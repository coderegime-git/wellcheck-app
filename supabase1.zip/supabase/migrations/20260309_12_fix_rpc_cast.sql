-- Create Secure PIN Join Function with explicit casting for custom ENUM types
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- We must cast the string record to the custom enum type "shield_role"
    INSERT INTO public.family_members(family_id, user_id, role, status)
    VALUES (invite_record.family_id, v_user_id, invite_record.role::shield_role, 'active')
    ON CONFLICT (family_id, user_id) DO NOTHING;

    -- Mark invite used
    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;
