-- Create a Database Webhook to trigger the push_notifications edge function
-- when a new 'sos' event is inserted into 'well_events'

-- 1. Note: This requires the pg_net extension to be enabled if doing raw HTTP requests,
-- but typically Supabase dashboard manages webhooks via the 'supautils' extension.
-- We'll define the standard Supabase webhook trigger here using the http_request function.

CREATE OR REPLACE FUNCTION public.trigger_sos_push_notification()
RETURNS TRIGGER AS $$
BEGIN
  -- We only want to notify if it's an SOS type
  IF NEW.event_type = 'sos' THEN
    -- In a real Supabase environment, you would use net.http_post
    -- or configure this via the Webhooks UI in the Dashboard.
    -- Here we simulate the trigger logic pointing to our Edge Function.
    
    perform net.http_post(
        url := coalesce(current_setting('app.settings.edge_function_url', true), 'http://host.docker.internal:54321/functions/v1/push_notifications'),
        body := jsonb_build_object(
            'type', 'INSERT',
            'table', 'well_events',
            'schema', 'public',
            'record', row_to_json(NEW)
        ),
        headers := '{"Content-Type": "application/json", "Authorization": "Bearer ' || coalesce(current_setting('app.settings.service_role_key', true), 'anon') || '"}'::jsonb
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop trigger if it exists
DROP TRIGGER IF EXISTS well_events_sos_trigger ON public.well_events;

-- Create the trigger on insertions
CREATE TRIGGER well_events_sos_trigger
  AFTER INSERT ON public.well_events
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_sos_push_notification();
