-- ============================================================
-- Well-Check V3: Medication Cloud Routing
-- Creates Database Triggers & Webhook structures to call 
-- the 'push-router' Edge Function for Push Notifications.
-- ============================================================

-- Enable pg_net to make external HTTP requests to Edge Functions
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Create a secure wrapper function to call our Edge Function.
-- NOTE: In production, configure SUPABASE_URL and SERVICE_ROLE_KEY
-- securely via Supabase Vault or custom settings. Replace placeholders here.
CREATE OR REPLACE FUNCTION public.trigger_fcm_push(
  p_target_user_id UUID,
  p_title TEXT,
  p_body TEXT,
  p_action TEXT DEFAULT 'default',
  p_payload TEXT DEFAULT ''
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_url TEXT := current_setting('app.settings.supabase_url', true) || '/functions/v1/push-router';
  v_key TEXT := current_setting('app.settings.service_role_key', true);
  v_body JSONB;
BEGIN
  -- Fallback if variables are not set in database config
  IF v_url IS NULL OR v_url = '/functions/v1/push-router' THEN
    v_url := 'https://lravvptfltbfbfmbhomp.supabase.co/functions/v1/push-router';
  END IF;
  
  IF v_key IS NULL THEN
    v_key := 'sb_publishable_cw-1FC21PuZXP6KJWdOcdA_ukAYxvaF';
  END IF;

  v_body := jsonb_build_object(
    'target_user_id', p_target_user_id,
    'title', p_title,
    'body', p_body,
    'action', p_action,
    'payload', p_payload
  );

  -- Dispatch async HTTP POST via pg_net
  PERFORM extensions.http_post(
    url := v_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || v_key
    ),
    body := v_body
  );
END;
$$;

-- ============================================================
-- TRIGGERS: Escalate "Dose Taken" to Leaders / Monitors
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_dose_logged_escalation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_patient_name TEXT;
  v_med_name TEXT;
  v_member RECORD;
BEGIN
  -- Only trigger for explicit "taken" logs
  IF NEW.status != 'taken' THEN
    RETURN NEW;
  END IF;

  -- 1. Get the patient's name
  SELECT full_name INTO v_patient_name 
  FROM public.profiles WHERE id = NEW.user_id;

  -- 2. Get the medication name
  SELECT medication_name INTO v_med_name 
  FROM public.medications WHERE id = NEW.medication_id;

  -- 3. Find completely separate users in the same family who are Leaders or Monitors
  FOR v_member IN 
    SELECT user_id FROM public.family_members 
    WHERE family_id = NEW.family_id 
      AND user_id != NEW.user_id 
      AND role IN ('leader', 'monitor')
  LOOP
    -- 4. Send FCM Push Notification
    PERFORM public.trigger_fcm_push(
      p_target_user_id := v_member.user_id,
      p_title := '✅ Medication Logged',
      p_body := COALESCE(v_patient_name, 'A member') || ' just logged ' || COALESCE(v_med_name, 'a dose') || '.',
      p_action := 'dose_escalation'
    );
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_dose_escalation ON public.dose_logs;
CREATE TRIGGER trg_dose_escalation
  AFTER INSERT ON public.dose_logs
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_dose_logged_escalation();

-- ============================================================
-- CRON JOB: Medication Schedule Dispatcher
-- ============================================================

-- NOTE: Ensure pg_cron is enabled in your Supabase Dashboard
-- Database -> Extensions -> search 'pg_cron'

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;

-- Function to check medications and trigger pushes
CREATE OR REPLACE FUNCTION public.dispatch_medication_pushes()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_med RECORD;
  v_now_time TEXT := to_char(now() AT TIME ZONE 'UTC', 'HH24:MI'); -- Using UTC for simplicity in MVP
BEGIN
  -- For every medication that is active
  FOR v_med IN 
    SELECT id, assigned_to, medication_name, dosage, schedule_times, instructions
    FROM public.medications 
    WHERE is_active = true 
      AND schedule_times IS NOT NULL
      AND array_length(schedule_times, 1) > 0
  LOOP
    -- If the current UTC time matches one of the scheduled times
    -- (In production, join with profiles.timezone to do proper local time matching)
    IF v_now_time = ANY(v_med.schedule_times) THEN
      PERFORM public.trigger_fcm_push(
        p_target_user_id := v_med.assigned_to,
        p_title := '💊 Time for ' || v_med.medication_name,
        p_body := v_med.dosage || ' — ' || COALESCE(v_med.instructions, 'Take as prescribed'),
        p_action := 'medication_reminder',
        p_payload := v_med.id::TEXT
      );
    END IF;
  END LOOP;
END;
$$;

-- Schedule it to run every minute
-- Note: cron.schedule may require postgres role depending on Supabase setup
DO $$
BEGIN
  BEGIN
    PERFORM cron.schedule('medication_dispatcher', '* * * * *', 'SELECT public.dispatch_medication_pushes()');
  EXCEPTION WHEN OTHERS THEN 
    -- Ignore if permission denied in free tier, instruct user to configure via dashboard
    NULL;
  END;
END $$;

-- ============================================================
-- DONE
-- ============================================================
