BEGIN;
  -- Add all core tables to the realtime engine natively.
  -- Supabase ignores if they are already added, doing DROP IF EXISTS is not standard for publications
  ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.families;
COMMIT;
