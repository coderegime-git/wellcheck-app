-- ==============================================================
-- Migration: 20260317_fix_all_features.sql
-- Purpose: Fix schema gaps for all broken features
-- ==============================================================

-- ============================================================
-- 1. SAFE ZONES: Ensure required columns exist
-- ============================================================
DO $$
BEGIN
  -- Add alert columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations_safe_zones' AND column_name = 'alert_on_entry'
  ) THEN
    ALTER TABLE public.locations_safe_zones ADD COLUMN alert_on_entry BOOLEAN DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations_safe_zones' AND column_name = 'alert_on_exit'
  ) THEN
    ALTER TABLE public.locations_safe_zones ADD COLUMN alert_on_exit BOOLEAN DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- 2. PROFILES: Ensure avatar_url column exists
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'avatar_url'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN avatar_url TEXT;
  END IF;
END $$;

-- ============================================================
-- 3. CALENDAR_EVENTS: Ensure table has correct columns
-- ============================================================
DO $$
BEGIN
  -- Ensure 'notes' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'notes'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN notes TEXT;
  END IF;

  -- Ensure 'participants' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'participants'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN participants TEXT[] DEFAULT '{}';
  END IF;

  -- Ensure 'location' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'location'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN location TEXT;
  END IF;
END $$;

-- ============================================================
-- 4. WELL_EVENTS: Make sure all columns exist for proper event handling
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'metadata'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN metadata JSONB DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'latitude'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN latitude DOUBLE PRECISION;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'longitude'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN longitude DOUBLE PRECISION;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'battery_level'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN battery_level INT;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN created_by UUID;
  END IF;
END $$;

-- ============================================================
-- 5. DISABLE RLS on all tables for MVP (ensure all data flows)
-- ============================================================
ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;

-- ============================================================
-- 6. GRANTS: Full access for authenticated + anon for MVP
-- ============================================================
GRANT ALL ON public.locations_safe_zones TO authenticated, anon;
GRANT ALL ON public.calendar_events TO authenticated, anon;
GRANT ALL ON public.check_ins TO authenticated, anon;
GRANT ALL ON public.well_events TO authenticated, anon;
GRANT ALL ON public.profiles TO authenticated, anon;
GRANT ALL ON public.family_members TO authenticated, anon;
GRANT ALL ON public.medications TO authenticated, anon;
GRANT ALL ON public.families TO authenticated, anon;

-- ============================================================
-- 7. REALTIME: Add all tables to realtime publication
-- ============================================================
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.locations_safe_zones;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.calendar_events;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.medications;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.families;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;

-- ============================================================
-- 8. STORAGE BUCKETS: Create manually in Supabase Dashboard
-- ============================================================
-- Go to Supabase Dashboard > Storage:
-- 1. Create bucket 'avatars' (public)
-- 2. Create bucket 'medical_vault' (private)
-- 3. Create bucket 'family_vault' (private)
-- 4. Under each bucket's Policies, add a policy allowing authenticated users
