-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.safe_zones ENABLE ROW LEVEL SECURITY;

-- Helper Function: Check if user is in a given family
CREATE OR REPLACE FUNCTION public.is_family_member(check_family_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.family_members
    WHERE family_id = check_family_id
    AND user_id = auth.uid()
    AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================
-- 1. PROFILES
-- Users can read profiles in their family. Users can update their own profile.
-- ==========================================
CREATE POLICY "Users can read profiles they share a family with."
ON public.profiles FOR SELECT
USING (
  id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.family_members fm1
    JOIN public.family_members fm2 ON fm1.family_id = fm2.family_id
    WHERE fm1.user_id = auth.uid() AND fm2.user_id = profiles.id AND fm1.status = 'active'
  )
);

CREATE POLICY "Users can update own profile."
ON public.profiles FOR UPDATE
USING (id = auth.uid());

CREATE POLICY "Users can insert their own profile."
ON public.profiles FOR INSERT
WITH CHECK (id = auth.uid());


-- ==========================================
-- 2. FAMILIES
-- Users can see their own families.
-- ==========================================
CREATE POLICY "Users can view families they belong to."
ON public.families FOR SELECT
USING (public.is_family_member(id));

CREATE POLICY "Users can create families."
ON public.families FOR INSERT
WITH CHECK (true);

-- ==========================================
-- 3. FAMILY MEMBERS
-- Users can see members of their families. They can insert their own pending requests.
-- ==========================================
CREATE POLICY "Users can view their family members."
ON public.family_members FOR SELECT
USING (
  user_id = auth.uid() OR 
  public.is_family_member(family_id)
);

CREATE POLICY "Users can join families (pending)."
ON public.family_members FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Leaders can update member status."
ON public.family_members FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.family_members
    WHERE family_id = family_members.family_id
    AND user_id = auth.uid()
    AND role = 'leader'
  )
);

-- ==========================================
-- 4. WELL EVENTS
-- Active members can read and insert events for their family.
-- ==========================================
CREATE POLICY "Members can view family events."
ON public.well_events FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Users can insert their own events."
ON public.well_events FOR INSERT
WITH CHECK (user_id = auth.uid() AND public.is_family_member(family_id));


-- ==========================================
-- 5. CHAT MESSAGES
-- Active members can read and write chat to their family.
-- ==========================================
CREATE POLICY "Members can view family chat."
ON public.chat_messages FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can send family chat."
ON public.chat_messages FOR INSERT
WITH CHECK (sender_id = auth.uid() AND public.is_family_member(family_id));


-- ==========================================
-- 6. MEDICATIONS & SAFE ZONES
-- Active members can read details.
-- ==========================================
CREATE POLICY "Members can view family medications."
ON public.medications FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can edit family medications."
ON public.medications FOR ALL
USING (public.is_family_member(family_id));

CREATE POLICY "Members can view safe zones."
ON public.safe_zones FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can edit safe zones."
ON public.safe_zones FOR ALL
USING (public.is_family_member(family_id));
