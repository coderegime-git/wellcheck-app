-- ============================================================
-- Well-Check Fix: well_events missing columns
-- Purpose: Ensures family_id and metadata tracking columns are explicitly bound 
-- to prevent Postgrest exceptions during CheckIn and Background Pulses.
-- ============================================================

DO $$
BEGIN
  -- 1. Ensure family_id exists to allow proper family-level streaming in SafetyRepository
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'family_id'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN family_id UUID REFERENCES public.families(id) ON DELETE CASCADE;
  END IF;

  -- 2. Ensure verification_source exists to allow Security Check-ins
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'verification_source'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN verification_source TEXT;
  END IF;
END $$;
