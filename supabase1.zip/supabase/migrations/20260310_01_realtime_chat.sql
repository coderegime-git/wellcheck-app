BEGIN;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
COMMIT;
