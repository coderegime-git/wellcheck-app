CREATE TABLE public.family_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    code VARCHAR(6) NOT NULL UNIQUE,
    role VARCHAR(50) NOT NULL,
    created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    used BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.family_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage family invites"
ON public.family_invites
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles
    WHERE user_profiles.id = auth.uid()
      AND user_profiles.family_id = family_invites.family_id
      AND user_profiles.role = 'leader'
  )
);

CREATE POLICY "Anyone can view active invites by code"
ON public.family_invites
FOR SELECT
USING (
  used = false AND expires_at > NOW()
);

-- RPC for securely consuming the code
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
    v_profile_exists BOOLEAN;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    -- Lock the invite row for update
    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- Check if user profile already exists
    SELECT EXISTS (
        SELECT 1 FROM public.user_profiles WHERE id = v_user_id
    ) INTO v_profile_exists;

    IF v_profile_exists THEN
        -- Optionally allow switching families, but for safety let's deny it if they already belong to one.
        RAISE EXCEPTION 'User already has a profile. Cannot join a completely new family.';
    END IF;

    -- Create target profile
    INSERT INTO public.user_profiles (id, family_id, role, full_name, email)
    SELECT
        v_user_id,
        invite_record.family_id,
        invite_record.role,
        -- fallback defaults
        'Family Member', 
        (SELECT email FROM auth.users WHERE id = v_user_id)
    ;

    -- Mark invite used
    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;
