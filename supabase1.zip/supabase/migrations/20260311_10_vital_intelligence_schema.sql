-- ===========================================================================
-- Vital-Intelligence Schema: Health Vitals, Baselines, and Consent Ledger
-- ===========================================================================

BEGIN;

-- 1. Add Vital Anomaly to event_type enum
-- Note: Adding values to enums must be done outside a transaction block in some PG versions,
-- but within a script it usually works or we can use separate blocks.
ALTER TYPE public.event_type ADD VALUE IF NOT EXISTS 'vital_anomaly';

-- 2. Create Consent Ledger (Privacy First)
CREATE TABLE IF NOT EXISTS public.consent_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    data_type TEXT NOT NULL, -- e.g., 'heart_rate', 'location_high_fidelity'
    granted BOOLEAN DEFAULT false,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, data_type)
);

-- 3. Create Health Vitals (Raw Telemetry)
-- This table stores high-frequency biometric data
CREATE TABLE IF NOT EXISTS public.health_vitals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    vital_type TEXT NOT NULL, -- 'heart_rate', 'hrv', 'blood_oxygen', 'respiratory_rate'
    value DOUBLE PRECISION NOT NULL,
    unit TEXT,
    timestamp TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create Health Baselines (Predictive AI)
-- Stores the 'normal' range for a user
CREATE TABLE IF NOT EXISTS public.health_baselines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    vital_type TEXT NOT NULL,
    min_value DOUBLE PRECISION,
    max_value DOUBLE PRECISION,
    avg_value DOUBLE PRECISION,
    sample_count INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, vital_type)
);

-- 5. Disable RLS for MVP iteration
ALTER TABLE public.consent_ledger DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_baselines DISABLE ROW LEVEL SECURITY;

-- 6. Add to Realtime Publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.consent_ledger;
ALTER PUBLICATION supabase_realtime ADD TABLE public.health_vitals;
ALTER PUBLICATION supabase_realtime ADD TABLE public.health_baselines;

COMMIT;
