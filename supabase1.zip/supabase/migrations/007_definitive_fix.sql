-- ============================================================
-- Well-Check V3: DEFINITIVE RLS FIX + Schema Alignment
-- Run this ONCE in Supabase SQL Editor.
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- STEP 1: Create any missing tables FIRST (before disabling RLS)

CREATE TABLE IF NOT EXISTS public.medications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  assigned_to UUID NOT NULL,
  medication_name TEXT NOT NULL,
  dosage TEXT NOT NULL,
  frequency TEXT NOT NULL,
  instructions TEXT,
  doctor TEXT,
  start_date TIMESTAMPTZ,
  end_date TIMESTAMPTZ,
  is_encrypted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  created_by UUID NOT NULL,
  title TEXT NOT NULL,
  event_datetime TIMESTAMPTZ NOT NULL,
  location TEXT,
  participants UUID[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.check_ins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  latitude DOUBLE PRECISION DEFAULT 0,
  longitude DOUBLE PRECISION DEFAULT 0,
  status_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.locations_safe_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  name TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  radius_meters DOUBLE PRECISION DEFAULT 200,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.family_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id UUID NOT NULL,
  sender_id UUID NOT NULL,
  message TEXT NOT NULL,
  message_type TEXT DEFAULT 'text',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- STEP 2: Ensure well_events has title, description, created_by
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'title') THEN
    ALTER TABLE well_events ADD COLUMN title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'description') THEN
    ALTER TABLE well_events ADD COLUMN description text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'created_by') THEN
    ALTER TABLE well_events ADD COLUMN created_by uuid;
  END IF;
END $$;

-- STEP 3: Add avatar_url to profiles
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'avatar_url') THEN
    ALTER TABLE profiles ADD COLUMN avatar_url TEXT;
  END IF;
END $$;

-- STEP 4: Disable RLS on ALL tables (now they all exist)
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;

-- Also disable on optional tables if they exist
DO $$
BEGIN
  BEGIN ALTER TABLE public.safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.vault_entries DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.driving_sessions DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.chat_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
END $$;

-- STEP 5: Grant ALL to anon + authenticated
GRANT ALL ON public.medications TO anon, authenticated;
GRANT ALL ON public.calendar_events TO anon, authenticated;
GRANT ALL ON public.check_ins TO anon, authenticated;
GRANT ALL ON public.locations_safe_zones TO anon, authenticated;
GRANT ALL ON public.family_messages TO anon, authenticated;
GRANT ALL ON public.well_events TO anon, authenticated;
GRANT ALL ON public.profiles TO anon, authenticated;
GRANT ALL ON public.families TO anon, authenticated;
GRANT ALL ON public.family_members TO anon, authenticated;

-- Optional tables (ignore errors)
DO $$
BEGIN
  BEGIN EXECUTE 'GRANT ALL ON public.safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.health_vitals TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.vault_entries TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.driving_sessions TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.chat_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- STEP 6: Add tables to realtime publication
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.family_messages; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.medications; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.calendar_events; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. All tables created, RLS disabled, grants applied.
-- ============================================================
