-- ===========================================================================
-- Geo-Shield Pro: Semantic Location and Vertical Awareness
-- ===========================================================================

BEGIN;

-- 1. Add semantic location fields to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS semantic_location TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS floor_level INT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS altitude DOUBLE PRECISION;

-- 2. Add semantic context to well_events for historical tracking
-- This allows us to see 'Room 402' in the activity log
ALTER TABLE public.well_events ADD COLUMN IF NOT EXISTS semantic_location TEXT;

-- 3. Create Location Metadata Table for mapping signal fingerprints to rooms
CREATE TABLE IF NOT EXISTS public.location_metadata (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    altitude DOUBLE PRECISION,
    semantic_label TEXT NOT NULL, -- e.g., 'Room 402', 'Kitchen', 'Library'
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Disable RLS for MVP
ALTER TABLE public.location_metadata DISABLE ROW LEVEL SECURITY;

-- 5. Add to Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.location_metadata;

COMMIT;
