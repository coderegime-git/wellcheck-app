-- ============================================================
-- Well-Check V3: A++ Elite Schema Alignment
-- Creates missing tables referenced by the A++ Dart code
-- ============================================================

-- 1. HEALTH VITALS — Raw readings from HealthKit / Google Fit
CREATE TABLE IF NOT EXISTS health_vitals (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  family_id uuid NOT NULL,
  vital_type text NOT NULL,        -- e.g. 'HEART_RATE', 'BLOOD_OXYGEN', 'HRV_SDNN'
  value double precision NOT NULL,
  unit text NOT NULL,              -- e.g. 'bpm', '%', 'ms'
  timestamp timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Unique constraint for upsert deduplication
ALTER TABLE health_vitals
  ADD CONSTRAINT health_vitals_unique
  UNIQUE (user_id, vital_type, timestamp);

-- RLS
ALTER TABLE health_vitals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own vitals"
  ON health_vitals FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read family vitals"
  ON health_vitals FOR SELECT
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND status = 'active'
    )
  );

-- Index for fast family-level queries
CREATE INDEX idx_health_vitals_family ON health_vitals(family_id, vital_type, timestamp DESC);


-- 2. HEALTH BASELINES — Personal baselines for anomaly detection
CREATE TABLE IF NOT EXISTS health_baselines (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  vital_type text NOT NULL,
  avg_value double precision,
  max_value double precision,
  hrv_avg double precision DEFAULT 50.0,
  sample_count int DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE health_baselines
  ADD CONSTRAINT health_baselines_unique
  UNIQUE (user_id, vital_type);

ALTER TABLE health_baselines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own baselines"
  ON health_baselines FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);


-- 3. CONSENT LEDGER — GDPR / Privacy consent tracking
CREATE TABLE IF NOT EXISTS consent_ledger (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  data_type text NOT NULL,         -- e.g. 'health_data', 'location', 'biometrics'
  granted boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE consent_ledger
  ADD CONSTRAINT consent_ledger_unique
  UNIQUE (user_id, data_type);

ALTER TABLE consent_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own consent"
  ON consent_ledger FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);


-- 4. LOCATION METADATA — Semantic zones with altitude / floor info
CREATE TABLE IF NOT EXISTS location_metadata (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  semantic_label text NOT NULL,    -- e.g. 'Home', 'School', 'Work'
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  altitude double precision,       -- NULL if not set
  floor_name text,                 -- e.g. '2nd Floor', 'Basement'
  radius double precision DEFAULT 50.0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE location_metadata ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Family members can read location metadata"
  ON location_metadata FOR SELECT
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND status = 'active'
    )
  );

CREATE POLICY "Leaders can manage location metadata"
  ON location_metadata FOR ALL
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND role = 'leader'
    )
  )
  WITH CHECK (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND role = 'leader'
    )
  );

-- GRANTs for anon/authenticated roles
GRANT SELECT, INSERT, UPDATE, DELETE ON health_vitals TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON health_baselines TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON consent_ledger TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON location_metadata TO authenticated;

-- ============================================================
-- Run this in Supabase SQL Editor to complete schema alignment
-- ============================================================
