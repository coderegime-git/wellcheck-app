-- Campus Watch Configuration: per-user monitoring toggles
-- Allows leaders to configure which notifications they want per family member

CREATE TABLE IF NOT EXISTS campus_watch_config (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  notify_zone_entry BOOLEAN DEFAULT true,
  notify_zone_exit BOOLEAN DEFAULT true,
  notify_campus_alert BOOLEAN DEFAULT true,
  notify_check_in BOOLEAN DEFAULT true,
  is_monitored BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(family_id, user_id)
);

-- Disable RLS for simplicity (same pattern as other tables in this project)
ALTER TABLE campus_watch_config DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON campus_watch_config TO anon, authenticated;

-- Add to realtime
ALTER PUBLICATION supabase_realtime ADD TABLE campus_watch_config;
