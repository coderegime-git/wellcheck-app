-- Add phone column to profiles for contact lookups
-- Phone is stored in auth.users but we need it accessible from client queries

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;

-- Backfill from auth.users where possible
UPDATE public.profiles p
SET phone = u.phone
FROM auth.users u
WHERE p.id = u.id AND u.phone IS NOT NULL AND p.phone IS NULL;

-- Update the existing auth trigger to also sync phone on new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, phone)
  VALUES (new.id, new.phone)
  ON CONFLICT (id) DO UPDATE SET phone = EXCLUDED.phone;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT ALL ON public.profiles TO anon, authenticated;
