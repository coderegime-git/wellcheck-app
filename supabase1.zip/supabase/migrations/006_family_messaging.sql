-- ============================================================
-- Well-Check V3: Family Messaging + Avatars
-- Run in Supabase SQL Editor after 005_missing_tables.sql
-- ============================================================

-- 1. FAMILY_MESSAGES — Real-time in-app messaging
CREATE TABLE IF NOT EXISTS family_messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  message_type text DEFAULT 'text', -- 'text', 'image', 'alert'
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE family_messages DISABLE ROW LEVEL SECURITY;
GRANT ALL ON family_messages TO anon, authenticated;

-- Index for fast family-scoped queries
CREATE INDEX IF NOT EXISTS idx_family_messages_family_id
  ON family_messages(family_id, created_at DESC);

-- 2. Add avatar_url column to profiles if missing
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'avatar_url') THEN
    ALTER TABLE profiles ADD COLUMN avatar_url text;
  END IF;
END $$;

-- ============================================================
-- Done. Run in Supabase SQL Editor.
-- ============================================================
