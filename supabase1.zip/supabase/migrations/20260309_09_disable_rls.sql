-- Disable RLS to allow unrestricted flutter development
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_invites DISABLE ROW LEVEL SECURITY;
