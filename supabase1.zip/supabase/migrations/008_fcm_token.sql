-- ============================================================
-- Well-Check V3: Add FCM token column for push notifications
-- Safe to re-run — idempotent.
-- ============================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'fcm_token') THEN
    ALTER TABLE profiles ADD COLUMN fcm_token TEXT;
  END IF;
END $$;

-- Grant access
GRANT ALL ON public.profiles TO anon, authenticated;
