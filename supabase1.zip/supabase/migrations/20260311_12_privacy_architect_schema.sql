-- ===========================================================================
-- Privacy-Architect: E2EE Family Key Management
-- ===========================================================================

BEGIN;

-- 1. Create family_keys table for encrypted Master Key distribution
CREATE TABLE IF NOT EXISTS public.family_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    encrypted_master_key TEXT NOT NULL, -- Master Key encrypted with member's Public RSA Key
    public_rsa_key TEXT NOT NULL, -- Member's Public Key for others to encrypt for them
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(family_id, user_id)
);

-- 2. Add 'is_encrypted' flag to vaults (if vault table exists, otherwise placeholder)
-- Assuming we might have a 'documents' or 'vault_items' table soon
-- For now, let's mark medications or attachments as potentially encrypted
ALTER TABLE public.medications ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false;

-- 3. Disable RLS for MVP
ALTER TABLE public.family_keys DISABLE ROW LEVEL SECURITY;

-- 4. Add to Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.family_keys;

COMMIT;
