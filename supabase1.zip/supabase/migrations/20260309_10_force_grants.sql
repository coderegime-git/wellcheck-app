-- In Supabase, the API connects using the "anon" or "authenticated" role.
-- Simply disabling RLS does not bypass the base PostgreSQL table GRANTS.

-- 1. Grant access to the tables for the API roles
GRANT ALL ON TABLE public.family_invites TO anon;
GRANT ALL ON TABLE public.family_invites TO authenticated;

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;

GRANT ALL ON TABLE public.families TO anon;
GRANT ALL ON TABLE public.families TO authenticated;

GRANT ALL ON TABLE public.family_members TO anon;
GRANT ALL ON TABLE public.family_members TO authenticated;

GRANT ALL ON TABLE public.well_events TO anon;
GRANT ALL ON TABLE public.well_events TO authenticated;

-- 2. Make absolutely sure RLS is off for the test
ALTER TABLE public.family_invites DISABLE ROW LEVEL SECURITY;

-- 3. If you want to use the RPC function, grant execution rights to it
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO authenticated;
