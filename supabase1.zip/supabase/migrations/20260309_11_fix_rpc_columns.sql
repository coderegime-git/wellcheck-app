-- Drop the old one securely
DROP FUNCTION IF EXISTS public.join_family_with_code(TEXT);

-- Create Secure PIN Join Function strictly using family_members
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- ONLY target family_members as the single source of truth for relationships
    INSERT INTO public.family_members(family_id, user_id, role, status)
    VALUES (invite_record.family_id, v_user_id, invite_record.role, 'active')
    ON CONFLICT (family_id, user_id) DO NOTHING;

    -- Mark invite used
    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;

-- Ensure Execution rights are given
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO authenticated;
