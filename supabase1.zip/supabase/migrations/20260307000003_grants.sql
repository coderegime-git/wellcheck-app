-- 403 Forbidden Fix: Grant basic permissions to the 'authenticated' role.
-- Currently, Supabase blocks users before RLS logic even runs because these basic grants 
-- were not created automatically since the tables were instantiated manually.

-- Grant usage on the public schema
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Grant permissions to read, update, and insert across all tables for active users
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;

-- Grant full system permissions to the service role (used by auth triggers/server functions)
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
