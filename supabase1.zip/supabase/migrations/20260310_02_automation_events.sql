-- Add new automation event types to the enum.
-- Note: Postgres enums cannot be updated within a transaction for some versions,
-- but adding values is generally safe with ALTER TYPE.

ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'driving';
ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'safe_zone_enter';
ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'safe_zone_exit';
