-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- PROFILES: Extended data for authenticated users
CREATE TABLE public.profiles (
  id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  last_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- FAMILIES: The core 'Shield' container
CREATE TABLE public.families (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  name TEXT NOT NULL,
  invite_code VARCHAR(6) UNIQUE, 
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- FAMILY MEMBERS: Join table managing RBAC within a shield
CREATE TYPE shield_role AS ENUM ('leader', 'monitor', 'senior', 'student', 'pet');
CREATE TYPE member_status AS ENUM ('pending', 'active', 'suspended');

CREATE TABLE public.family_members (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role shield_role NOT NULL,
  status member_status DEFAULT 'pending' NOT NULL,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE(family_id, user_id)
);

-- WELL EVENTS: Immutable ledger for heartbeats, check-ins, SOS, etc.
CREATE TYPE event_type AS ENUM ('heartbeat', 'sos', 'aura_checkin', 'medication_taken', 'geofence_trigger');

CREATE TABLE public.well_events (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  event_type event_type NOT NULL,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  battery_level INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb, -- flexible payload for different events
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  verification_source TEXT,
  PRIMARY KEY (id)
);

-- CHAT MESSAGES: Realtime family hub
CREATE TABLE public.chat_messages (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- MEDICATIONS: Master list of tracked drugs
CREATE TABLE public.medications (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  assigned_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  dosage TEXT NOT NULL,
  schedule_time TIME NOT NULL,
  inventory_count INTEGER DEFAULT 0 NOT NULL,
  refill_threshold INTEGER DEFAULT 5 NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- SAFE ZONES: Geofencing tools
CREATE TABLE public.safe_zones (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  assigned_user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE, -- Who the zone is tracked for
  name TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  radius_meters INTEGER NOT NULL DEFAULT 500,
  alert_on_entry BOOLEAN DEFAULT true,
  alert_on_exit BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- Note: We will add RLS policies in a separate migration step or follow-up file to keep it organized.
