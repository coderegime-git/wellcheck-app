-- 1. Create Core Tables safely
CREATE TABLE IF NOT EXISTS public.families (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    invite_code VARCHAR(6) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.family_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(family_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    family_id UUID REFERENCES public.families(id) ON DELETE SET NULL,
    role VARCHAR(50),
    full_name VARCHAR(255),
    email VARCHAR(255),
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.well_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(50) NOT NULL DEFAULT 'info',
    location_lat DOUBLE PRECISION,
    location_lng DOUBLE PRECISION,
    battery_level INTEGER,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Create the New Invites Table safely
CREATE TABLE IF NOT EXISTS public.family_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    code VARCHAR(6) NOT NULL UNIQUE,
    role VARCHAR(50) NOT NULL,
    created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    used BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Enable Row Level Security (RLS) on all tables safely
-- PostgreSQL doesn't have "ALTER TABLE IF EXISTS ENABLE ROW LEVEL SECURITY"
-- but running it multiple times is a no-op/safe operation.
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_invites ENABLE ROW LEVEL SECURITY;

-- 4. Apply Security Policies safely (requires dropping them first if they exist)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.families;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.families;
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.family_members;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.family_members;
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow update access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow read access to auth users" ON public.well_events;
    DROP POLICY IF EXISTS "Allow insert access to auth users" ON public.well_events;
    DROP POLICY IF EXISTS "Allow all to active invites" ON public.family_invites;
END $$;

CREATE POLICY "Allow read access to authenticated users" ON public.families FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.families FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to authenticated users" ON public.family_members FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.family_members FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to authenticated users" ON public.user_profiles FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.user_profiles FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Allow update access to authenticated users" ON public.user_profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Allow read access to auth users" ON public.well_events FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to auth users" ON public.well_events FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Allow all to active invites" ON public.family_invites FOR ALL USING (auth.role() = 'authenticated');

-- 5. Create Secure PIN Join Function
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
    v_profile_exists BOOLEAN;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- Ensure exact target profile is constructed mapping user to family
    INSERT INTO public.user_profiles (id, family_id, role, full_name, email)
    VALUES (
        v_user_id,
        invite_record.family_id,
        invite_record.role,
        'Family Member', 
        (SELECT email FROM auth.users WHERE id = v_user_id)
    )
    ON CONFLICT (id) DO UPDATE 
    SET family_id = EXCLUDED.family_id, role = EXCLUDED.role;
    
    INSERT INTO public.family_members(family_id, user_id, role, status)
    VALUES (invite_record.family_id, v_user_id, invite_record.role, 'active')
    ON CONFLICT (family_id, user_id) DO NOTHING;

    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;
