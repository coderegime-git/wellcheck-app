-- ============================================================
-- Well-Check V3: Medication Scheduler Schema
-- Adds scheduling columns to medications and creates dose_logs.
-- Run in Supabase SQL Editor after 20260317_schema_alignment.sql
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- ============================================================
-- 1. ADD SCHEDULING COLUMNS TO MEDICATIONS
-- ============================================================

-- schedule_times: array of HH:MM strings, e.g. {"08:00","20:00"}
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='schedule_times') THEN
    ALTER TABLE public.medications ADD COLUMN schedule_times TEXT[] DEFAULT '{}';
  END IF;
END $$;

-- start_date: when the schedule begins
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='start_date') THEN
    ALTER TABLE public.medications ADD COLUMN start_date DATE DEFAULT CURRENT_DATE;
  END IF;
END $$;

-- end_date: when it ends (null = indefinite/ongoing)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='end_date') THEN
    ALTER TABLE public.medications ADD COLUMN end_date DATE;
  END IF;
END $$;

-- recurrence: daily, every_other_day, weekly, monthly, as_needed
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='recurrence') THEN
    ALTER TABLE public.medications ADD COLUMN recurrence TEXT DEFAULT 'daily';
  END IF;
END $$;

-- days_of_week: for weekly schedules, array of ints 0=Sun..6=Sat
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='days_of_week') THEN
    ALTER TABLE public.medications ADD COLUMN days_of_week INT[] DEFAULT '{}';
  END IF;
END $$;

-- is_active: toggle medications on/off without deleting
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='is_active') THEN
    ALTER TABLE public.medications ADD COLUMN is_active BOOLEAN DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- 2. CREATE DOSE_LOGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.dose_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  medication_id UUID NOT NULL,
  user_id UUID NOT NULL,
  family_id UUID NOT NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  taken_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'pending',  -- pending, taken, missed, skipped
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Disable RLS for MVP
ALTER TABLE public.dose_logs DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON public.dose_logs TO anon, authenticated;

-- Add to realtime
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.dose_logs; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. Run after 20260317_schema_alignment.sql
-- ============================================================
