-- ============================================================
-- Well-Check V3: A++ Elite Schema Alignment
-- Creates missing tables referenced by the A++ Dart code
-- ============================================================

-- 1. HEALTH VITALS — Raw readings from HealthKit / Google Fit
CREATE TABLE IF NOT EXISTS health_vitals (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  family_id uuid NOT NULL,
  vital_type text NOT NULL,        -- e.g. 'HEART_RATE', 'BLOOD_OXYGEN', 'HRV_SDNN'
  value double precision NOT NULL,
  unit text NOT NULL,              -- e.g. 'bpm', '%', 'ms'
  timestamp timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Unique constraint for upsert deduplication
ALTER TABLE health_vitals
  ADD CONSTRAINT health_vitals_unique
  UNIQUE (user_id, vital_type, timestamp);

-- RLS
ALTER TABLE health_vitals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own vitals"
  ON health_vitals FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read family vitals"
  ON health_vitals FOR SELECT
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND status = 'active'
    )
  );

-- Index for fast family-level queries
CREATE INDEX idx_health_vitals_family ON health_vitals(family_id, vital_type, timestamp DESC);


-- 2. HEALTH BASELINES — Personal baselines for anomaly detection
CREATE TABLE IF NOT EXISTS health_baselines (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  vital_type text NOT NULL,
  avg_value double precision,
  max_value double precision,
  hrv_avg double precision DEFAULT 50.0,
  sample_count int DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE health_baselines
  ADD CONSTRAINT health_baselines_unique
  UNIQUE (user_id, vital_type);

ALTER TABLE health_baselines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own baselines"
  ON health_baselines FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);


-- 3. CONSENT LEDGER — GDPR / Privacy consent tracking
CREATE TABLE IF NOT EXISTS consent_ledger (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  data_type text NOT NULL,         -- e.g. 'health_data', 'location', 'biometrics'
  granted boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE consent_ledger
  ADD CONSTRAINT consent_ledger_unique
  UNIQUE (user_id, data_type);

ALTER TABLE consent_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own consent"
  ON consent_ledger FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);


-- 4. LOCATION METADATA — Semantic zones with altitude / floor info
CREATE TABLE IF NOT EXISTS location_metadata (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  semantic_label text NOT NULL,    -- e.g. 'Home', 'School', 'Work'
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  altitude double precision,       -- NULL if not set
  floor_name text,                 -- e.g. '2nd Floor', 'Basement'
  radius double precision DEFAULT 50.0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE location_metadata ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Family members can read location metadata"
  ON location_metadata FOR SELECT
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND status = 'active'
    )
  );

CREATE POLICY "Leaders can manage location metadata"
  ON location_metadata FOR ALL
  USING (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND role = 'leader'
    )
  )
  WITH CHECK (
    family_id IN (
      SELECT family_id FROM family_members WHERE user_id = auth.uid() AND role = 'leader'
    )
  );

-- GRANTs for anon/authenticated roles
GRANT SELECT, INSERT, UPDATE, DELETE ON health_vitals TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON health_baselines TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON consent_ledger TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON location_metadata TO authenticated;

-- ============================================================
-- Run this in Supabase SQL Editor to complete schema alignment
-- ============================================================
-- ============================================================
-- Well-Check V3: Missing Tables for Check-ins & Workflows
-- Run this in Supabase SQL Editor after 004_elite_schema_alignment.sql
-- ============================================================

-- 1. CHECK_INS — Manual broadcast signals
CREATE TABLE IF NOT EXISTS check_ins (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  latitude double precision,
  longitude double precision,
  status_message text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE check_ins DISABLE ROW LEVEL SECURITY;
GRANT ALL ON check_ins TO anon, authenticated;

-- 2. Ensure well_events has title + description columns (additive)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'title') THEN
    ALTER TABLE well_events ADD COLUMN title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'description') THEN
    ALTER TABLE well_events ADD COLUMN description text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'created_by') THEN
    ALTER TABLE well_events ADD COLUMN created_by uuid;
  END IF;
END $$;

-- ============================================================
-- Run in Supabase SQL Editor
-- ============================================================
-- ============================================================
-- Well-Check V3: Family Messaging + Avatars
-- Run in Supabase SQL Editor after 005_missing_tables.sql
-- ============================================================

-- 1. FAMILY_MESSAGES — Real-time in-app messaging
CREATE TABLE IF NOT EXISTS family_messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  message_type text DEFAULT 'text', -- 'text', 'image', 'alert'
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE family_messages DISABLE ROW LEVEL SECURITY;
GRANT ALL ON family_messages TO anon, authenticated;

-- Index for fast family-scoped queries
CREATE INDEX IF NOT EXISTS idx_family_messages_family_id
  ON family_messages(family_id, created_at DESC);

-- 2. Add avatar_url column to profiles if missing
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'avatar_url') THEN
    ALTER TABLE profiles ADD COLUMN avatar_url text;
  END IF;
END $$;

-- ============================================================
-- Done. Run in Supabase SQL Editor.
-- ============================================================
-- ============================================================
-- Well-Check V3: DEFINITIVE RLS FIX + Schema Alignment
-- Run this ONCE in Supabase SQL Editor.
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- STEP 1: Create any missing tables FIRST (before disabling RLS)

CREATE TABLE IF NOT EXISTS public.medications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  assigned_to UUID NOT NULL,
  medication_name TEXT NOT NULL,
  dosage TEXT NOT NULL,
  frequency TEXT NOT NULL,
  instructions TEXT,
  doctor TEXT,
  start_date TIMESTAMPTZ,
  end_date TIMESTAMPTZ,
  is_encrypted BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  created_by UUID NOT NULL,
  title TEXT NOT NULL,
  event_datetime TIMESTAMPTZ NOT NULL,
  location TEXT,
  participants UUID[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.check_ins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  latitude DOUBLE PRECISION DEFAULT 0,
  longitude DOUBLE PRECISION DEFAULT 0,
  status_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.locations_safe_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  name TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  radius_meters DOUBLE PRECISION DEFAULT 200,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.family_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id UUID NOT NULL,
  sender_id UUID NOT NULL,
  message TEXT NOT NULL,
  message_type TEXT DEFAULT 'text',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- STEP 2: Ensure well_events has title, description, created_by
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'title') THEN
    ALTER TABLE well_events ADD COLUMN title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'description') THEN
    ALTER TABLE well_events ADD COLUMN description text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'created_by') THEN
    ALTER TABLE well_events ADD COLUMN created_by uuid;
  END IF;
END $$;

-- STEP 3: Add avatar_url to profiles
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'avatar_url') THEN
    ALTER TABLE profiles ADD COLUMN avatar_url TEXT;
  END IF;
END $$;

-- STEP 4: Disable RLS on ALL tables (now they all exist)
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;

-- Also disable on optional tables if they exist
DO $$
BEGIN
  BEGIN ALTER TABLE public.safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.vault_entries DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.driving_sessions DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.chat_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
END $$;

-- STEP 5: Grant ALL to anon + authenticated
GRANT ALL ON public.medications TO anon, authenticated;
GRANT ALL ON public.calendar_events TO anon, authenticated;
GRANT ALL ON public.check_ins TO anon, authenticated;
GRANT ALL ON public.locations_safe_zones TO anon, authenticated;
GRANT ALL ON public.family_messages TO anon, authenticated;
GRANT ALL ON public.well_events TO anon, authenticated;
GRANT ALL ON public.profiles TO anon, authenticated;
GRANT ALL ON public.families TO anon, authenticated;
GRANT ALL ON public.family_members TO anon, authenticated;

-- Optional tables (ignore errors)
DO $$
BEGIN
  BEGIN EXECUTE 'GRANT ALL ON public.safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.health_vitals TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.vault_entries TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.driving_sessions TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.chat_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- STEP 6: Add tables to realtime publication
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.family_messages; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.medications; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.calendar_events; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. All tables created, RLS disabled, grants applied.
-- ============================================================
-- ============================================================
-- Well-Check V3: Add FCM token column for push notifications
-- Safe to re-run — idempotent.
-- ============================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'fcm_token') THEN
    ALTER TABLE profiles ADD COLUMN fcm_token TEXT;
  END IF;
END $$;

-- Grant access
GRANT ALL ON public.profiles TO anon, authenticated;
-- Create a Database Webhook to trigger the push_notifications edge function
-- when a new 'sos' event is inserted into 'well_events'

-- 1. Note: This requires the pg_net extension to be enabled if doing raw HTTP requests,
-- but typically Supabase dashboard manages webhooks via the 'supautils' extension.
-- We'll define the standard Supabase webhook trigger here using the http_request function.

CREATE OR REPLACE FUNCTION public.trigger_sos_push_notification()
RETURNS TRIGGER AS $$
BEGIN
  -- We only want to notify if it's an SOS type
  IF NEW.event_type = 'sos' THEN
    -- In a real Supabase environment, you would use net.http_post
    -- or configure this via the Webhooks UI in the Dashboard.
    -- Here we simulate the trigger logic pointing to our Edge Function.

    perform net.http_post(
        url := coalesce(current_setting('app.settings.edge_function_url', true), 'http://host.docker.internal:54321/functions/v1/push_notifications'),
        body := jsonb_build_object(
            'type', 'INSERT',
            'table', 'well_events',
            'schema', 'public',
            'record', row_to_json(NEW)
        ),
        headers := '{"Content-Type": "application/json", "Authorization": "Bearer ' || coalesce(current_setting('app.settings.service_role_key', true), 'anon') || '"}'::jsonb
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop trigger if it exists
DROP TRIGGER IF EXISTS well_events_sos_trigger ON public.well_events;

-- Create the trigger on insertions
CREATE TRIGGER well_events_sos_trigger
  AFTER INSERT ON public.well_events
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_sos_push_notification();
CREATE TABLE public.family_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    code VARCHAR(6) NOT NULL UNIQUE,
    role VARCHAR(50) NOT NULL,
    created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    used BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.family_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage family invites"
ON public.family_invites
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_profiles
    WHERE user_profiles.id = auth.uid()
      AND user_profiles.family_id = family_invites.family_id
      AND user_profiles.role = 'leader'
  )
);

CREATE POLICY "Anyone can view active invites by code"
ON public.family_invites
FOR SELECT
USING (
  used = false AND expires_at > NOW()
);

-- RPC for securely consuming the code
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
    v_profile_exists BOOLEAN;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    -- Lock the invite row for update
    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- Check if user profile already exists
    SELECT EXISTS (
        SELECT 1 FROM public.user_profiles WHERE id = v_user_id
    ) INTO v_profile_exists;

    IF v_profile_exists THEN
        -- Optionally allow switching families, but for safety let's deny it if they already belong to one.
        RAISE EXCEPTION 'User already has a profile. Cannot join a completely new family.';
    END IF;

    -- Create target profile
    INSERT INTO public.user_profiles (id, family_id, role, full_name, email)
    SELECT
        v_user_id,
        invite_record.family_id,
        invite_record.role,
        -- fallback defaults
        'Family Member',
        (SELECT email FROM auth.users WHERE id = v_user_id)
    ;

    -- Mark invite used
    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;
-- 1. Create Core Tables safely
CREATE TABLE IF NOT EXISTS public.families (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    invite_code VARCHAR(6) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.family_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(family_id, user_id)
);

CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    family_id UUID REFERENCES public.families(id) ON DELETE SET NULL,
    role VARCHAR(50),
    full_name VARCHAR(255),
    email VARCHAR(255),
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.well_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(50) NOT NULL DEFAULT 'info',
    location_lat DOUBLE PRECISION,
    location_lng DOUBLE PRECISION,
    battery_level INTEGER,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Create the New Invites Table safely
CREATE TABLE IF NOT EXISTS public.family_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    code VARCHAR(6) NOT NULL UNIQUE,
    role VARCHAR(50) NOT NULL,
    created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
    used BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Enable Row Level Security (RLS) on all tables safely
-- PostgreSQL doesn't have "ALTER TABLE IF EXISTS ENABLE ROW LEVEL SECURITY"
-- but running it multiple times is a no-op/safe operation.
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_invites ENABLE ROW LEVEL SECURITY;

-- 4. Apply Security Policies safely (requires dropping them first if they exist)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.families;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.families;
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.family_members;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.family_members;
    DROP POLICY IF EXISTS "Allow read access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow insert access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow update access to authenticated users" ON public.user_profiles;
    DROP POLICY IF EXISTS "Allow read access to auth users" ON public.well_events;
    DROP POLICY IF EXISTS "Allow insert access to auth users" ON public.well_events;
    DROP POLICY IF EXISTS "Allow all to active invites" ON public.family_invites;
END $$;

CREATE POLICY "Allow read access to authenticated users" ON public.families FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.families FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to authenticated users" ON public.family_members FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.family_members FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow read access to authenticated users" ON public.user_profiles FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to authenticated users" ON public.user_profiles FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Allow update access to authenticated users" ON public.user_profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Allow read access to auth users" ON public.well_events FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow insert access to auth users" ON public.well_events FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Allow all to active invites" ON public.family_invites FOR ALL USING (auth.role() = 'authenticated');

-- 5. Create Secure PIN Join Function
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
    v_profile_exists BOOLEAN;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- Ensure exact target profile is constructed mapping user to family
    INSERT INTO public.user_profiles (id, family_id, role, full_name, email)
    VALUES (
        v_user_id,
        invite_record.family_id,
        invite_record.role,
        'Family Member',
        (SELECT email FROM auth.users WHERE id = v_user_id)
    )
    ON CONFLICT (id) DO UPDATE
    SET family_id = EXCLUDED.family_id, role = EXCLUDED.role;

    INSERT INTO public.family_members(family_id, user_id, role, status)
    VALUES (invite_record.family_id, v_user_id, invite_record.role, 'active')
    ON CONFLICT (family_id, user_id) DO NOTHING;

    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;
-- Drop the old one securely
DROP FUNCTION IF EXISTS public.join_family_with_code(TEXT);

-- Create Secure PIN Join Function strictly using family_members
CREATE OR REPLACE FUNCTION join_family_with_code(invite_code TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    invite_record RECORD;
    v_user_id UUID;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Not authenticated';
    END IF;

    SELECT * INTO invite_record
    FROM public.family_invites
    WHERE code = invite_code
      AND used = false
      AND expires_at > NOW()
    FOR UPDATE SKIP LOCKED;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Invalid, expired, or already used invite code.';
    END IF;

    -- ONLY target family_members as the single source of truth for relationships
    INSERT INTO public.family_members(family_id, user_id, role, status)
    VALUES (invite_record.family_id, v_user_id, invite_record.role, 'active')
    ON CONFLICT (family_id, user_id) DO NOTHING;

    -- Mark invite used
    UPDATE public.family_invites
    SET used = true
    WHERE id = invite_record.id;

    RETURN json_build_object('success', true, 'family_id', invite_record.family_id, 'role', invite_record.role);
END;
$$;

-- Ensure Execution rights are given
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION public.join_family_with_code(TEXT) TO authenticated;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS full_name TEXT;
BEGIN;
  -- Add all core tables to the realtime engine natively.
  -- Supabase ignores if they are already added, doing DROP IF EXISTS is not standard for publications
  ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.families;
COMMIT;
-- ===========================================================================
-- Command Center Schema: Calendars, Medications, Check-ins, Safe Zones
-- ===========================================================================

BEGIN;

-- 1. Create Medications Table
CREATE TABLE IF NOT EXISTS public.medications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    assigned_to UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    medication_name TEXT NOT NULL,
    dosage TEXT NOT NULL,
    frequency TEXT NOT NULL,
    instructions TEXT,
    doctor TEXT,
    start_date TIMESTAMPTZ,
    end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Create Calendar Events Table
CREATE TABLE IF NOT EXISTS public.calendar_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    event_datetime TIMESTAMPTZ NOT NULL,
    location TEXT,
    participants UUID[] DEFAULT '{}',
    notes TEXT,
    reminders JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create Check-Ins Table
CREATE TABLE IF NOT EXISTS public.check_ins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    status_message TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create Locations & Safe Zones Table
CREATE TABLE IF NOT EXISTS public.locations_safe_zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    zone_name TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    radius_meters INT DEFAULT 100,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Note: We disable RLS on the new tables during MVP iteration just like the others
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY;

-- Bind the new tables into the real-time pipeline so listeners sync!
ALTER PUBLICATION supabase_realtime ADD TABLE public.medications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.calendar_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins;
ALTER PUBLICATION supabase_realtime ADD TABLE public.locations_safe_zones;

COMMIT;
BEGIN;
  ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
COMMIT;
-- Add new automation event types to the enum.
-- Note: Postgres enums cannot be updated within a transaction for some versions,
-- but adding values is generally safe with ALTER TYPE.

ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'driving';
ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'safe_zone_enter';
ALTER TYPE event_type ADD VALUE IF NOT EXISTS 'safe_zone_exit';
-- ===========================================================================
-- Vital-Intelligence Schema: Health Vitals, Baselines, and Consent Ledger
-- ===========================================================================

BEGIN;

-- 1. Add Vital Anomaly to event_type enum
-- Note: Adding values to enums must be done outside a transaction block in some PG versions,
-- but within a script it usually works or we can use separate blocks.
ALTER TYPE public.event_type ADD VALUE IF NOT EXISTS 'vital_anomaly';

-- 2. Create Consent Ledger (Privacy First)
CREATE TABLE IF NOT EXISTS public.consent_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    data_type TEXT NOT NULL, -- e.g., 'heart_rate', 'location_high_fidelity'
    granted BOOLEAN DEFAULT false,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, data_type)
);

-- 3. Create Health Vitals (Raw Telemetry)
-- This table stores high-frequency biometric data
CREATE TABLE IF NOT EXISTS public.health_vitals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    vital_type TEXT NOT NULL, -- 'heart_rate', 'hrv', 'blood_oxygen', 'respiratory_rate'
    value DOUBLE PRECISION NOT NULL,
    unit TEXT,
    timestamp TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create Health Baselines (Predictive AI)
-- Stores the 'normal' range for a user
CREATE TABLE IF NOT EXISTS public.health_baselines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    vital_type TEXT NOT NULL,
    min_value DOUBLE PRECISION,
    max_value DOUBLE PRECISION,
    avg_value DOUBLE PRECISION,
    sample_count INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(user_id, vital_type)
);

-- 5. Disable RLS for MVP iteration
ALTER TABLE public.consent_ledger DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_baselines DISABLE ROW LEVEL SECURITY;

-- 6. Add to Realtime Publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.consent_ledger;
ALTER PUBLICATION supabase_realtime ADD TABLE public.health_vitals;
ALTER PUBLICATION supabase_realtime ADD TABLE public.health_baselines;

COMMIT;
-- ===========================================================================
-- Geo-Shield Pro: Semantic Location and Vertical Awareness
-- ===========================================================================

BEGIN;

-- 1. Add semantic location fields to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS semantic_location TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS floor_level INT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS altitude DOUBLE PRECISION;

-- 2. Add semantic context to well_events for historical tracking
-- This allows us to see 'Room 402' in the activity log
ALTER TABLE public.well_events ADD COLUMN IF NOT EXISTS semantic_location TEXT;

-- 3. Create Location Metadata Table for mapping signal fingerprints to rooms
CREATE TABLE IF NOT EXISTS public.location_metadata (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    altitude DOUBLE PRECISION,
    semantic_label TEXT NOT NULL, -- e.g., 'Room 402', 'Kitchen', 'Library'
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Disable RLS for MVP
ALTER TABLE public.location_metadata DISABLE ROW LEVEL SECURITY;

-- 5. Add to Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.location_metadata;

COMMIT;
-- ===========================================================================
-- Privacy-Architect: E2EE Family Key Management
-- ===========================================================================

BEGIN;

-- 1. Create family_keys table for encrypted Master Key distribution
CREATE TABLE IF NOT EXISTS public.family_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    encrypted_master_key TEXT NOT NULL, -- Master Key encrypted with member's Public RSA Key
    public_rsa_key TEXT NOT NULL, -- Member's Public Key for others to encrypt for them
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(family_id, user_id)
);

-- 2. Add 'is_encrypted' flag to vaults (if vault table exists, otherwise placeholder)
-- Assuming we might have a 'documents' or 'vault_items' table soon
-- For now, let's mark medications or attachments as potentially encrypted
ALTER TABLE public.medications ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false;

-- 3. Disable RLS for MVP
ALTER TABLE public.family_keys DISABLE ROW LEVEL SECURITY;

-- 4. Add to Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.family_keys;

COMMIT;
-- ==============================================================
-- Migration: 20260317_fix_all_features.sql
-- Purpose: Fix schema gaps for all broken features
-- ==============================================================

-- ============================================================
-- 1. SAFE ZONES: Ensure required columns exist
-- ============================================================
DO $$
BEGIN
  -- Add alert columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations_safe_zones' AND column_name = 'alert_on_entry'
  ) THEN
    ALTER TABLE public.locations_safe_zones ADD COLUMN alert_on_entry BOOLEAN DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'locations_safe_zones' AND column_name = 'alert_on_exit'
  ) THEN
    ALTER TABLE public.locations_safe_zones ADD COLUMN alert_on_exit BOOLEAN DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- 2. PROFILES: Ensure avatar_url column exists
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'avatar_url'
  ) THEN
    ALTER TABLE public.profiles ADD COLUMN avatar_url TEXT;
  END IF;
END $$;

-- ============================================================
-- 3. CALENDAR_EVENTS: Ensure table has correct columns
-- ============================================================
DO $$
BEGIN
  -- Ensure 'notes' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'notes'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN notes TEXT;
  END IF;

  -- Ensure 'participants' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'participants'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN participants TEXT[] DEFAULT '{}';
  END IF;

  -- Ensure 'location' column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'calendar_events' AND column_name = 'location'
  ) THEN
    ALTER TABLE public.calendar_events ADD COLUMN location TEXT;
  END IF;
END $$;

-- ============================================================
-- 4. WELL_EVENTS: Make sure all columns exist for proper event handling
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'metadata'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN metadata JSONB DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'latitude'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN latitude DOUBLE PRECISION;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'longitude'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN longitude DOUBLE PRECISION;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'battery_level'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN battery_level INT;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN created_by UUID;
  END IF;
END $$;

-- ============================================================
-- 5. DISABLE RLS on all tables for MVP (ensure all data flows)
-- ============================================================
ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;

-- ============================================================
-- 6. GRANTS: Full access for authenticated + anon for MVP
-- ============================================================
GRANT ALL ON public.locations_safe_zones TO authenticated, anon;
GRANT ALL ON public.calendar_events TO authenticated, anon;
GRANT ALL ON public.check_ins TO authenticated, anon;
GRANT ALL ON public.well_events TO authenticated, anon;
GRANT ALL ON public.profiles TO authenticated, anon;
GRANT ALL ON public.family_members TO authenticated, anon;
GRANT ALL ON public.medications TO authenticated, anon;
GRANT ALL ON public.families TO authenticated, anon;

-- ============================================================
-- 7. REALTIME: Add all tables to realtime publication
-- ============================================================
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.locations_safe_zones;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.calendar_events;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.medications;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.families;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;

-- ============================================================
-- 8. STORAGE BUCKETS: Create manually in Supabase Dashboard
-- ============================================================
-- Go to Supabase Dashboard > Storage:
-- 1. Create bucket 'avatars' (public)
-- 2. Create bucket 'medical_vault' (private)
-- 3. Create bucket 'family_vault' (private)
-- 4. Under each bucket's Policies, add a policy allowing authenticated users
-- ============================================================
-- Well-Check V3: Medication Scheduler Schema
-- Adds scheduling columns to medications and creates dose_logs.
-- Run in Supabase SQL Editor after 20260317_schema_alignment.sql
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- ============================================================
-- 1. ADD SCHEDULING COLUMNS TO MEDICATIONS
-- ============================================================

-- schedule_times: array of HH:MM strings, e.g. {"08:00","20:00"}
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='schedule_times') THEN
    ALTER TABLE public.medications ADD COLUMN schedule_times TEXT[] DEFAULT '{}';
  END IF;
END $$;

-- start_date: when the schedule begins
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='start_date') THEN
    ALTER TABLE public.medications ADD COLUMN start_date DATE DEFAULT CURRENT_DATE;
  END IF;
END $$;

-- end_date: when it ends (null = indefinite/ongoing)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='end_date') THEN
    ALTER TABLE public.medications ADD COLUMN end_date DATE;
  END IF;
END $$;

-- recurrence: daily, every_other_day, weekly, monthly, as_needed
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='recurrence') THEN
    ALTER TABLE public.medications ADD COLUMN recurrence TEXT DEFAULT 'daily';
  END IF;
END $$;

-- days_of_week: for weekly schedules, array of ints 0=Sun..6=Sat
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='days_of_week') THEN
    ALTER TABLE public.medications ADD COLUMN days_of_week INT[] DEFAULT '{}';
  END IF;
END $$;

-- is_active: toggle medications on/off without deleting
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='is_active') THEN
    ALTER TABLE public.medications ADD COLUMN is_active BOOLEAN DEFAULT true;
  END IF;
END $$;

-- ============================================================
-- 2. CREATE DOSE_LOGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.dose_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  medication_id UUID NOT NULL,
  user_id UUID NOT NULL,
  family_id UUID NOT NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  taken_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'pending',  -- pending, taken, missed, skipped
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Disable RLS for MVP
ALTER TABLE public.dose_logs DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON public.dose_logs TO anon, authenticated;

-- Add to realtime
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.dose_logs; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. Run after 20260317_schema_alignment.sql
-- ============================================================
-- ============================================================
-- Well-Check V3: Schema Alignment Fix
-- Fixes column mismatches between initial schema and app code.
-- Run this in Supabase SQL Editor.
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- ============================================================
-- 1. FIX MEDICATIONS TABLE
-- Initial schema: assigned_user_id, name, schedule_time, inventory_count, refill_threshold
-- App expects:    assigned_to, medication_name, frequency, instructions, doctor
-- ============================================================

-- Rename assigned_user_id -> assigned_to (if old column exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='assigned_user_id')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='assigned_to')
  THEN
    ALTER TABLE public.medications RENAME COLUMN assigned_user_id TO assigned_to;
  END IF;
END $$;

-- Rename name -> medication_name (if old column exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='name')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='medication_name')
  THEN
    ALTER TABLE public.medications RENAME COLUMN name TO medication_name;
  END IF;
END $$;

-- Add frequency column (app requires it, old schema had schedule_time instead)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='frequency') THEN
    ALTER TABLE public.medications ADD COLUMN frequency TEXT NOT NULL DEFAULT 'Daily';
  END IF;
END $$;

-- Add instructions column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='instructions') THEN
    ALTER TABLE public.medications ADD COLUMN instructions TEXT;
  END IF;
END $$;

-- Add doctor column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='doctor') THEN
    ALTER TABLE public.medications ADD COLUMN doctor TEXT;
  END IF;
END $$;

-- ============================================================
-- 2. FIX WELL_EVENTS TABLE
-- Initial schema: event_type is an ENUM (heartbeat, sos, etc.)
-- App inserts:    event_type as TEXT ('check_in', 'medication_logged', 'status_update', etc.)
-- ============================================================

-- Change event_type from ENUM to TEXT to allow flexible event types
DO $$
BEGIN
  -- Check if event_type is currently an enum type
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='well_events' AND column_name='event_type'
    AND data_type = 'USER-DEFINED'
  ) THEN
    ALTER TABLE public.well_events ALTER COLUMN event_type TYPE TEXT USING event_type::TEXT;
  END IF;
END $$;

-- Add title column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='well_events' AND column_name='title') THEN
    ALTER TABLE public.well_events ADD COLUMN title TEXT;
  END IF;
END $$;

-- Add description column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='well_events' AND column_name='description') THEN
    ALTER TABLE public.well_events ADD COLUMN description TEXT;
  END IF;
END $$;

-- ============================================================
-- 3. FIX SAFE_ZONES TABLE
-- App code uses 'safe_zones' but command center migration created 'locations_safe_zones'.
-- Initial schema also created 'safe_zones'. Ensure 'safe_zones' exists with expected columns.
-- ============================================================

-- Add zone_name if safe_zones uses 'name' but app expects 'zone_name' (safe_zone_provider uses zone_name)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='safe_zones')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='safe_zones' AND column_name='zone_name')
     AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='safe_zones' AND column_name='name')
  THEN
    ALTER TABLE public.safe_zones RENAME COLUMN name TO zone_name;
  END IF;
END $$;

-- ============================================================
-- 4. FIX CHECK_INS TABLE - ensure it exists with correct columns
-- ============================================================
CREATE TABLE IF NOT EXISTS public.check_ins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  latitude DOUBLE PRECISION DEFAULT 0,
  longitude DOUBLE PRECISION DEFAULT 0,
  status_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- 5. ENSURE PROFILES HAS full_name COLUMN
-- App joins profiles(full_name) but initial schema has first_name/last_name
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='full_name') THEN
    ALTER TABLE public.profiles ADD COLUMN full_name TEXT;
    -- Populate full_name from existing first_name + last_name
    UPDATE public.profiles SET full_name = COALESCE(first_name, '') || ' ' || COALESCE(last_name, '') WHERE full_name IS NULL;
  END IF;
END $$;

-- ============================================================
-- 6. DISABLE RLS ON ALL TABLES (for MVP iteration)
-- ============================================================
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  BEGIN ALTER TABLE public.safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.chat_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.family_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.vault_entries DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.driving_sessions DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
END $$;

-- ============================================================
-- 7. GRANT ALL PERMISSIONS
-- ============================================================
GRANT ALL ON public.medications TO anon, authenticated;
GRANT ALL ON public.well_events TO anon, authenticated;
GRANT ALL ON public.profiles TO anon, authenticated;
GRANT ALL ON public.families TO anon, authenticated;
GRANT ALL ON public.family_members TO anon, authenticated;
GRANT ALL ON public.check_ins TO anon, authenticated;

DO $$
BEGIN
  BEGIN EXECUTE 'GRANT ALL ON public.safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.calendar_events TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.chat_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.family_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.locations_safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.vault_entries TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.driving_sessions TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.health_vitals TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- 8. REALTIME PUBLICATION
-- ============================================================
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.medications; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. Run this in Supabase SQL Editor -> New Query -> Run.
-- ============================================================
-- Campus Watch Configuration: per-user monitoring toggles
-- Allows leaders to configure which notifications they want per family member

CREATE TABLE IF NOT EXISTS campus_watch_config (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  notify_zone_entry BOOLEAN DEFAULT true,
  notify_zone_exit BOOLEAN DEFAULT true,
  notify_campus_alert BOOLEAN DEFAULT true,
  notify_check_in BOOLEAN DEFAULT true,
  is_monitored BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(family_id, user_id)
);

-- Disable RLS for simplicity (same pattern as other tables in this project)
ALTER TABLE campus_watch_config DISABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON campus_watch_config TO anon, authenticated;

-- Add to realtime
ALTER PUBLICATION supabase_realtime ADD TABLE campus_watch_config;
-- Add phone column to profiles for contact lookups
-- Phone is stored in auth.users but we need it accessible from client queries

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;

-- Backfill from auth.users where possible
UPDATE public.profiles p
SET phone = u.phone
FROM auth.users u
WHERE p.id = u.id AND u.phone IS NOT NULL AND p.phone IS NULL;

-- Update the existing auth trigger to also sync phone on new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, phone)
  VALUES (new.id, new.phone)
  ON CONFLICT (id) DO UPDATE SET phone = EXCLUDED.phone;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT ALL ON public.profiles TO anon, authenticated;
-- Create 'avatars' storage bucket for Profile Photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Grant access policies to the bucket
CREATE POLICY "Avatar Public Access" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "Avatar Auth Upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');
CREATE POLICY "Avatar Auth Update" ON storage.objects FOR UPDATE USING (bucket_id = 'avatars' AND auth.role() = 'authenticated');

-- Also, add settings column to profiles to persist privacy choices if they want to sync it
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS settings JSONB DEFAULT '{}';
-- ============================================================
-- Well-Check V3: Medication Cloud Routing
-- Creates Database Triggers & Webhook structures to call
-- the 'push-router' Edge Function for Push Notifications.
-- ============================================================

-- Enable pg_net to make external HTTP requests to Edge Functions
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Create a secure wrapper function to call our Edge Function.
-- NOTE: In production, configure SUPABASE_URL and SERVICE_ROLE_KEY
-- securely via Supabase Vault or custom settings. Replace placeholders here.
CREATE OR REPLACE FUNCTION public.trigger_fcm_push(
  p_target_user_id UUID,
  p_title TEXT,
  p_body TEXT,
  p_action TEXT DEFAULT 'default',
  p_payload TEXT DEFAULT ''
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_url TEXT := current_setting('app.settings.supabase_url', true) || '/functions/v1/push-router';
  v_key TEXT := current_setting('app.settings.service_role_key', true);
  v_body JSONB;
BEGIN
  -- Fallback if variables are not set in database config
  IF v_url IS NULL OR v_url = '/functions/v1/push-router' THEN
    v_url := 'https://lravvptfltbfbfmbhomp.supabase.co/functions/v1/push-router';
  END IF;

  IF v_key IS NULL THEN
    v_key := 'sb_publishable_cw-1FC21PuZXP6KJWdOcdA_ukAYxvaF';
  END IF;

  v_body := jsonb_build_object(
    'target_user_id', p_target_user_id,
    'title', p_title,
    'body', p_body,
    'action', p_action,
    'payload', p_payload
  );

  -- Dispatch async HTTP POST via pg_net
  PERFORM extensions.http_post(
    url := v_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || v_key
    ),
    body := v_body
  );
END;
$$;

-- ============================================================
-- TRIGGERS: Escalate "Dose Taken" to Leaders / Monitors
-- ============================================================

CREATE OR REPLACE FUNCTION public.handle_dose_logged_escalation()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_patient_name TEXT;
  v_med_name TEXT;
  v_member RECORD;
BEGIN
  -- Only trigger for explicit "taken" logs
  IF NEW.status != 'taken' THEN
    RETURN NEW;
  END IF;

  -- 1. Get the patient's name
  SELECT full_name INTO v_patient_name
  FROM public.profiles WHERE id = NEW.user_id;

  -- 2. Get the medication name
  SELECT medication_name INTO v_med_name
  FROM public.medications WHERE id = NEW.medication_id;

  -- 3. Find completely separate users in the same family who are Leaders or Monitors
  FOR v_member IN
    SELECT user_id FROM public.family_members
    WHERE family_id = NEW.family_id
      AND user_id != NEW.user_id
      AND role IN ('leader', 'monitor')
  LOOP
    -- 4. Send FCM Push Notification
    PERFORM public.trigger_fcm_push(
      p_target_user_id := v_member.user_id,
      p_title := '✅ Medication Logged',
      p_body := COALESCE(v_patient_name, 'A member') || ' just logged ' || COALESCE(v_med_name, 'a dose') || '.',
      p_action := 'dose_escalation'
    );
  END LOOP;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_dose_escalation ON public.dose_logs;
CREATE TRIGGER trg_dose_escalation
  AFTER INSERT ON public.dose_logs
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_dose_logged_escalation();

-- ============================================================
-- CRON JOB: Medication Schedule Dispatcher
-- ============================================================

-- NOTE: Ensure pg_cron is enabled in your Supabase Dashboard
-- Database -> Extensions -> search 'pg_cron'

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;

-- Function to check medications and trigger pushes
CREATE OR REPLACE FUNCTION public.dispatch_medication_pushes()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_med RECORD;
  v_now_time TEXT := to_char(now() AT TIME ZONE 'UTC', 'HH24:MI'); -- Using UTC for simplicity in MVP
BEGIN
  -- For every medication that is active
  FOR v_med IN
    SELECT id, assigned_to, medication_name, dosage, schedule_times, instructions
    FROM public.medications
    WHERE is_active = true
      AND schedule_times IS NOT NULL
      AND array_length(schedule_times, 1) > 0
  LOOP
    -- If the current UTC time matches one of the scheduled times
    -- (In production, join with profiles.timezone to do proper local time matching)
    IF v_now_time = ANY(v_med.schedule_times) THEN
      PERFORM public.trigger_fcm_push(
        p_target_user_id := v_med.assigned_to,
        p_title := '💊 Time for ' || v_med.medication_name,
        p_body := v_med.dosage || ' — ' || COALESCE(v_med.instructions, 'Take as prescribed'),
        p_action := 'medication_reminder',
        p_payload := v_med.id::TEXT
      );
    END IF;
  END LOOP;
END;
$$;

-- Schedule it to run every minute
-- Note: cron.schedule may require postgres role depending on Supabase setup
DO $$
BEGIN
  BEGIN
    PERFORM cron.schedule('medication_dispatcher', '* * * * *', 'SELECT public.dispatch_medication_pushes()');
  EXCEPTION WHEN OTHERS THEN
    -- Ignore if permission denied in free tier, instruct user to configure via dashboard
    NULL;
  END;
END $$;

-- ============================================================
-- DONE
-- ============================================================
-- ============================================================
-- Well-Check Fix: well_events missing columns
-- Purpose: Ensures family_id and metadata tracking columns are explicitly bound
-- to prevent Postgrest exceptions during CheckIn and Background Pulses.
-- ============================================================

DO $$
BEGIN
  -- 1. Ensure family_id exists to allow proper family-level streaming in SafetyRepository
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'family_id'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN family_id UUID REFERENCES public.families(id) ON DELETE CASCADE;
  END IF;

  -- 2. Ensure verification_source exists to allow Security Check-ins
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'well_events' AND column_name = 'verification_source'
  ) THEN
    ALTER TABLE public.well_events ADD COLUMN verification_source TEXT;
  END IF;
END $$;
-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- PROFILES: Extended data for authenticated users
CREATE TABLE public.profiles (
  id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  last_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- FAMILIES: The core 'Shield' container
CREATE TABLE public.families (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  name TEXT NOT NULL,
  invite_code VARCHAR(6) UNIQUE,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- FAMILY MEMBERS: Join table managing RBAC within a shield
CREATE TYPE shield_role AS ENUM ('leader', 'monitor', 'senior', 'student', 'pet');
CREATE TYPE member_status AS ENUM ('pending', 'active', 'suspended');

CREATE TABLE public.family_members (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role shield_role NOT NULL,
  status member_status DEFAULT 'pending' NOT NULL,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE(family_id, user_id)
);

-- WELL EVENTS: Immutable ledger for heartbeats, check-ins, SOS, etc.
CREATE TYPE event_type AS ENUM ('heartbeat', 'sos', 'aura_checkin', 'medication_taken', 'geofence_trigger');

CREATE TABLE public.well_events (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  event_type event_type NOT NULL,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  battery_level INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb, -- flexible payload for different events
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  verification_source TEXT,
  PRIMARY KEY (id)
);

-- CHAT MESSAGES: Realtime family hub
CREATE TABLE public.chat_messages (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- MEDICATIONS: Master list of tracked drugs
CREATE TABLE public.medications (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  assigned_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  dosage TEXT NOT NULL,
  schedule_time TIME NOT NULL,
  inventory_count INTEGER DEFAULT 0 NOT NULL,
  refill_threshold INTEGER DEFAULT 5 NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- SAFE ZONES: Geofencing tools
CREATE TABLE public.safe_zones (
  id UUID DEFAULT uuid_generate_v4() NOT NULL,
  family_id UUID NOT NULL REFERENCES public.families(id) ON DELETE CASCADE,
  assigned_user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE, -- Who the zone is tracked for
  name TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  radius_meters INTEGER NOT NULL DEFAULT 500,
  alert_on_entry BOOLEAN DEFAULT true,
  alert_on_exit BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  PRIMARY KEY (id)
);

-- Note: We will add RLS policies in a separate migration step or follow-up file to keep it organized.
-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.safe_zones ENABLE ROW LEVEL SECURITY;

-- Helper Function: Check if user is in a given family
CREATE OR REPLACE FUNCTION public.is_family_member(check_family_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.family_members
    WHERE family_id = check_family_id
    AND user_id = auth.uid()
    AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================
-- 1. PROFILES
-- Users can read profiles in their family. Users can update their own profile.
-- ==========================================
CREATE POLICY "Users can read profiles they share a family with."
ON public.profiles FOR SELECT
USING (
  id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.family_members fm1
    JOIN public.family_members fm2 ON fm1.family_id = fm2.family_id
    WHERE fm1.user_id = auth.uid() AND fm2.user_id = profiles.id AND fm1.status = 'active'
  )
);

CREATE POLICY "Users can update own profile."
ON public.profiles FOR UPDATE
USING (id = auth.uid());

CREATE POLICY "Users can insert their own profile."
ON public.profiles FOR INSERT
WITH CHECK (id = auth.uid());


-- ==========================================
-- 2. FAMILIES
-- Users can see their own families.
-- ==========================================
CREATE POLICY "Users can view families they belong to."
ON public.families FOR SELECT
USING (public.is_family_member(id));

CREATE POLICY "Users can create families."
ON public.families FOR INSERT
WITH CHECK (true);

-- ==========================================
-- 3. FAMILY MEMBERS
-- Users can see members of their families. They can insert their own pending requests.
-- ==========================================
CREATE POLICY "Users can view their family members."
ON public.family_members FOR SELECT
USING (
  user_id = auth.uid() OR
  public.is_family_member(family_id)
);

CREATE POLICY "Users can join families (pending)."
ON public.family_members FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Leaders can update member status."
ON public.family_members FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.family_members
    WHERE family_id = family_members.family_id
    AND user_id = auth.uid()
    AND role = 'leader'
  )
);

-- ==========================================
-- 4. WELL EVENTS
-- Active members can read and insert events for their family.
-- ==========================================
CREATE POLICY "Members can view family events."
ON public.well_events FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Users can insert their own events."
ON public.well_events FOR INSERT
WITH CHECK (user_id = auth.uid() AND public.is_family_member(family_id));


-- ==========================================
-- 5. CHAT MESSAGES
-- Active members can read and write chat to their family.
-- ==========================================
CREATE POLICY "Members can view family chat."
ON public.chat_messages FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can send family chat."
ON public.chat_messages FOR INSERT
WITH CHECK (sender_id = auth.uid() AND public.is_family_member(family_id));


-- ==========================================
-- 6. MEDICATIONS & SAFE ZONES
-- Active members can read details.
-- ==========================================
CREATE POLICY "Members can view family medications."
ON public.medications FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can edit family medications."
ON public.medications FOR ALL
USING (public.is_family_member(family_id));

CREATE POLICY "Members can view safe zones."
ON public.safe_zones FOR SELECT
USING (public.is_family_member(family_id));

CREATE POLICY "Members can edit safe zones."
ON public.safe_zones FOR ALL
USING (public.is_family_member(family_id));
-- 1. Create the function that will be attached to the trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id)
  VALUES (new.id)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Create the trigger on the auth.users table
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 3. Backfill any existing users who signed up before this trigger existed
INSERT INTO public.profiles (id)
SELECT id FROM auth.users
ON CONFLICT (id) DO NOTHING;
-- 403 Forbidden Fix: Grant basic permissions to the 'authenticated' role.
-- Currently, Supabase blocks users before RLS logic even runs because these basic grants
-- were not created automatically since the tables were instantiated manually.

-- Grant usage on the public schema
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Grant permissions to read, update, and insert across all tables for active users
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;

-- Grant full system permissions to the service role (used by auth triggers/server functions)
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
