-- ============================================================
-- Well-Check V3: Schema Alignment Fix
-- Fixes column mismatches between initial schema and app code.
-- Run this in Supabase SQL Editor.
-- Safe to re-run — all statements are idempotent.
-- ============================================================

-- ============================================================
-- 1. FIX MEDICATIONS TABLE
-- Initial schema: assigned_user_id, name, schedule_time, inventory_count, refill_threshold
-- App expects:    assigned_to, medication_name, frequency, instructions, doctor
-- ============================================================

-- Rename assigned_user_id -> assigned_to (if old column exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='assigned_user_id')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='assigned_to')
  THEN
    ALTER TABLE public.medications RENAME COLUMN assigned_user_id TO assigned_to;
  END IF;
END $$;

-- Rename name -> medication_name (if old column exists)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='name')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='medication_name')
  THEN
    ALTER TABLE public.medications RENAME COLUMN name TO medication_name;
  END IF;
END $$;

-- Add frequency column (app requires it, old schema had schedule_time instead)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='frequency') THEN
    ALTER TABLE public.medications ADD COLUMN frequency TEXT NOT NULL DEFAULT 'Daily';
  END IF;
END $$;

-- Add instructions column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='instructions') THEN
    ALTER TABLE public.medications ADD COLUMN instructions TEXT;
  END IF;
END $$;

-- Add doctor column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='medications' AND column_name='doctor') THEN
    ALTER TABLE public.medications ADD COLUMN doctor TEXT;
  END IF;
END $$;

-- ============================================================
-- 2. FIX WELL_EVENTS TABLE
-- Initial schema: event_type is an ENUM (heartbeat, sos, etc.)
-- App inserts:    event_type as TEXT ('check_in', 'medication_logged', 'status_update', etc.)
-- ============================================================

-- Change event_type from ENUM to TEXT to allow flexible event types
DO $$
BEGIN
  -- Check if event_type is currently an enum type
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='well_events' AND column_name='event_type'
    AND data_type = 'USER-DEFINED'
  ) THEN
    ALTER TABLE public.well_events ALTER COLUMN event_type TYPE TEXT USING event_type::TEXT;
  END IF;
END $$;

-- Add title column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='well_events' AND column_name='title') THEN
    ALTER TABLE public.well_events ADD COLUMN title TEXT;
  END IF;
END $$;

-- Add description column
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='well_events' AND column_name='description') THEN
    ALTER TABLE public.well_events ADD COLUMN description TEXT;
  END IF;
END $$;

-- ============================================================
-- 3. FIX SAFE_ZONES TABLE
-- App code uses 'safe_zones' but command center migration created 'locations_safe_zones'.
-- Initial schema also created 'safe_zones'. Ensure 'safe_zones' exists with expected columns.
-- ============================================================

-- Add zone_name if safe_zones uses 'name' but app expects 'zone_name' (safe_zone_provider uses zone_name)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='safe_zones')
     AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='safe_zones' AND column_name='zone_name')
     AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='safe_zones' AND column_name='name')
  THEN
    ALTER TABLE public.safe_zones RENAME COLUMN name TO zone_name;
  END IF;
END $$;

-- ============================================================
-- 4. FIX CHECK_INS TABLE - ensure it exists with correct columns
-- ============================================================
CREATE TABLE IF NOT EXISTS public.check_ins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL,
  user_id UUID NOT NULL,
  latitude DOUBLE PRECISION DEFAULT 0,
  longitude DOUBLE PRECISION DEFAULT 0,
  status_message TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- 5. ENSURE PROFILES HAS full_name COLUMN
-- App joins profiles(full_name) but initial schema has first_name/last_name
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='full_name') THEN
    ALTER TABLE public.profiles ADD COLUMN full_name TEXT;
    -- Populate full_name from existing first_name + last_name
    UPDATE public.profiles SET full_name = COALESCE(first_name, '') || ' ' || COALESCE(last_name, '') WHERE full_name IS NULL;
  END IF;
END $$;

-- ============================================================
-- 6. DISABLE RLS ON ALL TABLES (for MVP iteration)
-- ============================================================
ALTER TABLE public.medications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.well_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.families DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.family_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.check_ins DISABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  BEGIN ALTER TABLE public.safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.calendar_events DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.chat_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.family_messages DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.locations_safe_zones DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.vault_entries DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.driving_sessions DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
  BEGIN ALTER TABLE public.health_vitals DISABLE ROW LEVEL SECURITY; EXCEPTION WHEN undefined_table THEN NULL; END;
END $$;

-- ============================================================
-- 7. GRANT ALL PERMISSIONS
-- ============================================================
GRANT ALL ON public.medications TO anon, authenticated;
GRANT ALL ON public.well_events TO anon, authenticated;
GRANT ALL ON public.profiles TO anon, authenticated;
GRANT ALL ON public.families TO anon, authenticated;
GRANT ALL ON public.family_members TO anon, authenticated;
GRANT ALL ON public.check_ins TO anon, authenticated;

DO $$
BEGIN
  BEGIN EXECUTE 'GRANT ALL ON public.safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.calendar_events TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.chat_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.family_messages TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.locations_safe_zones TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.vault_entries TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.driving_sessions TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE 'GRANT ALL ON public.health_vitals TO anon, authenticated'; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- 8. REALTIME PUBLICATION
-- ============================================================
DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.medications; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.well_events; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.check_ins; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.family_members; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;

-- ============================================================
-- DONE. Run this in Supabase SQL Editor -> New Query -> Run.
-- ============================================================
