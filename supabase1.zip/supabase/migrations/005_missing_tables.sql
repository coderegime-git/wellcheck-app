-- ============================================================
-- Well-Check V3: Missing Tables for Check-ins & Workflows
-- Run this in Supabase SQL Editor after 004_elite_schema_alignment.sql
-- ============================================================

-- 1. CHECK_INS — Manual broadcast signals
CREATE TABLE IF NOT EXISTS check_ins (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  family_id uuid NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  latitude double precision,
  longitude double precision,
  status_message text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE check_ins DISABLE ROW LEVEL SECURITY;
GRANT ALL ON check_ins TO anon, authenticated;

-- 2. Ensure well_events has title + description columns (additive)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'title') THEN
    ALTER TABLE well_events ADD COLUMN title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'description') THEN
    ALTER TABLE well_events ADD COLUMN description text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'well_events' AND column_name = 'created_by') THEN
    ALTER TABLE well_events ADD COLUMN created_by uuid;
  END IF;
END $$;

-- ============================================================
-- Run in Supabase SQL Editor
-- ============================================================
