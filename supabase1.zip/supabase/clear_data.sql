-- This script truncates all active tables and removes all test users.
-- RUN THIS IN THE SUPABASE SQL EDITOR

-- 1. Wipe all relational tables with CASCADE to ignore foreign key blocks temporarily
TRUNCATE TABLE public.well_events CASCADE;
TRUNCATE TABLE public.family_invites CASCADE;
TRUNCATE TABLE public.family_members CASCADE;
TRUNCATE TABLE public.families CASCADE;
TRUNCATE TABLE public.profiles CASCADE;

-- 2. Clear Auth users natively (Requires Supabase schema permissions)
-- This removes all registered users so you can make clean accounts
DELETE FROM auth.users;

-- Note: In Supabase, deleting from auth.users automatically triggers the generic 
-- delete cascades to profiles if set up, but the TRUNCATES above ensure 
-- a completely clean slate regardless!
