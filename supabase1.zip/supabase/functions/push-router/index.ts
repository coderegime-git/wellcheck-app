import "https://esm.sh/@supabase/functions-js/src/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { JWT } from "npm:google-auth-library@9";

const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  // Gracefully handle browser pings
  if (req.method === 'GET') {
    return new Response(JSON.stringify({ status: "push-router is online" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { target_user_id, title, body, payload, action } = await req.json();

    if (!target_user_id) {
      throw new Error("target_user_id is required");
    }

    // 1. Fetch the target user's FCM token from profiles
    const { data: profile, error: profileErr } = await supabase
      .from("profiles")
      .select("fcm_token")
      .eq("id", target_user_id)
      .single();

    if (profileErr || !profile?.fcm_token) {
      console.log(`No FCM token found for user ${target_user_id}`);
      return new Response(JSON.stringify({ success: false, error: "No token" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const token = profile.fcm_token;

    // 2. Load the Service Account JSON directly from Secrets
    const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT");
    if (!serviceAccountRaw) {
      throw new Error("FIREBASE_SERVICE_ACCOUNT secret is missing");
    }
    const credentials = JSON.parse(serviceAccountRaw);

    // 3. Generate a lightweight OAuth Token using google-auth-library
    const jwtClient = new JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ["https://www.googleapis.com/auth/firebase.messaging"],
    });

    const accessToken = await jwtClient.getAccessToken();

    // 4. Dispatch using the raw FCM V1 REST API
    const message = {
      message: {
        token: token,
        notification: {
          title: title,
          body: body,
        },
        data: {
          click_action: "FLUTTER_NOTIFICATION_CLICK",
          action: action || "default",
          payload: payload || ""
        },
        apns: {
          payload: {
            aps: {
              "mutable-content": 1,
              sound: "default",
              category: action === "medication_reminder" ? "medication_category" : undefined,
            }
          }
        }
      }
    };

    const fcmRes = await fetch(
      `https://fcm.googleapis.com/v1/projects/${credentials.project_id}/messages:send`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken.token}`,
        },
        body: JSON.stringify(message),
      }
    );

    const fcmResult = await fcmRes.json();

    if (!fcmRes.ok) {
      console.error("FCM Send Error Payload:", fcmResult);
      throw new Error(`FCM API Error: ${fcmRes.statusText}`);
    }

    return new Response(JSON.stringify({ success: true, result: fcmResult }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("Router Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
