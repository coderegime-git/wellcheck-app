// Supabase Edge Function: aura_ai
// Handles logic for the Aura Voice Assistant feature.
// Takes recognized text input from the Flutter app's STT, queries OpenAI, and returns a natural response.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY')

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders })
    }

    try {
        const { prompt, context } = await req.json()

        if (!prompt) {
            throw new Error('Prompt is required.')
        }

        if (!OPENAI_API_KEY) {
            throw new Error('OpenAI API key not configured.')
        }

        // System prompt defines Aura's personality and restrictions
        const systemPrompt = `
      You are Aura, an empathetic, concise, and helpful AI assistant for the Well-Check family safety app.
      Your primary goal is to help seniors stay safe, assist students with check-ins, and allow monitoring parents quick updates.
      Keep your responses extremely short (under 2 sentences) because they will be read aloud via Text-to-Speech to the user.
      Current App Context provided by device: ${context || 'None'}
    `

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${OPENAI_API_KEY}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: prompt }
                ],
                max_tokens: 150,
                temperature: 0.5,
            }),
        })

        const result = await response.json()
        const auraReply = result.choices?.[0]?.message?.content?.trim() || "I'm sorry, I couldn't process that right now."

        return new Response(JSON.stringify({
            success: true,
            reply: auraReply
        }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 200,
        })

    } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 400,
        })
    }
})
