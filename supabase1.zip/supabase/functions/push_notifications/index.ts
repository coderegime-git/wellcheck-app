// Supabase Edge Function: push_notifications
// Triggered via Database Webhook on `well_events` insert when event_type = 'sos'

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

// You would typically use a library like 'firebase-admin' or fetch directly to FCM REST API
// For this MVP, we outline the logic using a generic fetch approach to Expo Push or Firebase

serve(async (req) => {
    try {
        // 1. Parse the Webhook payload from Supabase
        const payload = await req.json()
        const record = payload.record

        // Only process 'sos' events just in case the webhook filter wasn't set correctly
        if (record.event_type !== 'sos') {
            return new Response(JSON.stringify({ message: "Not an SOS event, ignoring." }), {
                headers: { "Content-Type": "application/json" },
                status: 200,
            })
        }

        const familyId = record.family_id
        const initiatorId = record.user_id

        // 2. Initialize Supabase Admin Client to bypass RLS and fetch family members
        const supabaseAdmin = createClient(
            Deno.env.get('SUPABASE_URL') ?? '',
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
        )

        // Fetch the name of the user who triggered the SOS
        const { data: profile } = await supabaseAdmin
            .from('profiles')
            .select('display_name')
            .eq('id', initiatorId)
            .single()

        const initiatorName = profile?.display_name ?? 'A member'

        // Fetch all active members of the family to send the notification
        const { data: familyMembers, error: memberError } = await supabaseAdmin
            .from('family_members')
            .select(`
        user_id,
        role,
        profiles (
          id,
          push_token
        )
      `)
            .eq('family_id', familyId)
            .eq('status', 'active')

        if (memberError || !familyMembers) {
            throw new Error(`Failed to fetch family members: ${memberError?.message}`)
        }

        // 3. Extract tokens
        const tokens = familyMembers
            .map(member => member.profiles?.push_token)
            .filter(token => token != null && token !== '') // filter out empty tokens

        if (tokens.length === 0) {
            return new Response(JSON.stringify({ message: "No valid registered push tokens found for family." }), {
                headers: { "Content-Type": "application/json" },
                status: 200,
            })
        }

        // 4. Send the push notification (Using Expo Push API as an example, easily swapped to FCM)
        const title = "EMERGENCY: Shield SOS Triggered!"
        const body = `${initiatorName} has triggered an SOS alert. Please check the Monitor view immediately.`

        // Send logic via Expo
        const expoTokens = tokens // assuming they are Expo push tokens
        const messages = expoTokens.map(token => ({
            to: token,
            sound: 'default',
            title: title,
            body: body,
            data: { eventId: record.id, familyId: familyId, type: 'sos_alert' },
        }))

        const pushResponse = await fetch('https://exp.host/--/api/v2/push/send', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Accept-encoding': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(messages),
        })

        const pushResult = await pushResponse.json()

        return new Response(JSON.stringify({
            success: true,
            sent_count: tokens.length,
            push_result: pushResult,
        }), {
            headers: { "Content-Type": "application/json" },
            status: 200,
        })

    } catch (error) {
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { "Content-Type": "application/json" },
            status: 400,
        })
    }
})
