import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async () => {
  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const now = new Date();

    const currentDate =
      now.toISOString().split("T")[0];

    const currentTime =
      now.toTimeString().split(" ")[0];

    const { data: schedules, error } =
      await supabase
        .from("checkin_schedules")
        .select("*")
        .eq("is_active", true)
        .eq("is_completed", false)
        .eq("reminder_sent", false)
        .eq("checkin_date", currentDate)
        .lte("checkin_time", currentTime);

    if (error) {
      throw error;
    }

    for (const schedule of schedules) {
      // Send push notification
      await supabase.functions.invoke(
        "push-router",
        {
          body: {
            target_user_id:
              schedule.assigned_user_id,

            title: "⏰ Check-In Reminder",

            body:
              "It's time to complete your check-in.",

            action: "checkin_reminder",

            schedule,
          },
        }
      );

      // Mark as sent
      await supabase
        .from("checkin_schedules")
        .update({
          reminder_sent: true,
          reminder_sent_at:
            new Date().toISOString(),
        })
        .eq("id", schedule.id);
    }

    return new Response(
      JSON.stringify({
        success: true,
        sent: schedules.length,
      }),
      {
        headers: {
          "Content-Type":
            "application/json",
        },
      }
    );
  } catch (e) {
    return new Response(
      JSON.stringify({
        error: e.message,
      }),
      {
        status: 500,
      }
    );
  }
});