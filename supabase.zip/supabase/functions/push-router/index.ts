// import "https://esm.sh/@supabase/functions-js/src/edge-runtime.d.ts";
// import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
// import { JWT } from "npm:google-auth-library@9";
//
// const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
// const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
//
// Deno.serve(async (req) => {
//   const corsHeaders = {
//     'Access-Control-Allow-Origin': '*',
//     'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
//   };
//
//   if (req.method === 'OPTIONS') {
//     return new Response('ok', { headers: corsHeaders });
//   }
//
//   if (req.method === 'GET') {
//     return new Response(JSON.stringify({ status: "push-router is online" }), {
//       headers: { ...corsHeaders, "Content-Type": "application/json" },
//       status: 200,
//     });
//   }
//
//   try {
//     const supabase = createClient(supabaseUrl, supabaseServiceKey);
//   //  const { target_user_id, title, body, payload, action } = await req.json();
// Deno.serve(async (req) => {
//   const corsHeaders = {
//     'Access-Control-Allow-Origin': '*',
//     'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
//   };
//
//   if (req.method === 'OPTIONS') {
//     return new Response('ok', { headers: corsHeaders });
//   }
//
//   if (req.method === 'GET') {
//     return new Response(JSON.stringify({ status: "push-router is online" }), {
//       headers: { ...corsHeaders, "Content-Type": "application/json" },
//       status: 200,
//     });
//   }
//
//   try {
//     const supabase = createClient(supabaseUrl, supabaseServiceKey);
//
//     // 👇 ✅ ADD THIS HERE
//     let requestData;
//
//     try {
//       const text = await req.text();
//
//       if (!text || text.trim() === "") {
//         return new Response(JSON.stringify({ error: "Empty body" }), {
//           status: 400,
//         });
//       }
//
//       requestData = JSON.parse(text);
//     } catch (e) {
//       return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
//         status: 400,
//       });
//     }
//
//     const { target_user_id, title, body, payload, action } = requestData;
//     // 👆 END HERE
//
//     if (!target_user_id) {
//       throw new Error("target_user_id is required");
//     }
//
//     // rest of your code...
//     if (!target_user_id) {
//       throw new Error("target_user_id is required");
//     }
//
//     const { data: profile } = await supabase
//       .from("profiles")
//       .select("fcm_token")
//       .eq("id", target_user_id)
//       .single();
//
//     if (!profile?.fcm_token) {
//       return new Response(JSON.stringify({ success: false, error: "No token" }), {
//         headers: { ...corsHeaders, "Content-Type": "application/json" },
//         status: 400,
//       });
//     }
//
//     const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT");
//     const credentials = JSON.parse(serviceAccountRaw!);
//
//     const jwtClient = new JWT({
//       email: credentials.client_email,
//       key: credentials.private_key,
//       scopes: ["https://www.googleapis.com/auth/firebase.messaging"],
//     });
//
//     const accessToken = await jwtClient.getAccessToken();
//
//     const message = {
//       message: {
//         token: profile.fcm_token,
//         notification: { title, body },
//         data: {
//           click_action: "FLUTTER_NOTIFICATION_CLICK",
//           action: action || "default",
//           payload: payload || ""
//         }
//       }
//     };
//
//     const fcmRes = await fetch(
//       `https://fcm.googleapis.com/v1/projects/${credentials.project_id}/messages:send`,
//       {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//           Authorization: `Bearer ${accessToken.token}`,
//         },
//         body: JSON.stringify(message),
//       }
//     );
//
//     const result = await fcmRes.json();
//
//     return new Response(JSON.stringify({ success: true, result }), {
//       headers: { ...corsHeaders, "Content-Type": "application/json" },
//       status: 200,
//     });
//
//   } catch (error) {
//     return new Response(JSON.stringify({ error: error.message }), {
//       headers: { "Content-Type": "application/json" },
//       status: 500,
//     });
//   }
// });

import "https://esm.sh/@supabase/functions-js/src/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import { JWT } from "npm:google-auth-library@9";

const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

Deno.serve(async (req) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method === "GET") {
    return new Response(
      JSON.stringify({ status: "push-router is online" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // ── Safe JSON parsing ────────────────────────────────────────────
    let requestData: {
      target_user_id: string;
      title?: string;
      body?: string;
      payload?: string;
      action?: string;
      schedule?: string;
    };

    try {
      const text = await req.text();
      if (!text || text.trim() === "") {
        return new Response(JSON.stringify({ error: "Empty body" }), { status: 400 });
      }
      requestData = JSON.parse(text);
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400 });
    }

    const { target_user_id, title, body, payload, action, schedule } = requestData;

    if (!target_user_id) {
      throw new Error("target_user_id is required");
    }

    // ── Get FCM token ────────────────────────────────────────────────
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("fcm_token")
      .eq("id", target_user_id)
      .single();

    if (profileError || !profile?.fcm_token) {
      return new Response(
        JSON.stringify({ success: false, error: "No FCM token found for user" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }

    // ── Firebase auth ────────────────────────────────────────────────
    const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT");
    if (!serviceAccountRaw) throw new Error("FIREBASE_SERVICE_ACCOUNT env not set");

    const credentials = JSON.parse(serviceAccountRaw);

    const jwtClient = new JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ["https://www.googleapis.com/auth/firebase.messaging"],
    });

    const accessToken = await jwtClient.getAccessToken();

    // ── Build FCM message ────────────────────────────────────────────
    // If title is provided → show a visible notification immediately.
    // If no title → silent data-only message (background handler schedules locally).
    const fcmMessage: Record<string, unknown> = {
      token: profile.fcm_token,

      // Data payload — always included so background handler can act on it
      data: {
        action: action ?? "",
        schedule: schedule ?? "",
        payload: payload ?? "",
      },

      // Android: high priority wakes the device even in doze mode
      android: {
        priority: "high",
        ...(title && {
          notification: {
            title,
            body: body ?? "",
            click_action: "FLUTTER_NOTIFICATION_CLICK",
          },
        }),
      },

      // iOS: content-available=1 wakes the app silently for data messages
      apns: {
        headers: {
          "apns-priority": title ? "10" : "5", // 10 = immediate, 5 = silent
        },
        payload: {
          aps: {
            "content-available": 1,
            ...(title && {
              alert: { title, body: body ?? "" },
              sound: "default",
            }),
          },
        },
      },
    };

    // Only add top-level notification for non-Android/iOS (web etc.) if title given
    if (title) {
      (fcmMessage as Record<string, unknown>).notification = {
        title,
        body: body ?? "",
      };
    }

    console.log("[push-router] Sending FCM message:", JSON.stringify(fcmMessage));

    const fcmRes = await fetch(
      `https://fcm.googleapis.com/v1/projects/${credentials.project_id}/messages:send`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken.token}`,
        },
        body: JSON.stringify({ message: fcmMessage }),
      }
    );

    const result = await fcmRes.json();

    if (!fcmRes.ok) {
      console.error("[push-router] FCM error:", JSON.stringify(result));
      return new Response(
        JSON.stringify({ success: false, error: result }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
      );
    }

    console.log("[push-router] FCM success:", JSON.stringify(result));

    return new Response(
      JSON.stringify({ success: true, result }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );

  } catch (error) {
    console.error("[push-router] Exception:", error.message);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { "Content-Type": "application/json" }, status: 500 }
    );
  }
});