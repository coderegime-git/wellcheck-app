// life360_location_service.dart
//
// Two responsibilities:
//   1. Track THIS device's GPS (lat/lng/speed/heading) and push updates
//      to your backend so other members can see you.
//   2. Listen for ALL members' latest locations and expose them as a
//      Stream<List<MemberLocation>> that Life360MapScreen can consume directly.
//
// Dependencies (pubspec.yaml):
//   geolocator: ^13.0.0
//   supabase_flutter: ^2.8.0   // swap for your own backend client if different
//
// Backend table assumed (Supabase/Postgres), adjust names to match yours:
//
//   create table member_locations (
//     user_id      uuid primary key references auth.users(id),
//     name         text not null,
//     avatar_url   text,
//     color_hex    text,               -- e.g. '#2196F3'
//     latitude     double precision not null,
//     longitude    double precision not null,
//     speed_kmh    double precision not null default 0,
//     heading      double precision,
//     battery_pct  double precision,
//     address      text,
//     status       text,               -- 'driving' | 'walking' | 'stopped'
//     updated_at   timestamptz not null default now()
//   );
//
//   -- enable Realtime on this table in Supabase dashboard, and RLS policies
//   -- so members can only read locations within their own group/org.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../features/dashboard/widgets/life360_screen.dart';

class Life360LocationService {
  Life360LocationService(this._supabase);

  final SupabaseClient _supabase;
  StreamSubscription<Position>? _gpsSub;
  RealtimeChannel? _channel;

  // ---------------------------------------------------------------------
  // 1. CAPTURE + PUSH this device's own location
  // ---------------------------------------------------------------------

  /// Call once (e.g. in initState of your home screen, or a background
  /// service) after checking/requesting location permission.

  void stopSharingMyLocation() {
    _gpsSub?.cancel();
    _gpsSub = null;
  }

  Future<void> startSharingMyLocation({
    required String name,
    double? batteryPct,
  }) async {
    final permission = await _ensurePermission();
    if (!permission) return;

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 55,
    );
    print("asasasa");
    _gpsSub = Geolocator.getPositionStream(
      locationSettings: settings,
    ).listen((pos) => _pushMyPosition(pos, name: name, batteryPct: batteryPct));
  }

  Future<void> _pushMyPosition(
    Position pos, {
    required String name,
    double? batteryPct,
  }) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    final speedKmh = (pos.speed.isFinite ? pos.speed : 0) * 3.6;
    final prefs = await SharedPreferences.getInstance();
    final familyId = prefs.getString('last_family_id');
    final avatar = prefs.getString('last_user_profile');

    await _supabase.from('member_locations').upsert({
      'user_id': userId,
      'family_id': familyId,
      'name': name,
      'avatar': avatar,
      'latitude': pos.latitude,
      'longitude': pos.longitude,
      'speed_kmh': speedKmh,
      'heading': pos.heading,
      'battery_pct': batteryPct,
      'status': speedKmh < 1
          ? 'stopped'
          : speedKmh < 8
          ? 'walking'
          : 'driving',
      'updated_at': DateTime.now().toIso8601String(),
    });
  }

  Future<bool> _ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    return perm == LocationPermission.always ||
        perm == LocationPermission.whileInUse;
  }

  // ---------------------------------------------------------------------
  // 2. LISTEN for everyone's latest locations -> feed Life360MapScreen
  // ---------------------------------------------------------------------

  final _membersController = StreamController<List<MemberLocation>>.broadcast();

  /// Stream of the full member list, updated live as anyone moves.
  /// Pass this straight into a StreamBuilder<List<MemberLocation>> that
  /// builds Life360MapScreen.
  Stream<List<MemberLocation>> watchMembers(String familyId) {
    _loadInitial(familyId);
    _channel ??= _supabase
        .channel('member_locations_changes')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'member_locations',
          filter: PostgresChangeFilter(
            // ← add
            type: PostgresChangeFilterType.eq,
            column: 'family_id',
            value: familyId,
          ),
          callback: (_) => _loadInitial(familyId),
        )
        .subscribe();
    return _membersController.stream;
  }

  Future<void> _loadInitial(String familyId) async {
    final rows = await _supabase
        .from('member_locations')
        .select()
        .eq('family_id', familyId); // ← add
    _membersController.add(rows.map(_rowToMemberLocation).toList());
  }

  MemberLocation _rowToMemberLocation(Map<String, dynamic> row) {
    return MemberLocation(
      id: row['user_id'] as String,
      name: (row['name'] as String?) ?? 'Member',
      avatarUrl: row['avatar'] as String?,
      color: _colorFromHex(row['color_hex'] as String?),
      latitude: (row['latitude'] as num).toDouble(),
      longitude: (row['longitude'] as num).toDouble(),
      speedKmh: (row['speed_kmh'] as num?)?.toDouble() ?? 0,
      headingDegrees: (row['heading'] as num?)?.toDouble(),
      batteryPercent: (row['battery_pct'] as num?)?.toDouble(),
      address: row['address'] as String?,
      status: _statusFromString(row['status'] as String?),
      lastUpdated:
          DateTime.tryParse(row['updated_at'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  Color _colorFromHex(String? hex) {
    if (hex == null || hex.isEmpty) return Colors.blue;
    final clean = hex.replaceFirst('#', '');
    return Color(int.parse('FF$clean', radix: 16));
  }

  MovementStatus _statusFromString(String? s) {
    switch (s) {
      case 'driving':
        return MovementStatus.driving;
      case 'walking':
        return MovementStatus.walking;
      case 'stopped':
        return MovementStatus.stopped;
      default:
        return MovementStatus.unknown;
    }
  }

  void dispose() {
    _gpsSub?.cancel();
    _channel?.unsubscribe();
    _membersController.close();
  }
}
