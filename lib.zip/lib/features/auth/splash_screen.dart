import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/referral_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      // Initialize deep-link handling first

      //  await ReferralService.instance.initialize();

      // Give the deep-link processing a moment to complete
      await Future.delayed(const Duration(milliseconds: 500));

      if (!mounted) return;

      // Now continue your normal app flow
      _goToNextScreen();
    } catch (e) {
      debugPrint('Splash initialization error: $e');

      if (!mounted) return;

      _goToNextScreen();
    }
  }

  void _goToNextScreen() {
    // Your existing authentication/navigation logic

    context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Image.asset('assets/logo.png', width: 150)),
    );
  }
}
