// life360_map_screen.dart
//
// A Life360-style "family/group map" screen for Flutter.
//
// Shows:
//  - Google Map with a marker per member (colored avatar-style pin)
//  - Draggable bottom sheet with member details: speed, address,
//    last updated, battery %, driving/stopped status
//  - Horizontal member chip list at the top to quickly jump to a member
//  - Recenter / "show all members" FAB
//
// Dependencies (add to pubspec.yaml):
//   google_maps_flutter: ^2.9.0
//   geocoding: ^3.0.0         // for reverse-geocoding lat/lng -> address (optional)
//   intl: ^0.19.0             // for "last updated" time formatting
//
// Wire `MemberLocation` up to your own realtime source (Supabase Realtime,
// Firebase, socket, polling API, etc.) — just push updated MemberLocation
// objects into `onMembersChanged` / update `_members` and call setState,
// or convert `_members` to a Stream/ValueNotifier if you prefer.

import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';

// ---------------------------------------------------------------------------
// MODEL
// ---------------------------------------------------------------------------

enum MovementStatus { stopped, walking, driving, unknown }

class MemberLocation {
  final String id;
  final String name;
  final String? avatarUrl;
  final Color color;
  final double latitude;
  final double longitude;
  final double speedKmh; // current speed in km/h
  final double? headingDegrees; // 0-360, for rotating the marker
  final double? batteryPercent; // 0-100
  final DateTime lastUpdated;
  final String? address; // pre-resolved address, if you have one
  final MovementStatus status;

  const MemberLocation({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.speedKmh,
    required this.lastUpdated,
    this.avatarUrl,
    this.color = Colors.blue,
    this.headingDegrees,
    this.batteryPercent,
    this.address,
    this.status = MovementStatus.unknown,
  });

  LatLng get position => LatLng(latitude, longitude);

  MovementStatus get effectiveStatus {
    if (status != MovementStatus.unknown) return status;
    if (speedKmh < 1) return MovementStatus.stopped;
    if (speedKmh < 8) return MovementStatus.walking;
    return MovementStatus.driving;
  }
}

// ---------------------------------------------------------------------------
// SCREEN
// ---------------------------------------------------------------------------

class Life360MapScreen extends StatefulWidget {
  const Life360MapScreen({
    super.key,
    required this.members,
    this.onRefresh,
    this.speedUnitKmh = true,
  });

  /// Current members to plot on the map. Pass an updated list (e.g. from a
  /// realtime stream) and this widget will animate/update markers.
  final List<MemberLocation> members;

  /// Called when the user pulls to refresh / taps the refresh action.
  final Future<void> Function()? onRefresh;

  /// true = show speed in km/h, false = show mph.
  final bool speedUnitKmh;

  @override
  State<Life360MapScreen> createState() => _Life360MapScreenState();
}

class _Life360MapScreenState extends State<Life360MapScreen> {
  GoogleMapController? _mapController;
  String? _selectedMemberId;
  final DraggableScrollableController _sheetController =
      DraggableScrollableController();

  @override
  void didUpdateWidget(covariant Life360MapScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Keep selection valid if a member disappears from the list.
    if (_selectedMemberId != null &&
        widget.members.every((m) => m.id != _selectedMemberId)) {
      _selectedMemberId = widget.members.isNotEmpty
          ? widget.members.first.id
          : null;
    } else if (_selectedMemberId == null && widget.members.isNotEmpty) {
      _selectedMemberId = widget.members.first.id;
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.members.isNotEmpty) {
      _selectedMemberId = widget.members.first.id;
    }
  }

  MemberLocation? get _selectedMember {
    if (_selectedMemberId == null) return null;
    try {
      return widget.members.firstWhere((m) => m.id == _selectedMemberId);
    } catch (_) {
      return null;
    }
  }

  Future<void> _focusMember(MemberLocation member, {double zoom = 16}) async {
    setState(() => _selectedMemberId = member.id);
    await _mapController?.animateCamera(
      CameraUpdate.newLatLngZoom(member.position, zoom),
    );
    _sheetController.animateTo(
      0.32,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  Future<void> _fitAllMembers() async {
    if (widget.members.isEmpty || _mapController == null) return;
    if (widget.members.length == 1) {
      await _focusMember(widget.members.first);
      return;
    }
    double minLat = widget.members.first.latitude;
    double maxLat = widget.members.first.latitude;
    double minLng = widget.members.first.longitude;
    double maxLng = widget.members.first.longitude;
    for (final m in widget.members) {
      minLat = math.min(minLat, m.latitude);
      maxLat = math.max(maxLat, m.latitude);
      minLng = math.min(minLng, m.longitude);
      maxLng = math.max(maxLng, m.longitude);
    }
    await _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLng),
          northeast: LatLng(maxLat, maxLng),
        ),
        60,
      ),
    );
  }

  Set<Marker> _buildMarkers() {
    return widget.members.map((m) {
      final isSelected = m.id == _selectedMemberId;
      return Marker(
        markerId: MarkerId(m.id),
        position: m.position,
        rotation: m.headingDegrees ?? 0,
        anchor: const Offset(0.5, 0.5),
        zIndex: isSelected ? 2 : 1,
        icon: BitmapDescriptor.defaultMarkerWithHue(_hueForColor(m.color)),
        onTap: () => _focusMember(m, zoom: 16),
        infoWindow: InfoWindow(title: m.name, snippet: _statusLabel(m)),
      );
    }).toSet();
  }

  double _hueForColor(Color c) {
    final hsl = HSLColor.fromColor(c);
    return hsl.hue;
  }

  String _statusLabel(MemberLocation m) {
    final speed = widget.speedUnitKmh
        ? '${m.speedKmh.toStringAsFixed(0)} km/h'
        : '${(m.speedKmh * 0.621371).toStringAsFixed(0)} mph';
    switch (m.effectiveStatus) {
      case MovementStatus.driving:
        return 'Driving • $speed';
      case MovementStatus.walking:
        return 'Walking • $speed';
      case MovementStatus.stopped:
        return 'Stopped';
      case MovementStatus.unknown:
        return speed;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: widget.members.isNotEmpty
                    ? widget.members.first.position
                    : const LatLng(9.9252, 78.1198), // fallback: Madurai
                zoom: 12,
              ),
              markers: _buildMarkers(),
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              onMapCreated: (c) {
                _mapController = c;
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _fitAllMembers();
                });
              },
            ),

            //     Top member chip strip.
            SafeArea(
              child: SizedBox(
                height: 84,
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  scrollDirection: Axis.horizontal,
                  itemCount: widget.members.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, i) {
                    final m = widget.members[i];
                    final isSelected = m.id == _selectedMemberId;
                    return GestureDetector(
                      onTap: () => _focusMember(m),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: isSelected
                                      ? m.color
                                      : Colors.transparent,
                                  width: 2.5,
                                ),
                              ),
                              child: CircleAvatar(
                                radius: 24,
                                backgroundColor: m.color.withValues(
                                  alpha: 0.15,
                                ),
                                backgroundImage: m.avatarUrl != null
                                    ? NetworkImage(m.avatarUrl!)
                                    : null,
                                child: m.avatarUrl == null
                                    ? Text(
                                        m.name.isNotEmpty
                                            ? m.name[0].toUpperCase()
                                            : '?',
                                        style: TextStyle(
                                          color: m.color,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      )
                                    : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          SizedBox(
                            width: 70,
                            child: Text(
                              m.name,
                              maxLines: 1,
                              textAlign: TextAlign.center,
                              style: theme.textTheme.labelSmall?.copyWith(
                                color: Platform.isIOS
                                    ? Colors.white
                                    : Colors.black,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
            DraggableScrollableSheet(
              controller: _sheetController,
              initialChildSize: 0.32,
              minChildSize: 0.14,
              maxChildSize: 0.62,
              builder: (context, scrollController) {
                final m = _selectedMember;
                return Material(
                  color: Colors.white,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                  // decoration: BoxDecoration(
                  //   color: theme.colorScheme.surface,
                  //   borderRadius: const BorderRadius.vertical(
                  //     top: Radius.circular(20),
                  //   ),
                  //   boxShadow: const [
                  //     BoxShadow(color: Colors.black26, blurRadius: 12),
                  //   ],
                  // ),
                  child: ListView(
                    controller: scrollController,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: theme.dividerColor,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      if (m == null)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 24),
                          child: Center(child: Text('No member selected')),
                        )
                      else
                        _MemberDetailCard(
                          member: m,
                          speedUnitKmh: widget.speedUnitKmh,
                        ),
                      if (widget.members.length > 1) ...[
                        const SizedBox(height: 20),
                        Text('All members', style: theme.textTheme.titleSmall),
                        const SizedBox(height: 8),
                        ...widget.members.map(
                          (mem) => _MemberListTile(
                            member: mem,
                            selected: mem.id == _selectedMemberId,
                            speedUnitKmh: widget.speedUnitKmh,
                            onTap: () => _focusMember(mem),
                          ),
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
            // Recenter / fit-all FAB.
            Positioned(
              right: 16,
              bottom: 0,
              child: SafeArea(
                minimum: const EdgeInsets.only(bottom: 260),
                child: FloatingActionButton.small(
                  heroTag: 'life360-fit-all',
                  onPressed: _fitAllMembers,
                  child: const Icon(Icons.center_focus_strong),
                ),
              ),
            ),
          ],
        ),

        // Bottom detail sheet.
        // bottomSheet: DraggableScrollableSheet(
        //   controller: _sheetController,
        //   initialChildSize: 0.32,
        //   minChildSize: 0.14,
        //   maxChildSize: 0.62,
        //   builder: (context, scrollController) {
        //     final m = _selectedMember;
        //     return Container(
        //       decoration: BoxDecoration(
        //         color: theme.colorScheme.surface,
        //         borderRadius: const BorderRadius.vertical(
        //           top: Radius.circular(20),
        //         ),
        //         boxShadow: const [
        //           BoxShadow(color: Colors.black26, blurRadius: 12),
        //         ],
        //       ),
        //       child: ListView(
        //         controller: scrollController,
        //         padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        //         children: [
        //           Center(
        //             child: Container(
        //               width: 40,
        //               height: 4,
        //               margin: const EdgeInsets.only(bottom: 12),
        //               decoration: BoxDecoration(
        //                 color: theme.dividerColor,
        //                 borderRadius: BorderRadius.circular(2),
        //               ),
        //             ),
        //           ),
        //           if (m == null)
        //             const Padding(
        //               padding: EdgeInsets.symmetric(vertical: 24),
        //               child: Center(child: Text('No member selected')),
        //             )
        //           else
        //             _MemberDetailCard(
        //               member: m,
        //               speedUnitKmh: widget.speedUnitKmh,
        //             ),
        //           if (widget.members.length > 1) ...[
        //             const SizedBox(height: 20),
        //             Text('All members', style: theme.textTheme.titleSmall),
        //             const SizedBox(height: 8),
        //             ...widget.members.map(
        //               (mem) => _MemberListTile(
        //                 member: mem,
        //                 selected: mem.id == _selectedMemberId,
        //                 speedUnitKmh: widget.speedUnitKmh,
        //                 onTap: () => _focusMember(mem),
        //               ),
        //             ),
        //           ],
        //         ],
        //       ),
        //     );
        //   },
        // ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// DETAIL CARD (speed, address, battery, last updated)
// ---------------------------------------------------------------------------

class _MemberDetailCard extends StatelessWidget {
  const _MemberDetailCard({required this.member, required this.speedUnitKmh});

  final MemberLocation member;
  final bool speedUnitKmh;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final speedText = speedUnitKmh
        ? '${member.speedKmh.toStringAsFixed(0)} km/h'
        : '${(member.speedKmh * 0.621371).toStringAsFixed(0)} mph';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 26,
              backgroundColor: member.color.withValues(alpha: 0.15),
              backgroundImage: member.avatarUrl != null
                  ? NetworkImage(member.avatarUrl!)
                  : null,
              child: member.avatarUrl == null
                  ? Text(
                      member.name.isNotEmpty
                          ? member.name[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                        color: member.color,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(member.name, style: theme.textTheme.titleMedium),
                  Text(
                    'Updated ${_relativeTime(member.lastUpdated)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.hintColor,
                    ),
                  ),
                ],
              ),
            ),
            _StatusPill(status: member.effectiveStatus),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _StatTile(
                icon: Icons.speed,
                label: 'Speed',
                value: speedText,
              ),
            ),
            if (member.batteryPercent != null)
              Expanded(
                child: _StatTile(
                  icon: member.batteryPercent! < 20
                      ? Icons.battery_alert
                      : Icons.battery_std,
                  label: 'Battery',
                  value: '${member.batteryPercent!.toStringAsFixed(0)}%',
                  valueColor: member.batteryPercent! < 20
                      ? Colors.redAccent
                      : null,
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        if (member.address != null) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.location_on, size: 18, color: theme.hintColor),
              const SizedBox(width: 6),
              Expanded(
                child: Text(member.address!, style: theme.textTheme.bodyMedium),
              ),
            ],
          ),
          const SizedBox(height: 4),
        ],
        Row(
          children: [
            Icon(Icons.my_location, size: 16, color: theme.hintColor),
            const SizedBox(width: 6),
            Text(
              '${member.latitude.toStringAsFixed(5)}, '
              '${member.longitude.toStringAsFixed(5)}',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.hintColor,
              ),
            ),
          ],
        ),
      ],
    );
  }

  static String _relativeTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return DateFormat('MMM d, h:mm a').format(dt);
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.label,
    required this.value,
    this.valueColor,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Icon(icon, size: 22, color: theme.hintColor),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.hintColor,
              ),
            ),
            Text(
              value,
              style: theme.textTheme.titleSmall?.copyWith(color: valueColor),
            ),
          ],
        ),
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.status});

  final MovementStatus status;

  @override
  Widget build(BuildContext context) {
    late final Color color;
    late final IconData icon;
    late final String label;
    switch (status) {
      case MovementStatus.driving:
        color = Colors.orange;
        icon = Icons.directions_car;
        label = 'Driving';
        break;
      case MovementStatus.walking:
        color = Colors.blue;
        icon = Icons.directions_walk;
        label = 'Walking';
        break;
      case MovementStatus.stopped:
        color = Colors.green;
        icon = Icons.pause_circle;
        label = 'Stopped';
        break;
      case MovementStatus.unknown:
        color = Colors.grey;
        icon = Icons.help_outline;
        label = '—';
        break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _MemberListTile extends StatelessWidget {
  const _MemberListTile({
    required this.member,
    required this.selected,
    required this.speedUnitKmh,
    required this.onTap,
  });

  final MemberLocation member;
  final bool selected;
  final bool speedUnitKmh;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final speedText = speedUnitKmh
        ? '${member.speedKmh.toStringAsFixed(0)} km/h'
        : '${(member.speedKmh * 0.621371).toStringAsFixed(0)} mph';
    return ListTile(
      onTap: onTap,
      selected: selected,
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: member.color.withValues(alpha: 0.15),
        backgroundImage: member.avatarUrl != null
            ? NetworkImage(member.avatarUrl!)
            : null,
        child: member.avatarUrl == null
            ? Text(
                member.name.isNotEmpty ? member.name[0].toUpperCase() : '?',
                style: TextStyle(color: member.color),
              )
            : null,
      ),
      title: Text(member.name),
      subtitle: Text(member.address ?? speedText),
      trailing: _StatusPill(status: member.effectiveStatus),
    );
  }
}
