import 'dart:async';
import 'package:battery_plus/battery_plus.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:well_check_v3/core/data/auth_repository.dart';
import 'package:well_check_v3/core/data/medication_provider.dart';
import 'package:well_check_v3/core/data/safe_zone_provider.dart';
import 'package:well_check_v3/core/data/tools_repository.dart';
import 'package:well_check_v3/features/dashboard/widgets/pending_actions_card.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:well_check_v3/core/design/shield_theme.dart';
import 'package:well_check_v3/core/data/user_profile_provider.dart';
import 'package:well_check_v3/core/data/safety_repository.dart';
import 'package:well_check_v3/features/dashboard/widgets/shield_member_card.dart';
import 'package:well_check_v3/features/dashboard/widgets/invite_member_dialog.dart';
import 'package:well_check_v3/features/dashboard/widgets/command_center_sheet.dart';
import 'package:well_check_v3/features/dashboard/widgets/ai_wellness_card.dart';
import 'package:well_check_v3/features/profile/profile_settings_view.dart';
import 'package:well_check_v3/features/tools/safe_zone_config_screen.dart';

import '../../core/data/health_repository.dart';
import '../../core/navigation/shield_router.dart';
import '../../core/notifications/push_notification_service.dart';
import '../../services/referral_service.dart';
import '../command_center/check_in_sheet.dart';
import '../command_center/medications_sheet.dart';
import '../safety/services/location_service.dart';
import '../safety/services/pulse_service.dart';

class LeaderDashboard extends ConsumerStatefulWidget {
  const LeaderDashboard({super.key});

  @override
  ConsumerState<LeaderDashboard> createState() => _LeaderDashboardState();
}

class _LeaderDashboardState extends ConsumerState<LeaderDashboard> {
  bool _sosCountdownActive = false;
  int _sosCountdown = 5;
  Timer? _sosTimer;
  bool isLoad = true;
  Stream<List<Map<String, dynamic>>>? _locationStream;

  Future<bool> showHealthPermissionDialog(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            title: const Text('Connect Apple Health'),
            content: const Text(
              'Well Check integrates with Apple Health to securely access '
              'health and wellness data such as heart rate, steps, and activity '
              'information.\n\n'
              'This data helps provide wellness monitoring, health insights, '
              'and family safety features within the app.\n\n'
              'Your health data is only accessed with your permission and can '
              'be managed at any time through Apple Health settings.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Not Now'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Connect Apple Health'),
              ),
            ],
          ),
        ) ??
        false;
  }

  @override
  void initState() {
    super.initState();
    initializeFCM();
  }

  Future<void> onBoardingDialog() {
    return showDialog(
      context: context,

      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 72,
                width: 72,
                decoration: BoxDecoration(
                  color: const Color(0xFF007F80).withOpacity(.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.shield_outlined,
                  size: 40,
                  color: Color(0xFF007F80),
                ),
              ),
              const SizedBox(height: 20),

              const Text(
                'Welcome to Well Check',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 12),

              Text(
                'Your Family Shield is now active. Let’s take a few moments to build a safer and healthier support network for your loved ones.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey.shade600,
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 24),

              _StepTile(
                icon: Icons.people_outline,
                title: 'Invite Family Members',
                subtitle:
                    'Connect children, elders, and caregivers to your Family Shield.',
              ),

              const SizedBox(height: 12),

              _StepTile(
                icon: Icons.medication_outlined,
                title: 'Add Medications',
                subtitle:
                    'Create medication schedules and reminders for better care.',
              ),

              const SizedBox(height: 12),

              _StepTile(
                icon: Icons.monitor_heart_outlined,
                title: 'Start Monitoring',
                subtitle:
                    'Receive wellness updates and stay informed about your loved ones.',
              ),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    showDialog(
                      context: context,
                      builder: (context) => const InviteMemberDialog(),
                    );
                    // Navigate to Invite Family
                  },
                  child: const Text('Get Started'),
                ),
              ),

              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Skip for Now'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void initializeFCM() async {
    try {
      //  await PulseService().broadcastPulse(null);
      await PushNotificationService.initialize();
    } catch (e) {
      print('broadcastPulse error: $e');
    }

    if (!mounted) return;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final profile = await ref.read(currentUserProfileProvider.future);
        if (profile == null) return;
        final safetyRepo = ref.watch(safetyRepositoryProvider);

        _locationStream = safetyRepo.streamFamilyLocation(profile.familyId);
        if (mounted) {
          setState(() {});
        }
        final prefs = await SharedPreferences.getInstance();

        final heartRateEnabled = prefs.getBool('priv_heartbeat') ?? true;
        final hasSeen = prefs.getBool('has_seen_leader_onboarding') ?? false;
        if (heartRateEnabled && !hasSeen) {
          final shouldConnect = await showHealthPermissionDialog(context);

          if (!shouldConnect) {
            setState(() => isLoad = false);

            return;
          }

          final result = await ref
              .read(healthRepositoryProvider)
              .syncVitals(
                userId: profile.userId,
                familyId: profile.familyId,
                userName: profile.fullName ?? '',
              );

          print(
            'SYNC RESULT: ${result.success} | ${result.status} | ${result.message}',
          );

          if (!mounted) return;

          await Future.delayed(const Duration(milliseconds: 500));

          if (!mounted) return;

          // if (result.success) {
          //   _showSuccessSnackbar(context, result.message);
          // } else {
          //   _showErrorDialog(context, result);
          // }
        }
        setState(() => isLoad = false);

        final hasSeenOnboarding =
            prefs.getBool('has_seen_leader_onboarding') ?? false;

        if (!hasSeenOnboarding && profile.role == 'leader') {
          await prefs.setBool('has_seen_leader_onboarding', true);

          if (mounted) {
            await _showGuidedSetupSheet(context, profile);
          }
        }
      } catch (e) {
        print('initializeFCM error: $e');
      }
    });
    final granted = await LocationService.checkLocationPermissions(context);
    if (!granted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Location access is required for your safety.'),
            duration: const Duration(seconds: 4),
            action: SnackBarAction(
              label: 'Enable',
              onPressed: () async {
                await LocationService.requestSettingsRedirect(
                  context,
                  title: 'Location Permission Required',
                  steps: [
                    'Tap "Open Settings" below',
                    'Select "Location"',
                    'Choose an option',
                  ],
                );
              },
            ),
          ),
        );
      }
    }
  }

  Future<void> _showGuidedSetupSheet(BuildContext context, profile) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) => _GuidedSetupSheet(
        onInviteMembers: () {
          // Navigator.pop(context);
          showDialog(
            context: context,
            builder: (context) => const InviteMemberDialog(),
          );
        },
        onAddMedication: () {
          //  Navigator.pop(context);
          WidgetsBinding.instance.addPostFrameCallback((_) {
            showModalBottomSheet(
              context: context,
              useSafeArea: true,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (context) => StatefulBuilder(
                builder: (context, setState) {
                  return MedicationsSheet(fromLeader: true);
                },
              ),
            );

            //  Navigator.push(context, MaterialPageRoute(builder: (context)=>sheet));
          });
        },
        onScheduleCheckIn: () {
          //  Navigator.pop(context);
          WidgetsBinding.instance.addPostFrameCallback((_) {
            showModalBottomSheet(
              context: context,
              useSafeArea: true,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (context) => StatefulBuilder(
                builder: (context, setState) {
                  return ScheduleCheckInSheet();
                },
              ),
            );

            //  Navigator.push(context, MaterialPageRoute(builder: (context)=>sheet));
          });
        },
        onOpenCommandCenter: () {
          //Navigator.pop(context);
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (context) => CommandCenterSheet(fromLeader: true),
          );
        },
      ),
    );
  }

  void _showSuccessSnackbar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green.shade700,
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────
  // Error — blocking dialog with icon + action per scenario
  // ─────────────────────────────────────────────────────────────
  void _showErrorDialog(BuildContext context, SyncResult result) {
    final config = _dialogConfig(result.status);

    showDialog(
      context: context,
      barrierDismissible: false, // client must read and dismiss
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(config.icon, color: config.color, size: 28),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                config.title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          result.message,
          style: const TextStyle(fontSize: 14, height: 1.5),
        ),
        actions: [
          // Optional: retry button for network/upload errors
          if (result.status == SyncStatus.networkError ||
              result.status == SyncStatus.uploadFailed)
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Retry'),
            ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────
  // Icon + title per SyncStatus
  // ─────────────────────────────────────────────────────────────
  _DialogConfig _dialogConfig(SyncStatus status) {
    switch (status) {
      case SyncStatus.permissionDenied:
        return _DialogConfig(
          icon: Icons.lock_outline,
          color: Colors.orange,
          title: 'Permission Required',
        );
      case SyncStatus.noData:
        return _DialogConfig(
          icon: Icons.watch_off_outlined,
          color: Colors.blue,
          title: 'No Health Data Found',
        );
      case SyncStatus.noHeartRate:
        return _DialogConfig(
          icon: Icons.favorite_border,
          color: Colors.red,
          title: 'No Heart Rate Data',
        );
      case SyncStatus.networkError:
        return _DialogConfig(
          icon: Icons.wifi_off_outlined,
          color: Colors.grey,
          title: 'No Internet Connection',
        );
      case SyncStatus.uploadFailed:
        return _DialogConfig(
          icon: Icons.cloud_off_outlined,
          color: Colors.deepOrange,
          title: 'Upload Failed',
        );
      case SyncStatus.unknownError:
      default:
        return _DialogConfig(
          icon: Icons.error_outline,
          color: Colors.red,
          title: 'Sync Failed',
        );
    }
  }

  // void initializeFCM() async {
  //   // await  PulseService().broadcastPulse(null);
  //   await PulseService().broadcastPulse(null);
  //   if (!mounted) return;
  //
  //   setState(() {
  //     isLoad = false;
  //   });
  //   if (!mounted) return;
  //   await PushNotificationService.initialize();
  // }

  @override
  void dispose() {
    _sosTimer?.cancel();
    super.dispose();
  }

  //
  void _startSosCountdown() {
    if (isLoad) return;

    if (_sosCountdownActive) {
      _sosTimer?.cancel();
      setState(() {
        _sosCountdownActive = false;
        _sosCountdown = 5;
      });
      return;
    }

    setState(() {
      //  isLoad = true;
      _sosCountdownActive = true;
      _sosCountdown = 5;
    });

    _sosTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      HapticFeedback.heavyImpact();

      if (_sosCountdown <= 1) {
        timer.cancel();
        try {
          final profile = await ref.read(currentUserProfileProvider.future);
          if (profile == null) {
            debugPrint(
              '[SOS] Profile is null — user has no family_members row',
            );
            if (mounted) {
              setState(() {
                isLoad = false;

                _sosCountdownActive = false;
                _sosCountdown = 5;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    '⚠️ SOS FAILED: No family profile found. Please re-join a family first.',
                  ),
                  backgroundColor: Colors.orange,
                  duration: Duration(seconds: 5),
                ),
              );
            }
            return;
          }

          await ref
              .read(safetyRepositoryProvider)
              .triggerSiren(
                profile.familyId,
                '${profile.fullName}- Leader manually initiated an emergency state',
              );

          if (mounted) {
            setState(() {
              isLoad = false;

              _sosCountdownActive = false;
              _sosCountdown = 5;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('🚨 EMERGENCY ALERT SENT!'),
                backgroundColor: ShieldColors.urgentRed,
                duration: Duration(seconds: 5),
              ),
            );
            final members = await Supabase.instance.client
                .from('family_members')
                .select('user_id')
                .eq('family_id', profile.familyId);

            for (final m in members) {
              final targetUserId = m['user_id'];

              if (targetUserId == profile.userId) continue;

              try {
                await Supabase.instance.client.functions.invoke(
                  'push-router',
                  body: {
                    "target_user_id": targetUserId,
                    "title": "Emergency Alert",
                    "body": "${profile.fullName} triggered an emergency alert",
                    "action": "emergency",
                    "sound": "sos_sound",
                  },
                );
              } catch (e) {
                debugPrint("Push failed: $e");
              }
            }
          }
        } catch (e) {
          debugPrint('[SOS] triggerSiren failed: $e');
          if (mounted) {
            setState(() {
              isLoad = false;

              _sosCountdownActive = false;
              _sosCountdown = 5;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('⚠️ SOS FAILED: $e'),
                backgroundColor: Colors.orange,
                duration: const Duration(seconds: 5),
              ),
            );
          }
        }
      } else {
        if (mounted) setState(() => _sosCountdown--);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(currentUserProfileProvider);
    final medicationsAsync = ref.watch(familyMedicationsProvider);

    return isLoad
        ? Scaffold(
            backgroundColor: Colors.white,
            body: Center(child: CircularProgressIndicator()),
          )
        : Scaffold(
            backgroundColor: ShieldColors.activeTeal,
            body: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 8),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        Image.asset('assets/logo.png', height: 40, width: 40),
                        SizedBox(width: 6),
                        Text(
                          "Well-Check",
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(
                                color: ShieldColors.backgroundWhite,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                        ),
                        Spacer(),
                        Container(
                          padding: EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.grey.shade200),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              // showModalBottomSheet(
                              //   context: context,
                              //   isScrollControlled: true,
                              //   backgroundColor: Colors.transparent,
                              //   builder: (_) => const ProfileSettingsView(),
                              // );
                              showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                builder: (_) {
                                  return DraggableScrollableSheet(
                                    initialChildSize: 0.85,
                                    minChildSize: 0.5,
                                    maxChildSize: 0.95,
                                    expand: false,
                                    builder: (_, controller) {
                                      return SingleChildScrollView(
                                        controller: controller,
                                        child: const ProfileSettingsView(),
                                      );
                                    },
                                  );
                                },
                              );
                            },
                            child: Icon(
                              Icons.menu,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12),
                  // Header — Bug 1: Responsive scaling, Bug 2: Working notification bell
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24),
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24.0,
                      vertical: 16.0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              profileAsync.when(
                                data: (profile) {
                                  final firstName =
                                      profile?.fullName?.split(' ').first ??
                                      'Leader';
                                  return Text(
                                    'Welcome, $firstName.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: ShieldColors.textBody,
                                        ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  );
                                },
                                loading: () => Text(
                                  'Welcome back...',
                                  style: Theme.of(context).textTheme.titleMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: ShieldColors.textBody,
                                      ),
                                ),
                                error: (e, st) => Text(
                                  'Welcome, Leader.',
                                  style: Theme.of(context).textTheme.titleMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: ShieldColors.textBody,
                                      ),
                                ),
                              ),
                              const SizedBox(height: 4),

                              Row(
                                children: [
                                  Icon(
                                    Icons.privacy_tip,
                                    color: ShieldColors.activeTeal,
                                    size: 22,
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    'The Shield is active',
                                    style: Theme.of(context).textTheme.bodySmall
                                        ?.copyWith(
                                          color: ShieldColors.textLabel,
                                        ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            profileAsync.when(
                              data: (profile) {
                                print(profile!.avatarUrl);
                                print("avatarUrl");
                                return profile != null &&
                                        profile!.avatarUrl != null
                                    ? CircleAvatar(
                                        radius: 35,
                                        backgroundColor:
                                            ShieldColors.activeTeal,

                                        backgroundImage: CachedNetworkImageProvider(
                                          '${profile!.avatarUrl}?t=${DateTime.now().millisecondsSinceEpoch}',
                                        ),
                                      )
                                    : CircleAvatar(
                                        backgroundColor:
                                            ShieldColors.activeTeal,

                                        radius: 35,
                                        child: Icon(
                                          size: 35,
                                          Icons.person,
                                          color: Colors.white,
                                        ),
                                      );
                              },
                              loading: () => SizedBox.shrink(),
                              error: (e, st) => SizedBox.shrink(),
                            ),
                            SizedBox(width: 10),
                            Container(
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: ShieldDesign.roundedTwelve,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: GestureDetector(
                                child: const Icon(
                                  size: 20,
                                  Icons.person_add_alt_1,
                                  color: ShieldColors.activeTeal,
                                ),
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) =>
                                        const InviteMemberDialog(),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            // Bug 2: Notification bell now shows recent events
                            Container(
                              padding: EdgeInsets.all(10),

                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: ShieldDesign.roundedTwelve,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: profileAsync.value == null
                                  ? GestureDetector(
                                      child: const Icon(
                                        size: 20,

                                        Icons.notifications_none,
                                        color: ShieldColors.textBody,
                                      ),
                                      onTap: () {},
                                    )
                                  : StreamBuilder<List<Map<String, dynamic>>>(
                                      stream: ref
                                          .watch(safetyRepositoryProvider)
                                          .streamFamilyEvents(
                                            profileAsync.value!.familyId,
                                          ),
                                      builder: (context, snapshot) {
                                        return FutureBuilder(
                                          future: SharedPreferences.getInstance()
                                              .then(
                                                (p) => p.getString(
                                                  'last_notification_opened',
                                                ),
                                              ),
                                          builder: (context, prefSnap) {
                                            final lastSeen = DateTime.tryParse(
                                              prefSnap.data ?? '',
                                            );
                                            final events = snapshot.data ?? [];
                                            final hasUnread = events.any((e) {
                                              final dt = DateTime.tryParse(
                                                e['created_at'] ?? '',
                                              );

                                              if (dt == null) return false;

                                              if (lastSeen == null) return true;

                                              return dt.isAfter(lastSeen);
                                            });
                                            return Stack(
                                              alignment: Alignment.topRight,
                                              children: [
                                                GestureDetector(
                                                  child: const Icon(
                                                    size: 20,
                                                    Icons.notifications_none,
                                                    color:
                                                        ShieldColors.textBody,
                                                  ),
                                                  onTap: () async {
                                                    final prefs =
                                                        await SharedPreferences.getInstance();

                                                    await prefs.setString(
                                                      'last_notification_opened',
                                                      DateTime.now()
                                                          .toIso8601String(),
                                                    );
                                                    setState(() {});

                                                    showModalBottomSheet(
                                                      context: context,
                                                      isScrollControlled: true,
                                                      backgroundColor:
                                                          Colors.transparent,
                                                      builder: (ctx) =>
                                                          _NotificationsSheet(
                                                            familyId:
                                                                profileAsync
                                                                    .value!
                                                                    .familyId,
                                                            safetyRepo: ref.read(
                                                              safetyRepositoryProvider,
                                                            ),
                                                          ),
                                                    );
                                                  },
                                                ),

                                                if (hasUnread)
                                                  Positioned(
                                                    right: 3,
                                                    top: 0,
                                                    child: Container(
                                                      width: 6,
                                                      height: 6,
                                                      decoration:
                                                          const BoxDecoration(
                                                            color: ShieldColors
                                                                .urgentRed,
                                                            shape:
                                                                BoxShape.circle,
                                                          ),
                                                    ),
                                                  ),
                                              ],
                                            );
                                          },
                                        );
                                      },
                                    ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Leader Dashboard Content
                  Expanded(
                    child: profileAsync.when(
                      data: (profile) {
                        if (profile == null) {
                          return const Center(
                            child: Text('No profile found. Please register.'),
                          );
                        }

                        final safetyRepo = ref.watch(safetyRepositoryProvider);

                        return Container(
                          decoration: BoxDecoration(color: Colors.grey.shade50),
                          child: RefreshIndicator(
                            onRefresh: () async {
                              final safetyRepo = ref.invalidate(
                                safetyRepositoryProvider,
                              );
                            },
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 24.0,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const PendingActionsCard(),
                                  const SizedBox(height: 16),
                                  if (_locationStream == null)
                                    Center(child: CircularProgressIndicator()),

                                  StreamBuilder<List<Map<String, dynamic>>>(
                                    stream: _locationStream,
                                    builder: (context, eventSnapshot) {
                                      // if (eventSnapshot.connectionState ==
                                      //     ConnectionState.waiting) {
                                      //   return const Center(
                                      //     child: CircularProgressIndicator(),
                                      //   );
                                      // }

                                      final events = eventSnapshot.data ?? [];

                                      if (events.isEmpty) {
                                        return const SizedBox();
                                      }

                                      return LiveMembersMap(events: events);
                                    },
                                  ),
                                  const SizedBox(height: 16),

                                  // Pending Members List
                                  StreamBuilder<List<Map<String, dynamic>>>(
                                    stream: safetyRepo.streamPendingMembers(
                                      profile.familyId,
                                    ),
                                    builder: (context, snapshot) {
                                      final pending = snapshot.data ?? [];
                                      if (pending.isEmpty) {
                                        return const SizedBox.shrink();
                                      }

                                      return Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Pending Approvals (${pending.length})',
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleMedium
                                                ?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                  color: ShieldColors.urgentRed,
                                                ),
                                          ),
                                          const SizedBox(height: 12),
                                          ...pending.map(
                                            (member) => Card(
                                              margin: const EdgeInsets.only(
                                                bottom: 8,
                                              ),
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    ShieldDesign.roundedTwelve,
                                                side: const BorderSide(
                                                  color: ShieldColors.urgentRed,
                                                  width: 1,
                                                ),
                                              ),
                                              child: ListTile(
                                                leading: const Icon(
                                                  Icons.person_add_alt_1,
                                                  color: ShieldColors.urgentRed,
                                                ),
                                                title: Text(
                                                  member['full_name'] != null
                                                      ? '${member['full_name']} (${member['role']})'
                                                      : 'New ${member['role'] ?? 'Member'} Request',
                                                ),
                                                subtitle: Text(
                                                  'User ID: ${member['id'].toString().substring(0, 8)}...',
                                                ),
                                                trailing: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    IconButton(
                                                      icon: const Icon(
                                                        Icons.check_circle,
                                                        color: ShieldColors
                                                            .safeZoneGreen,
                                                      ),
                                                      onPressed: () =>
                                                          safetyRepo
                                                              .approveMember(
                                                                member['id'],
                                                              ),
                                                    ),
                                                    IconButton(
                                                      icon: const Icon(
                                                        Icons.cancel,
                                                        color: Colors.grey,
                                                      ),
                                                      onPressed: () =>
                                                          safetyRepo
                                                              .rejectMember(
                                                                member['id'],
                                                              ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 24),
                                        ],
                                      );
                                    },
                                  ),
                                  const SizedBox(height: 16),

                                  StreamBuilder<List<Map<String, dynamic>>>(
                                    stream: safetyRepo.streamLeaderSchedules(
                                      profile.familyId,
                                    ),
                                    builder: (context, snapshot) {
                                      final schedules = snapshot.data ?? [];
                                      print("schedules");
                                      print(schedules);
                                      if (schedules.isEmpty) {
                                        return const SizedBox.shrink();
                                      }

                                      // Get next upcoming checkin
                                      DateTime? nextCheckin;
                                      Map<String, dynamic>? selectedSchedule;
                                      String assignedUser = '';
                                      for (final s in schedules) {
                                        print(s);
                                        print('checkin_time');
                                        final time = s['checkin_time'];
                                        final name = s['assigned_user_name'];

                                        final next = _getNextCheckinTime(s);
                                        print(
                                          'ID=${s['id']} '
                                          'recurrence=${s['recurrence']} '
                                          'scheduled_at=${s['scheduled_at']} '
                                          'next=$next',
                                        );

                                        if (next == null) continue;
                                        if (nextCheckin == null ||
                                            next.isBefore(nextCheckin)) {
                                          nextCheckin = next;
                                          selectedSchedule = s;
                                          assignedUser = name;
                                        }
                                      }
                                      print(
                                        'SELECTED: ${selectedSchedule?['id']} '
                                        '${selectedSchedule?['recurrence']} '
                                        '$nextCheckin',
                                      );
                                      if (nextCheckin == null ||
                                          selectedSchedule == null) {
                                        return const SizedBox.shrink();
                                      }

                                      final scheduleId = selectedSchedule['id'];
                                      final assignedUserId =
                                          selectedSchedule['assigned_user_id'];
                                      print("nextCheckin$nextCheckin");
                                      return _NextCheckinCard(
                                        nextCheckin: nextCheckin,
                                        profile: profileAsync.value,
                                        scheduleId: scheduleId,
                                        assignedUser: assignedUser,
                                        assignedUserId: assignedUserId,
                                      );
                                    },
                                  ),
                                  SizedBox(height: 10),
                                  medicationsAsync.when(
                                    data: (medications) {
                                      final activeMeds = medications
                                          .where((m) => m.isActive)
                                          .toList();

                                      if (activeMeds.isEmpty) {
                                        return const SizedBox.shrink();
                                      }

                                      return Container(
                                        margin: const EdgeInsets.only(
                                          bottom: 18,
                                        ),
                                        padding: const EdgeInsets.all(16),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            20,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black.withValues(
                                                alpha: 0.04,
                                              ),
                                              blurRadius: 10,
                                              offset: const Offset(0, 4),
                                            ),
                                          ],
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'MEDICATION MONITOR',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .labelMedium
                                                  ?.copyWith(
                                                    color:
                                                        ShieldColors.textLabel,
                                                    fontWeight: FontWeight.bold,
                                                    letterSpacing: 1.2,
                                                  ),
                                            ),

                                            const SizedBox(height: 14),

                                            ...activeMeds.map((med) {
                                              // final nextDose = med.nextDoseToday;
                                              DateTime? nextDose;

                                              if (med
                                                  .scheduleTimes
                                                  .isNotEmpty) {
                                                final now = DateTime.now();

                                                final upcomingDoses =
                                                    <DateTime>[];

                                                final startDate =
                                                    med.startDate ?? now;

                                                for (final time
                                                    in med.scheduleTimes) {
                                                  try {
                                                    final parts = time.split(
                                                      ':',
                                                    );

                                                    final hour = int.parse(
                                                      parts[0],
                                                    );
                                                    final minute = int.parse(
                                                      parts[1],
                                                    );

                                                    DateTime doseTime =
                                                        DateTime(
                                                          now.year,
                                                          now.month,
                                                          now.day,
                                                          hour,
                                                          minute,
                                                        );

                                                    final frequency = med
                                                        .frequency
                                                        .toLowerCase();

                                                    // DAILY
                                                    if (frequency.contains(
                                                      'daily',
                                                    )) {
                                                      if (doseTime.isBefore(
                                                        now,
                                                      )) {
                                                        doseTime = doseTime.add(
                                                          const Duration(
                                                            days: 1,
                                                          ),
                                                        );
                                                      }
                                                    }
                                                    // EVERY OTHER DAY
                                                    else if (frequency.contains(
                                                      'every other',
                                                    )) {
                                                      final daysSinceStart = now
                                                          .difference(startDate)
                                                          .inDays;

                                                      final shouldTakeToday =
                                                          daysSinceStart % 2 ==
                                                          0;

                                                      if (!shouldTakeToday ||
                                                          doseTime.isBefore(
                                                            now,
                                                          )) {
                                                        doseTime = doseTime.add(
                                                          const Duration(
                                                            days: 1,
                                                          ),
                                                        );

                                                        while (doseTime
                                                                    .difference(
                                                                      startDate,
                                                                    )
                                                                    .inDays %
                                                                2 !=
                                                            0) {
                                                          doseTime = doseTime
                                                              .add(
                                                                const Duration(
                                                                  days: 1,
                                                                ),
                                                              );
                                                        }
                                                      }
                                                    }
                                                    // WEEKLY
                                                    else if (frequency.contains(
                                                      'weekly',
                                                    )) {
                                                      doseTime = DateTime(
                                                        now.year,
                                                        now.month,
                                                        now.day,
                                                        hour,
                                                        minute,
                                                      );

                                                      while (doseTime.weekday !=
                                                              startDate
                                                                  .weekday ||
                                                          doseTime.isBefore(
                                                            now,
                                                          )) {
                                                        doseTime = doseTime.add(
                                                          const Duration(
                                                            days: 1,
                                                          ),
                                                        );
                                                      }
                                                    }
                                                    // MONTHLY
                                                    else if (frequency.contains(
                                                      'monthly',
                                                    )) {
                                                      doseTime = DateTime(
                                                        now.year,
                                                        now.month,
                                                        startDate.day,
                                                        hour,
                                                        minute,
                                                      );

                                                      if (doseTime.isBefore(
                                                        now,
                                                      )) {
                                                        doseTime = DateTime(
                                                          now.year,
                                                          now.month + 1,
                                                          startDate.day,
                                                          hour,
                                                          minute,
                                                        );
                                                      }
                                                    }
                                                    // AS NEEDED
                                                    else if (frequency.contains(
                                                      'as needed',
                                                    )) {
                                                      continue;
                                                    }

                                                    upcomingDoses.add(doseTime);
                                                  } catch (e) {
                                                    debugPrint(
                                                      "Dose parse error: $e",
                                                    );
                                                  }
                                                }

                                                upcomingDoses.sort();

                                                if (upcomingDoses.isNotEmpty) {
                                                  nextDose =
                                                      upcomingDoses.first;
                                                }
                                              }
                                              String countdownText =
                                                  'No upcoming dose';
                                              Color statusColor = Colors.grey;

                                              Duration? diff;

                                              if (nextDose != null) {
                                                diff = nextDose.difference(
                                                  DateTime.now(),
                                                );
                                              }
                                              countdownText =
                                                  '${diff?.inHours}h ${diff?.inMinutes.remainder(60)}m ${diff?.inSeconds.remainder(60)}s';
                                              return Container(
                                                margin: const EdgeInsets.only(
                                                  bottom: 12,
                                                ),
                                                padding: const EdgeInsets.all(
                                                  14,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: Colors.grey.shade50,
                                                  borderRadius:
                                                      BorderRadius.circular(16),
                                                  border: Border.all(
                                                    color: statusColor
                                                        .withValues(alpha: 0.2),
                                                  ),
                                                ),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Icon(
                                                      Icons.local_hospital,
                                                      color: Colors.purple,
                                                      size: 26,
                                                    ),

                                                    const SizedBox(width: 7),

                                                    Expanded(
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  med.medicationName,
                                                                  style: const TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontSize:
                                                                        15,
                                                                  ),
                                                                ),

                                                                const SizedBox(
                                                                  height: 4,
                                                                ),

                                                                Text(
                                                                  '${med.dosage} • ${med.scheduleSummary}',
                                                                  style: TextStyle(
                                                                    color: Colors
                                                                        .grey
                                                                        .shade700,
                                                                    fontSize:
                                                                        12,
                                                                  ),
                                                                ),

                                                                //
                                                                if (med.assignedName !=
                                                                    null) ...[
                                                                  const SizedBox(
                                                                    height: 4,
                                                                  ),

                                                                  Text(
                                                                    'Assigned to: ${med.assignedName}',
                                                                    style: TextStyle(
                                                                      color: Colors
                                                                          .blueGrey,
                                                                      fontSize:
                                                                          12,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ],

                                                                if (med.doctor !=
                                                                    null) ...[
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),

                                                                  RichText(
                                                                    text: TextSpan(
                                                                      style: TextStyle(
                                                                        color: Colors
                                                                            .blueGrey,
                                                                        fontSize:
                                                                            12,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                      children: [
                                                                        TextSpan(
                                                                          text:
                                                                              'Prescribing doctor: ',
                                                                        ),
                                                                        TextSpan(
                                                                          text:
                                                                              med.doctor,
                                                                          style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                                if (med.instructions !=
                                                                    null) ...[
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),
                                                                  RichText(
                                                                    text: TextSpan(
                                                                      style: TextStyle(
                                                                        color: Colors
                                                                            .blueGrey,
                                                                        fontSize:
                                                                            12,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                      children: [
                                                                        TextSpan(
                                                                          text:
                                                                              'Instruction: ',
                                                                        ),
                                                                        TextSpan(
                                                                          text:
                                                                              med.instructions,
                                                                          style: TextStyle(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                                SizedBox(
                                                                  height: 5,
                                                                ),

                                                                // if (nextDose !=
                                                                //     null) ...[
                                                                //   const SizedBox(
                                                                //     height: 4,
                                                                //   ),
                                                                //
                                                                //   Text(
                                                                //     'At ${DateFormat.jm().format(nextDose)}',
                                                                //     style: TextStyle(
                                                                //       color: Colors
                                                                //           .grey
                                                                //           .shade600,
                                                                //       fontSize: 11,
                                                                //     ),
                                                                //   ),
                                                                // ],
                                                              ],
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .end,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .end,
                                                              children: [
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .end,
                                                                  children: [
                                                                    if (nextDose !=
                                                                        null)
                                                                      StreamBuilder(
                                                                        stream: Stream.periodic(
                                                                          const Duration(
                                                                            seconds:
                                                                                1,
                                                                          ),
                                                                        ),
                                                                        builder:
                                                                            (
                                                                              context,
                                                                              snapshot,
                                                                            ) {
                                                                              final diff =
                                                                                  nextDose?.difference(
                                                                                    DateTime.now(),
                                                                                  ) ??
                                                                                  Duration.zero;

                                                                              // Prevent negative values
                                                                              final safeDiff = diff.isNegative
                                                                                  ? Duration.zero
                                                                                  : diff;

                                                                              final text =
                                                                                  '${safeDiff.inHours.toString().padLeft(2, '0')}h '
                                                                                  '${safeDiff.inMinutes.remainder(60).toString().padLeft(2, '0')}m '
                                                                                  '${safeDiff.inSeconds.remainder(60).toString().padLeft(2, '0')}s';

                                                                              return Text(
                                                                                text,
                                                                                style: TextStyle(
                                                                                  color: ShieldColors.activeTeal,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  fontSize: 12,
                                                                                ),
                                                                              );
                                                                            },
                                                                      ),
                                                                  ],
                                                                ),
                                                                Text(
                                                                  "Until Next Dose",
                                                                  style: TextStyle(
                                                                    fontSize:
                                                                        12,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: ShieldColors
                                                                        .activeTeal,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            }),
                                          ],
                                        ),
                                      );
                                    },
                                    loading: () => const Center(
                                      child: Padding(
                                        padding: EdgeInsets.all(20),
                                        child: CircularProgressIndicator(),
                                      ),
                                    ),
                                    error: (e, st) => const SizedBox.shrink(),
                                  ),
                                  // Active Members Stream
                                  Text(
                                    'Shield Members',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleLarge
                                        ?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: ShieldColors.textBody,
                                        ),
                                  ),
                                  const SizedBox(height: 16),

                                  StreamBuilder<List<Map<String, dynamic>>>(
                                    stream: safetyRepo.streamActiveMembers(
                                      profile.familyId,
                                    ),
                                    builder: (context, memberSnapshot) {
                                      if (memberSnapshot.connectionState ==
                                              ConnectionState.waiting &&
                                          !_sosCountdownActive) {
                                        return const Center(
                                          child: CircularPulseIndicator(),
                                        );
                                      }

                                      final members = memberSnapshot.data ?? [];

                                      if (members.isEmpty) {
                                        return const Text(
                                          'No members found. Invite some!',
                                        );
                                      }

                                      return Column(
                                        children: members.map((member) {
                                          return _MemberStatusCard(
                                            member: member,
                                            safetyRepo: safetyRepo,
                                            currentUserId: profile.userId,
                                          );
                                        }).toList(),
                                      );
                                    },
                                  ),

                                  // Recent Events Stream — Bug 3: Improved formatting
                                  const SizedBox(height: 20),
                                  // Text(
                                  //   'Recent Activity',
                                  //   style: Theme.of(context).textTheme.titleLarge
                                  //       ?.copyWith(
                                  //         fontWeight: FontWeight.bold,
                                  //         color: ShieldColors.textBody,
                                  //       ),
                                  // ),
                                  // const SizedBox(height: 16),

                                  // StreamBuilder<List<Map<String, dynamic>>>(
                                  //   stream: safetyRepo.streamFamilyEvents(
                                  //     profile.familyId,
                                  //   ),
                                  //   builder: (context, eventSnapshot) {
                                  //     if (eventSnapshot.connectionState ==
                                  //         ConnectionState.waiting) {
                                  //       return const Center(
                                  //         child: CircularProgressIndicator(),
                                  //       );
                                  //     }
                                  //
                                  //     final events = eventSnapshot.data ?? [];
                                  //     if (events.isEmpty) {
                                  //       return const Padding(
                                  //         padding: EdgeInsets.symmetric(vertical: 32),
                                  //         child: Center(
                                  //           child: Column(
                                  //             children: [
                                  //               Icon(
                                  //                 Icons.history,
                                  //                 size: 48,
                                  //                 color: Colors.grey,
                                  //               ),
                                  //               SizedBox(height: 8),
                                  //               Text(
                                  //                 'No recent activity yet.\nCheck-ins, SOS events, and status updates will appear here.',
                                  //                 textAlign: TextAlign.center,
                                  //                 style: TextStyle(
                                  //                   color: ShieldColors.textLabel,
                                  //                 ),
                                  //               ),
                                  //             ],
                                  //           ),
                                  //         ),
                                  //       );
                                  //     }
                                  //
                                  //     return Container(
                                  //       decoration: BoxDecoration(
                                  //         color: Colors.white,
                                  //         borderRadius: ShieldDesign.roundedTwelve,
                                  //       ),
                                  //       child: ListView.separated(
                                  //         shrinkWrap: true,
                                  //         physics: const NeverScrollableScrollPhysics(),
                                  //         itemCount: events.length > 10
                                  //             ? 10
                                  //             : events.length,
                                  //         separatorBuilder: (context, index) =>
                                  //             const Divider(height: 1),
                                  //         itemBuilder: (context, index) {
                                  //           final evt = events[index];
                                  //           return _buildEventTile(evt);
                                  //         },
                                  //       ),
                                  //     );
                                  //   },
                                  // ),
                                  _buildRecentActivity(
                                    context,
                                    safetyRepo,
                                    profile.familyId,
                                  ),

                                  const SizedBox(height: 20),
                                  const AiWellnessCard(),
                                  const SizedBox(height: 100),
                                  // Space for bottom nav
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      loading: () =>
                          const Center(child: CircularProgressIndicator()),
                      error: (e, st) => Center(child: Text('Error: $e')),
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: Container(
              color: Colors.white,
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: Row(
                    children: [
                      // Large EMERGENCY button
                      Expanded(
                        flex: 2,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          height: 60,
                          child: ElevatedButton(
                            onPressed: _startSosCountdown,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _sosCountdownActive
                                  ? Colors.orange
                                  : ShieldColors.urgentRed,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: ShieldDesign.roundedTwelve,
                              ),
                              elevation: 6,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.warning_rounded, size: 24),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    _sosCountdownActive
                                        ? 'CANCEL ($_sosCountdown)'
                                        : 'EMERGENCY',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      letterSpacing: 1,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // COMMAND CENTER button
                      Expanded(
                        flex: 2,
                        child: SizedBox(
                          height: 60,
                          child: ElevatedButton(
                            onPressed: () async {
                              await showModalBottomSheet(
                                context: context,

                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                builder: (context) =>
                                    CommandCenterSheet(fromLeader: true),
                              );
                              //  profileAsync = ref.watch(currentUserProfileProvider);
                              //  ref.invalidate(currentUserProfileProvider);
                              //   ref.invalidate(safetyRepositoryProvider);
                              //  ref.invalidate(userRoleProvider);
                              //  ref.invalidate(currentUserProfileProvider);
                              // ref.invalidate(shieldRouterProvider);
                              // ref.invalidate(allDoseLogsProvider);
                              // ref.invalidate(familySafeZonesProvider);
                              // ref.invalidate(familyMedicationsProvider);
                              // ref.invalidate(toolsRepositoryProvider);
                              //   ref.invalidate(authRepositoryProvider);
                              //  ref.invalidate(safeZonesStreamProvider);
                              //  Navigator.push(context, MaterialPageRoute(builder: (context)=>CommandCenterSheet()));
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: ShieldColors.activeTeal,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: ShieldDesign.roundedTwelve,
                              ),
                              elevation: 4,
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.grid_view_rounded, size: 22),
                                SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    'MENU',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                      letterSpacing: 1,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      // const SizedBox(width: 8),
                      // // Profile icon button
                      // Container(
                      //   decoration: BoxDecoration(
                      //     borderRadius: BorderRadius.circular(30),
                      //     color: Colors.white,
                      //   ),
                      //   height: 60,
                      //   width: 60,
                      //   child: GestureDetector(
                      //     onTap: () {
                      //       showModalBottomSheet(
                      //         context: context,
                      //         isScrollControlled: true,
                      //         backgroundColor: Colors.transparent,
                      //         builder: (_) => const ProfileSettingsView(),
                      //       );
                      //     },
                      //
                      //     child: profileAsync.value?.avatarUrl != null
                      //         ? Container(
                      //             padding: EdgeInsets.all(10),
                      //             clipBehavior: Clip.antiAlias,
                      //             decoration: BoxDecoration(),
                      //             child: ClipRRect(
                      //               borderRadius: BorderRadius.circular(30),
                      //               //  borderRadius: ShieldDesign.roundedTwelve,
                      //               child: Image.network(
                      //                 profileAsync.value!.avatarUrl!,
                      //                 fit: BoxFit.cover,
                      //               ),
                      //             ),
                      //           )
                      //         : const Icon(Icons.person_outline, size: 26),
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }

  DateTime? _getNextCheckinTime(Map<String, dynamic> schedule) {
    // use next generated occurrence if available
    if (schedule['scheduled_at'] != null) {
      final next = DateTime.parse(schedule['scheduled_at']).toLocal();

      if (next.isBefore(DateTime.now())) {
        return null;
      }

      return next;
    }

    // fallback for old records
    final datePart = DateTime.parse(schedule['checkin_date']);

    final parts = schedule['checkin_time'].split(':');

    final hour = int.parse(parts[0]);

    final minute = int.parse(parts[1]);

    final checkin = DateTime(
      datePart.year,
      datePart.month,
      datePart.day,
      hour,
      minute,
    );

    if (checkin.isBefore(DateTime.now())) {
      return null;
    }

    return checkin;
  }

  Widget _buildRecentActivity(BuildContext context, safetyRepo, familyId) {
    return Container(
      //padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.show_chart, color: Colors.green.shade600, size: 18),
              const SizedBox(width: 8),
              Text(
                'Recent Activity',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: ShieldColors.textBody,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          StreamBuilder<List<Map<String, dynamic>>>(
            stream: safetyRepo.streamFamilyEvents(familyId),
            builder: (context, eventSnapshot) {
              if (eventSnapshot.connectionState == ConnectionState.waiting &&
                  !_sosCountdownActive) {
                return const Center(child: CircularProgressIndicator());
              }

              final events = eventSnapshot.data ?? [];
              if (events.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 32),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(Icons.history, size: 48, color: Colors.grey),
                        SizedBox(height: 8),
                        Text(
                          'No recent activity yet.\nCheck-ins, SOS events, and status updates will appear here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: ShieldColors.textLabel),
                        ),
                      ],
                    ),
                  ),
                );
              }

              final latestEvent = events.first;

              return Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: ShieldDesign.roundedTwelve,
                  border: Border.all(color: Colors.grey.shade200, width: 0.5),
                ),
                child: Column(
                  children: [
                    _buildEventTile(latestEvent),
                    const Divider(height: 1),
                    _buildStatsSummary(events),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  int _computeAvgBpm(List<Map<String, dynamic>> events) {
    final bpmValues = events.map((e) => e['bpm']).whereType<num>().toList();

    if (bpmValues.isEmpty) return 0;

    final sum = bpmValues.fold<num>(0, (acc, val) => acc + val);
    return (sum / bpmValues.length).round();
  }

  Widget _buildStatsSummary(List<Map<String, dynamic>> events) {
    final avgBpm = _computeAvgBpm(events);
    final battery = events.first['battery_level'] ?? 0;
    final checkIns = events.where((e) => e['type'] == 'check_in').length;
    print(battery);
    print(events.first['battery_level']);
    print("batterybattery");
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          _buildStatChip(
            icon: Icons.favorite,
            color: Colors.red,
            value: '$avgBpm',
            label: 'Avg BPM',
          ),
          _buildStatChip(
            icon: CupertinoIcons.battery_25_percent,
            color: Colors.green,
            value: '$battery%',
            label: 'Battery',
          ),
          _buildStatChip(
            icon: Icons.access_time_filled,
            color: Colors.blue,
            value: '$checkIns',
            label: 'Check-ins',
          ),
          _buildStatChip(
            icon: Icons.safety_check_rounded,
            color: Colors.teal,
            value: 'Active',
            label: 'Status',
          ),
        ],
      ),
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required Color color,
    required String value,
    required String label,
  }) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 24, color: color),
                const SizedBox(width: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),

            Text(
              label,
              style: TextStyle(fontSize: 10, color: Colors.grey.shade900),
            ),
          ],
        ),
      ),
    );
  }

  /// Bug 3: Improved event tile with readable timestamps and icons
  Widget _buildEventTile(Map<String, dynamic> evt) {
    final type = (evt['event_type'] as String?) ?? 'unknown';
    final title =
        evt['title'] as String? ?? type.replaceAll('_', ' ').toUpperCase();
    final description = evt['description'] as String?;
    final fullName = evt['user_name'] as String?;
    final battery = evt['battery_level'];
    final createdAt = evt['created_at'] as String?;

    IconData icon = Icons.favorite_border;
    Color color = ShieldColors.activeTeal;

    switch (type) {
      case 'sos':
        icon = Icons.warning_amber_rounded;
        color = ShieldColors.urgentRed;
        break;
      case 'driving':
      case 'driving_alert':
      case 'driving_start':
      case 'biking_start':
        icon = Icons.directions_car;
        color = Colors.orange;
        break;
      case 'check_in':
        icon = Icons.how_to_reg;
        color = ShieldColors.safeZoneGreen;
        break;
      case 'medication_logged':
        icon = Icons.medical_services;
        color = Colors.purple;
        break;
      case 'campus_alert':
        icon = Icons.school;
        color = ShieldColors.alertRed;
        break;
      case 'status_update':
        icon = Icons.info_outline;
        color = Colors.blueGrey;
        break;
      case 'heartbeat':
        icon = Icons.favorite;
        color = ShieldColors.activeTeal;
        break;
      case 'safe_zone_enter':
        icon = Icons.verified_user;
        color = ShieldColors.safeZoneGreen;
        break;
      case 'vital_anomaly':
        icon = Icons.monitor_heart;
        color = ShieldColors.urgentRed;
        break;
    }

    String timeAgo = '';
    if (createdAt != null) {
      try {
        final dt = DateTime.parse(createdAt);
        final diff = DateTime.now().difference(dt);
        if (diff.inMinutes < 1) {
          timeAgo = 'Just now';
        } else if (diff.inMinutes < 60) {
          timeAgo = '${diff.inMinutes}m ago';
        } else if (diff.inHours < 24) {
          timeAgo = '${diff.inHours}h ago';
        } else {
          timeAgo = DateFormat.MMMd().format(dt);
        }
      } catch (_) {
        timeAgo = '';
      }
    }

    return ListTile(
      leading: Icon(icon, color: color),
      // title: Row(
      //   children: [
      //     if(fullName!=null&&fullName!='')
      //     Expanded(
      //       child: Text('$fullName-'??"", style: TextStyle(
      //         fontWeight: FontWeight.bold,
      //         color: Colors.black,
      //         fontSize: 12,
      //       ),),
      //     ),
      //     Text(
      //       title,
      //       style: TextStyle(
      //         fontWeight: FontWeight.bold,
      //         color: color,
      //         fontSize: 13,
      //       ),
      //     ),
      //   ],
      // ),
      title: RichText(
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          children: [
            if (fullName != null && fullName != '')
              TextSpan(
                text: '$fullName - ',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 12,
                ),
              ),

            TextSpan(
              text: title,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: ShieldColors.activeTeal,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),

      subtitle: Text(
        description ?? (battery != null ? 'Battery: $battery%' : ''),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 12),
      ),
      trailing: Text(
        timeAgo,
        style: const TextStyle(color: ShieldColors.textLabel, fontSize: 11),
      ),
    );
  }
}

/// Member cards with REAL data from latest events + live vitals
class _MemberStatusCard extends StatelessWidget {
  final Map<String, dynamic> member;
  final SafetyRepository safetyRepo;
  final String currentUserId;

  const _MemberStatusCard({
    required this.member,
    required this.safetyRepo,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final userId = member['id'] as String;
    final authUserId = member['user_id'] as String;

    return StreamBuilder<Map<String, dynamic>?>(
      stream: safetyRepo.streamMemberLatestEvent(authUserId),
      builder: (context, eventSnapshot) {
        // Nest a second StreamBuilder to get live vitals
        return StreamBuilder<List<Map<String, dynamic>>>(
          stream: safetyRepo.streamMemberEvents(authUserId),
          // use userId not authUserId
          builder: (context, eventsSnapshot) {
            final allEvents = eventsSnapshot.data ?? <Map<String, dynamic>>[];
            final checkInCount = allEvents
                .where((e) => e['event_type'] == 'check_in')
                .length;
            return StreamBuilder<List<Map<String, dynamic>>>(
              stream: safetyRepo.streamMemberVitals(authUserId),
              builder: (context, vitalsSnapshot) {
                final lastEvent = eventSnapshot.data;
                final vitals = vitalsSnapshot.data ?? [];
                final role = member['role'] as String;
                final avatar = member['avatar_url'] != null
                    ? member['avatar_url']
                    : null;
                final realName = member['full_name'] ?? 'Family Member';
                final isMe = userId == currentUserId;
                String displayName = isMe ? '$realName (You)' : realName;
                IconData statusIcon = Icons.info_outline;
                String statusText = 'Awaiting first pulse...';
                String? title = '';
                String? description = '';
                bool isAlert = false;
                List<Map<String, String>> metrics = [];

                // --- Derive status from latest event ---
                if (lastEvent != null) {
                  final type = lastEvent['event_type'] as String;
                  title = lastEvent['title'] as String?;
                  description = lastEvent['description'] as String?;

                  final battery = lastEvent['battery_level'];

                  final createdAt = lastEvent['created_at'] as String?;

                  String lastSeen = '';
                  if (createdAt != null) {
                    try {
                      final dt = DateTime.parse(createdAt);
                      final diff = DateTime.now().difference(dt);
                      if (diff.inMinutes < 5) {
                        lastSeen = 'Just now';
                      } else if (diff.inMinutes < 60) {
                        lastSeen = '${diff.inMinutes}m ago';
                      } else if (diff.inHours < 24) {
                        lastSeen = '${diff.inHours}h ago';
                      } else {
                        lastSeen = '${diff.inDays}d ago';
                      }
                    } catch (_) {}
                  }

                  if (type == 'sos' &&
                      lastEvent['metadata']?['status'] != 'resolved') {
                    isAlert = true;
                    statusText = 'EMERGENCY: SOS ACTIVE';
                    statusIcon = Icons.warning;
                  } else if (type == 'driving' || type == 'driving_alert') {
                    statusText = 'In Motion: Driving';
                    statusIcon = Icons.directions_car;
                  } else if (type == 'safe_zone_enter') {
                    statusText = 'In Safe Zone';
                    statusIcon = Icons.verified_user;
                  } else if (type == 'check_in') {
                    statusText = '$title\n$description • $lastSeen ';
                    statusIcon = Icons.how_to_reg;
                  } else if (type == 'heartbeat') {
                    statusText = lastSeen.isNotEmpty
                        ? 'Pulse active • $lastSeen'
                        : 'Pulse active';

                    statusIcon = Icons.favorite;
                  } else {
                    statusText = lastSeen.isNotEmpty
                        ? 'Last seen $lastSeen'
                        : 'Online';
                    statusIcon = Icons.check_circle_outline;
                  }

                  if (battery != null) {
                    metrics.add({
                      'label': 'BATTERY',
                      'value': '$battery',
                      'unit': '%',
                    });
                  }

                  final semLoc = lastEvent['metadata']?['semantic_location'];
                  if (semLoc != null) {
                    metrics.add({
                      'label': 'LOC',
                      'value': '$semLoc',
                      'unit': '',
                    });
                  } else if (lastEvent['latitude'] != null) {
                    metrics.add({
                      'label': 'LOC',
                      'value': 'GPS Active',
                      'unit': '',
                    });
                  }
                } else {
                  statusText = 'No pulse data yet';
                  statusIcon = Icons.radio_button_unchecked;
                }

                // --- Live Vitals from health_vitals table ---
                if (vitals.isNotEmpty) {
                  print("vitalsvitalsvitals");
                  print(vitals.map((v) => v['vital_type']).toList());
                  // Extract latest heart rate
                  final hrEntry =
                      vitals
                          .where((v) => v['vital_type'] == 'HEART_RATE')
                          .toList()
                        ..sort(
                          (a, b) => DateTime.parse(
                            b['timestamp'],
                          ).compareTo(DateTime.parse(a['timestamp'])),
                        );
                  if (hrEntry.isNotEmpty) {
                    final hrVal = hrEntry.first['value'];
                    final hrNum = (hrVal is num)
                        ? hrVal.round()
                        : (double.tryParse(hrVal.toString())?.round() ?? 0);
                    metrics.add({
                      'label': 'HR',
                      'value': '$hrNum',
                      'unit': 'BPM',
                    });
                  }

                  // Extract latest SpO2
                  final spo2Entry = vitals
                      .where((v) => v['vital_type'] == 'BLOOD_OXYGEN')
                      .toList();
                  if (spo2Entry.isNotEmpty) {
                    final spo2Val = spo2Entry.first['value'];
                    final spo2Num = (spo2Val is num)
                        ? spo2Val.round()
                        : (double.tryParse(spo2Val.toString())?.round() ?? 0);
                    metrics.add({
                      'label': 'SpO2',
                      'value': '$spo2Num',
                      'unit': '%',
                    });
                  }
                } else if (role == 'senior') {
                  // No vitals synced yet for senior
                  metrics.add({
                    'label': 'VITALS',
                    'value': 'No wearable',
                    'unit': '',
                  });
                }

                return Padding(
                  padding: const EdgeInsets.only(bottom: 16.0),
                  child: ShieldMemberCard(
                    name: displayName,
                    status: role.toUpperCase(),
                    metrics: metrics,
                    subStatusIcon: statusIcon,
                    subStatusText: statusText,
                    isAlert: isAlert,
                    avatarUrl: avatar,
                    batteryLevel: lastEvent?['battery_level'] as num?,
                    vitals: vitals,
                    title: title,
                    description: description,
                    checkInCount: checkInCount,
                    isActive: lastEvent != null,
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

/// Bug 2: Notification bell bottom sheet
class _NotificationsSheet extends StatelessWidget {
  final String familyId;
  final SafetyRepository safetyRepo;

  const _NotificationsSheet({required this.familyId, required this.safetyRepo});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: ShieldColors.backgroundWhite,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.7,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 24),
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Text(
            'Notifications',
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: safetyRepo.streamFamilyEvents(familyId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final events = snapshot.data ?? [];
                if (events.isEmpty) {
                  return const Center(
                    child: Text(
                      'No notifications yet.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  );
                }
                return ListView.separated(
                  itemCount: events.length > 20 ? 20 : events.length,
                  separatorBuilder: (context, index) =>
                      const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final evt = events[index];
                    final type = (evt['event_type'] as String?) ?? 'unknown';
                    final title =
                        evt['title'] as String? ?? type.replaceAll('_', ' ');
                    final desc = evt['description'] as String? ?? '';
                    final userName = evt['user_name'] as String? ?? '';
                    final createdAt = evt['created_at'] as String?;
                    print(evt);
                    print("evtevt");
                    String dateStr = '';
                    String timeStr = '';

                    if (createdAt != null) {
                      try {
                        final dt = DateTime.parse(createdAt).toLocal();
                        dateStr = DateFormat('dd MMM yyyy').format(dt);
                        timeStr = DateFormat('h:mm a').format(dt);
                      } catch (_) {}
                    }
                    IconData icon = Icons.notifications;
                    if (type == 'sos') icon = Icons.warning;
                    if (type == 'check_in') icon = Icons.how_to_reg;
                    if (type.contains('driving')) icon = Icons.directions_car;

                    return ListTile(
                      leading: Icon(
                        icon,
                        size: 20,
                        color: ShieldColors.activeTeal,
                      ),
                      title: Text.rich(
                        TextSpan(
                          children: [
                            if (userName.isNotEmpty)
                              TextSpan(
                                text: userName,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            if (userName.isNotEmpty)
                              const TextSpan(text: ' - '),
                            TextSpan(
                              text: title,

                              style: const TextStyle(fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                      subtitle: desc.isNotEmpty
                          ? Text(
                              desc,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11),
                            )
                          : null,
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            dateStr,
                            style: const TextStyle(
                              fontSize: 10,
                              color: Colors.grey,
                            ),
                          ),
                          Text(
                            timeStr,
                            style: const TextStyle(
                              fontSize: 10,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CircularPulseIndicator extends StatelessWidget {
  const CircularPulseIndicator({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox(
      width: 40,
      height: 40,
      child: CircularProgressIndicator(color: ShieldColors.activeTeal),
    );
  }
}

class _NextCheckinCard extends ConsumerStatefulWidget {
  final DateTime nextCheckin;
  final UserProfile? profile;
  final String scheduleId;
  final String assignedUser;
  final String assignedUserId;

  const _NextCheckinCard({
    super.key,
    required this.nextCheckin,
    required this.profile,
    required this.scheduleId,
    required this.assignedUser,
    required this.assignedUserId,
  });

  @override
  ConsumerState<_NextCheckinCard> createState() => _NextCheckinCardState();
}

class _NextCheckinCardState extends ConsumerState<_NextCheckinCard> {
  bool _showCheckinPopup = false;
  bool isLoad = false;
  bool _sosCountdownActive = false;
  int _sosCountdown = 5;
  Timer? _sosTimer;

  void _startSosCountdown() {
    if (_sosCountdownActive) {
      _sosTimer?.cancel();
      setState(() {
        _sosCountdownActive = false;
        _sosCountdown = 5;
      });
      return;
    }

    setState(() {
      _sosCountdownActive = true;
      _sosCountdown = 5;
    });

    _sosTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      HapticFeedback.heavyImpact();

      if (_sosCountdown <= 1) {
        timer.cancel();
        try {
          final profile = await ref.read(currentUserProfileProvider.future);
          if (profile == null) {
            debugPrint(
              '[SOS] Profile is null — user has no family_members row',
            );
            if (mounted) {
              setState(() {
                _sosCountdownActive = false;
                _sosCountdown = 5;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    '⚠️ SOS FAILED: No family profile found. Please re-join a family first.',
                  ),
                  backgroundColor: Colors.orange,
                  duration: Duration(seconds: 5),
                ),
              );
            }
            return;
          }

          await ref
              .read(safetyRepositoryProvider)
              .triggerSiren(
                profile.familyId,
                'Monitor initiated an emergency state',
              );

          if (mounted) {
            setState(() {
              _sosCountdownActive = false;
              _sosCountdown = 5;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('🚨 EMERGENCY ALERT SENT!'),
                backgroundColor: ShieldColors.urgentRed,
                duration: Duration(seconds: 5),
              ),
            );
          }
          final members = await Supabase.instance.client
              .from('family_members')
              .select('user_id')
              .eq('family_id', profile.familyId);

          for (final m in members) {
            final targetUserId = m['user_id'];

            if (targetUserId == profile.userId) continue;

            try {
              await Supabase.instance.client.functions.invoke(
                'push-router',
                body: {
                  "target_user_id": targetUserId,
                  "title": "Emergency Alert",
                  "body": "${profile.fullName} triggered an emergency alert",
                  "action": "emergency",
                  "sound": "sos_sound",
                },
              );
            } catch (e) {
              debugPrint("Push failed: $e");
            }
          }
        } catch (e) {
          debugPrint('[SOS] triggerSiren failed: $e');
          if (mounted) {
            setState(() {
              _sosCountdownActive = false;
              _sosCountdown = 5;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('⚠️ SOS FAILED: $e'),
                backgroundColor: Colors.orange,
                duration: const Duration(seconds: 5),
              ),
            );
          }
        }
      } else {
        if (mounted) setState(() => _sosCountdown--);
      }
    });
  }

  void _checkScheduleTime(DateTime nextCheckin) {
    final now = DateTime.now();

    if (now.isAfter(nextCheckin) && !_showCheckinPopup) {
      _showCheckinPopup = true;

      // WidgetsBinding.instance.addPostFrameCallback((_) async {
      //   if (mounted) {
      //     var value = await _showCheckinDialog();
      //     print(value);
      //     print("valuevalue");
      //
      //     if (value == true) {
      //       if (isLoad) return;
      //       if (widget.profile == null) return;
      //       setState(() {
      //         isLoad = true;
      //       });
      //       int level =
      //           100; // Safe default for simulators and aggressive background iOS policies
      //       try {
      //         final battery = Battery();
      //         level = await battery.batteryLevel;
      //       } catch (e) {
      //         debugPrint(
      //           'Battery info not available over isolate, using default: $e',
      //         );
      //       }
      //
      //       final defaultMsg = "Checked in from Current Location.";
      //
      //       bool gpsSuccess = false;
      //       double lat = 0.0;
      //       double lng = 0.0;
      //
      //       try {
      //         bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      //         if (serviceEnabled) {
      //           LocationPermission permission =
      //               await Geolocator.checkPermission();
      //           if (permission == LocationPermission.denied) {
      //             permission = await Geolocator.requestPermission();
      //           }
      //           if (permission == LocationPermission.deniedForever) {
      //             setState(() {
      //               isLoad = false;
      //             });
      //             throw Exception(
      //               'Location permissions are permanently denied, we cannot request permissions. Please enable in Settings.',
      //             );
      //           }
      //
      //           if (permission == LocationPermission.whileInUse ||
      //               permission == LocationPermission.always) {
      //             // First attempt: High accuracy, short timeout
      //             try {
      //               final position = await Geolocator.getCurrentPosition(
      //                 locationSettings: const LocationSettings(
      //                   accuracy: LocationAccuracy.high,
      //                 ),
      //                 timeLimit: const Duration(seconds: 5),
      //               );
      //               lat = position.latitude;
      //               lng = position.longitude;
      //               gpsSuccess = true;
      //             } catch (_) {
      //               setState(() {
      //                 isLoad = false;
      //               });
      //               // Fallback 1: Low accuracy (Cell tower/Wi-Fi), very fast
      //               try {
      //                 final position = await Geolocator.getCurrentPosition(
      //                   locationSettings: const LocationSettings(
      //                     accuracy: LocationAccuracy.low,
      //                   ),
      //                   timeLimit: const Duration(seconds: 4),
      //                 );
      //                 lat = position.latitude;
      //                 lng = position.longitude;
      //                 gpsSuccess = true;
      //               } catch (_) {
      //                 setState(() {
      //                   isLoad = false;
      //                 });
      //                 // Fallback 2: Last known position
      //                 final lastPos = await Geolocator.getLastKnownPosition();
      //                 if (lastPos != null) {
      //                   lat = lastPos.latitude;
      //                   lng = lastPos.longitude;
      //                   gpsSuccess = true;
      //                 }
      //               }
      //             }
      //           }
      //         } else {
      //           setState(() {
      //             isLoad = false;
      //           });
      //           await Geolocator.openLocationSettings();
      //           throw Exception(
      //             'GPS Location Services are disabled on this device.',
      //           );
      //         }
      //       } catch (e) {
      //         setState(() {
      //           isLoad = false;
      //         });
      //         if (e is Exception &&
      //                 e.toString().contains('permanently denied') ||
      //             e.toString().contains('disabled')) {
      //           rethrow;
      //         }
      //       }
      //
      //       await Supabase.instance.client.from('check_ins').insert({
      //         'family_id': widget.profile?.familyId,
      //         'user_id': widget.profile?.userId,
      //         'latitude': lat,
      //         'longitude': lng,
      //         'status_message': "Scheduled check-in completed",
      //       });
      //
      //       // Also register this as a well_event to ensure it shows up securely on the stream!
      //       await logWellEvent(Supabase.instance.client,{
      //         'family_id': widget.profile?.familyId,
      //         'user_id': widget.profile?.userId,
      //         'user_name': widget.profile?.fullName,
      //         'event_type': 'check_in',
      //         'title': 'Manual Check-in',
      //         'description': 'Scheduled check-in completed',
      //         'latitude': lat,
      //         'longitude': lng,
      //         'battery_level': level,
      //       });
      //       final schedule = await Supabase.instance.client
      //           .from('checkin_schedules')
      //           .select('recurrence')
      //           .eq('id', widget.scheduleId)
      //           .single();
      //       final recurrence = schedule['recurrence'];
      //
      //       final isRecurring =
      //           recurrence == 'daily' ||
      //           recurrence == 'every_other_day' ||
      //           recurrence == 'weekly' ||
      //           recurrence == 'monthly';
      //
      //       DateTime? nextDate;
      //
      //       if (isRecurring) {
      //         final fullSchedule = await Supabase.instance.client
      //             .from('checkin_schedules')
      //             .select()
      //             .eq('id', widget.scheduleId)
      //             .single();
      //
      //         nextDate = DateTime.parse(fullSchedule['scheduled_at']);
      //
      //         switch (recurrence) {
      //           case 'daily':
      //             nextDate = nextDate.add(const Duration(days: 1));
      //             break;
      //
      //           case 'every_other_day':
      //             nextDate = nextDate.add(const Duration(days: 2));
      //             break;
      //
      //           case 'weekly':
      //             final days = List<int>.from(
      //               fullSchedule['days_of_week'] ?? [],
      //             );
      //
      //             if (days.isEmpty) {
      //               nextDate = nextDate.add(const Duration(days: 7));
      //             } else {
      //               final currentDay = nextDate.weekday % 7;
      //
      //               int? found;
      //
      //               for (final d in days) {
      //                 if (d > currentDay) {
      //                   found = d;
      //                   break;
      //                 }
      //               }
      //
      //               found ??= days.first + 7;
      //
      //               nextDate = nextDate.add(Duration(days: found - currentDay));
      //             }
      //
      //             break;
      //
      //           case 'monthly':
      //             nextDate = DateTime(
      //               nextDate.year,
      //               nextDate.month + 1,
      //               nextDate.day,
      //               nextDate.hour,
      //               nextDate.minute,
      //             );
      //             break;
      //         }
      //       }
      //
      //       await Supabase.instance.client
      //           .from('checkin_schedules')
      //           .update({
      //             if (!isRecurring) 'is_completed': true,
      //
      //             'completed_at': DateTime.now().toIso8601String(),
      //
      //             if (!isRecurring) 'status': 'completed',
      //
      //             if (isRecurring) ...{
      //               'status': 'pending',
      //               'scheduled_at': nextDate?.toIso8601String(),
      //               'reminder_sent': false,
      //               'reminder_sent_at': null,
      //             },
      //           })
      //           .eq('id', widget.scheduleId);
      //       if (!mounted) return;
      //
      //       ScaffoldMessenger.of(context).showSnackBar(
      //         SnackBar(content: Text("Scheduled check-in completed")),
      //       );
      //       final safety = ref.invalidate(safetyRepositoryProvider);
      //
      //       final profile = await ref.read(currentUserProfileProvider.future);
      //       if (profile == null) throw Exception('No profile');
      //
      //       final members = await Supabase.instance.client
      //           .from('family_members')
      //           .select('user_id, role')
      //           .eq('family_id', profile.familyId);
      //
      //       for (final m in members) {
      //         final targetUserId = m['user_id'];
      //
      //         if (targetUserId == profile.userId ||
      //             (m['role'] != "leader" && m['role'] != "monitor")) {
      //           continue;
      //         }
      //         try {
      //           await Supabase.instance.client.functions.invoke(
      //             'push-router',
      //             body: {
      //               "target_user_id": targetUserId,
      //               "title": "Check-In",
      //               "body":
      //                   "${profile.fullName ?? 'Someone'}: Checked in just now",
      //               "action": "check_in",
      //             },
      //           );
      //           setState(() {
      //             isLoad = false;
      //           });
      //         } catch (e) {
      //           print("Push failed: $e");
      //         }
      //       }
      //     } else if (value == false) {
      //       _startSosCountdown();
      //     }
      //   }
      // });
    }
  }

  Future<bool?> _showCheckinDialog() async {
    final result = await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return AlertDialog(
          title: const Text("Time To Check In"),
          content: const Text("Please confirm your status"),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: const Text("I'M OK"),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text("I NEED HELP"),
            ),
          ],
        );
      },
    );
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Stream.periodic(const Duration(seconds: 1)),
      builder: (context, snapshot) {
        Duration diff = widget.nextCheckin.difference(DateTime.now());

        if (diff.isNegative) {
          diff = Duration.zero;
        }

        final hours = diff.inHours.toString().padLeft(2, '0');

        final mins = diff.inMinutes.remainder(60).toString().padLeft(2, '0');

        final secs = diff.inSeconds.remainder(60).toString().padLeft(2, '0');
        if (widget.profile?.userId == widget.assignedUserId) {
          //  _checkScheduleTime(widget.nextCheckin);
        }
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 24),
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF00838F), Color(0xFF006064)],
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(
                    Icons.check_circle_outline,
                    color: Colors.white,
                    size: 42,
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Check In",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 42,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 8),

              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: const TextStyle(color: Colors.white70, fontSize: 18),
                  children: [
                    TextSpan(
                      text: widget.assignedUser,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    TextSpan(
                      text:
                          "- Next Check-In at ${DateFormat('dd MMM yyyy, hh:mm a').format(widget.nextCheckin)}",
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _timeBox(hours, "HRS"),
                  const SizedBox(width: 16),

                  const Text(
                    ":",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(width: 16),

                  _timeBox(mins, "MINS"),

                  const SizedBox(width: 16),

                  const Text(
                    ":",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(width: 16),

                  _timeBox(secs, "SECS"),
                ],
              ),
              if (widget.profile?.userId == widget.assignedUserId)
                SizedBox(height: 10),
              if (widget.profile?.userId == widget.assignedUserId)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF006064),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: () async {
                      print("isLoad$isLoad");
                      if (isLoad) return;
                      if (widget.profile == null) return;
                      setState(() {
                        isLoad = true;
                      });
                      int level =
                          100; // Safe default for simulators and aggressive background iOS policies
                      try {
                        final battery = Battery();
                        level = await battery.batteryLevel;
                      } catch (e) {
                        debugPrint(
                          'Battery info not available over isolate, using default: $e',
                        );
                      }

                      final defaultMsg = "Checked in from Current Location.";

                      bool gpsSuccess = false;
                      double lat = 0.0;
                      double lng = 0.0;

                      try {
                        bool serviceEnabled =
                            await Geolocator.isLocationServiceEnabled();
                        if (serviceEnabled) {
                          LocationPermission permission =
                              await Geolocator.checkPermission();
                          if (permission == LocationPermission.denied) {
                            permission = await Geolocator.requestPermission();
                          }
                          if (permission == LocationPermission.deniedForever) {
                            setState(() {
                              isLoad = false;
                            });
                            throw Exception(
                              'Location permissions are permanently denied, we cannot request permissions. Please enable in Settings.',
                            );
                          }

                          if (permission == LocationPermission.whileInUse ||
                              permission == LocationPermission.always) {
                            // First attempt: High accuracy, short timeout
                            try {
                              final position =
                                  await Geolocator.getCurrentPosition(
                                    locationSettings: const LocationSettings(
                                      accuracy: LocationAccuracy.high,
                                    ),
                                    timeLimit: const Duration(seconds: 5),
                                  );
                              lat = position.latitude;
                              lng = position.longitude;
                              gpsSuccess = true;
                            } catch (_) {
                              setState(() {
                                isLoad = false;
                              });
                              // Fallback 1: Low accuracy (Cell tower/Wi-Fi), very fast
                              try {
                                final position =
                                    await Geolocator.getCurrentPosition(
                                      locationSettings: const LocationSettings(
                                        accuracy: LocationAccuracy.low,
                                      ),
                                      timeLimit: const Duration(seconds: 4),
                                    );
                                lat = position.latitude;
                                lng = position.longitude;
                                gpsSuccess = true;
                              } catch (_) {
                                setState(() {
                                  isLoad = false;
                                });
                                // Fallback 2: Last known position
                                final lastPos =
                                    await Geolocator.getLastKnownPosition();
                                if (lastPos != null) {
                                  lat = lastPos.latitude;
                                  lng = lastPos.longitude;
                                  gpsSuccess = true;
                                }
                              }
                            }
                          }
                        } else {
                          setState(() {
                            isLoad = false;
                          });
                          await Geolocator.openLocationSettings();
                          throw Exception(
                            'GPS Location Services are disabled on this device.',
                          );
                        }
                      } catch (e) {
                        setState(() {
                          isLoad = false;
                        });
                        if (e is Exception &&
                                e.toString().contains('permanently denied') ||
                            e.toString().contains('disabled')) {
                          rethrow;
                        }
                      }

                      final fullSchedule = await Supabase.instance.client
                          .from('checkin_schedules')
                          .select()
                          .eq('id', widget.scheduleId)
                          .single();

                      final recurrence = fullSchedule['recurrence'] as String?;
                      final scheduledAtUtc = DateTime.parse(
                        fullSchedule['scheduled_at'],
                      ).toUtc();
                      final nowUtc = DateTime.now().toUtc();

                      print("🕐 nowUtc: $nowUtc");
                      print("🕐 scheduledAtUtc: $scheduledAtUtc");
                      print(
                        "🕐 diff: ${scheduledAtUtc.difference(nowUtc).inMinutes} mins away",
                      );

                      // ── Within 5 min early window? ───────────────────────────────────
                      final isWithin5MinEarly =
                          nowUtc.isAfter(
                            scheduledAtUtc.subtract(const Duration(minutes: 5)),
                          ) &&
                          nowUtc.isBefore(
                            scheduledAtUtc.add(const Duration(minutes: 1)),
                          );
                      print("away11");
                      final isRecurring =
                          isWithin5MinEarly &&
                          (recurrence == 'daily' ||
                              recurrence == 'every_other_day' ||
                              recurrence == 'weekly' ||
                              recurrence == 'monthly');
                      print("away12");

                      // ── Insert check_in ──────────────────────────────────────────────
                      await Supabase.instance.client.from('check_ins').insert({
                        'family_id': widget.profile!.familyId,
                        'user_id': widget.profile!.userId,
                        'latitude': lat,
                        'longitude': lng,
                        'status_message': isWithin5MinEarly
                            ? "Scheduled check-in completed"
                            : "Manual check-in",
                      });
                      print("away13");

                      // ── Insert well_event ────────────────────────────────────────────
                      await Supabase.instance.client
                          .from('well_events')
                          .insert({
                            'family_id': widget.profile!.familyId,
                            'user_id': widget.profile!.userId,
                            'user_name': widget.profile!.fullName,
                            'event_type': 'check_in',
                            'title': isWithin5MinEarly
                                ? 'Scheduled Check-in'
                                : 'Manual Check-in',
                            'description': isWithin5MinEarly
                                ? 'Scheduled check-in completed'
                                : 'Manual check-in outside schedule window',
                            'latitude': lat,
                            'longitude': lng,
                            'battery_level': level,
                          });
                      print("away14");

                      // ── Compute next date if recurring ───────────────────────────────
                      // ❌ DELETE the old `final schedule = ...` fetch here — REMOVE IT
                      // ❌ DELETE the second `fullSchedule` fetch inside if(isRecurring) — REMOVE IT

                      DateTime? nextDate;

                      if (isRecurring) {
                        nextDate =
                            scheduledAtUtc; // ✅ reuse already fetched value

                        switch (recurrence) {
                          // continues below...
                          case 'daily':
                            nextDate = nextDate.add(const Duration(days: 1));
                            break;

                          case 'every_other_day':
                            nextDate = nextDate.add(const Duration(days: 2));
                            break;

                          case 'weekly':
                            final days = List<int>.from(
                              fullSchedule['days_of_week'] ?? [],
                            );

                            if (days.isEmpty) {
                              nextDate = nextDate.add(const Duration(days: 7));
                            } else {
                              final currentDay = nextDate.weekday % 7;

                              int? found;

                              for (final d in days) {
                                if (d > currentDay) {
                                  found = d;
                                  break;
                                }
                              }

                              found ??= days.first + 7;

                              nextDate = nextDate.add(
                                Duration(days: found - currentDay),
                              );
                            }

                            break;

                          case 'monthly':
                            nextDate = DateTime(
                              nextDate.year,
                              nextDate.month + 1,
                              nextDate.day,
                              nextDate.hour,
                              nextDate.minute,
                            );
                            break;
                        }
                      }
                      print("away15");

                      await Supabase.instance.client
                          .from('checkin_schedules')
                          .update(
                            isRecurring
                                ? {
                                    'status': 'pending',
                                    'completed_at': DateTime.now()
                                        .toIso8601String(),
                                    'scheduled_at': nextDate!.toIso8601String(),
                                    'reminder_sent': false,
                                    'reminder_sent_at': null,
                                  }
                                : isWithin5MinEarly
                                ? {
                                    'is_completed': true,
                                    'completed_at': DateTime.now()
                                        .toIso8601String(),
                                    'status': 'completed',
                                  }
                                : {
                                    // ✅ Manual check-in — just log the time, keep status as-is
                                    'completed_at': DateTime.now()
                                        .toIso8601String(),
                                  },
                          )
                          .eq('id', widget.scheduleId);
                      if (!mounted) return;
                      print("away15");

                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   SnackBar(
                      //     content: Text(
                      //       !isWithin5MinEarly
                      //           ? "Manual check-in completed"
                      //           : "Scheduled check-in completed",
                      //     ),
                      //   ),
                      // );
                      final safety = ref.invalidate(safetyRepositoryProvider);

                      final profile = await ref.read(
                        currentUserProfileProvider.future,
                      );
                      print("away17");

                      if (profile == null) throw Exception('No profile');
                      final response = await Supabase.instance.client
                          .from('live_locations')
                          .upsert({
                            'user_id': profile.userId,
                            'family_id': profile.familyId,
                            'user_name': profile.fullName,
                            'role': profile.role,
                            'latitude': lat,
                            'longitude': lng,
                            'battery_level': level,
                            'updated_at': DateTime.now().toIso8601String(),
                          }, onConflict: 'user_id')
                          .select();
                      final members = await Supabase.instance.client
                          .from('family_members')
                          .select('user_id, role')
                          .eq('family_id', profile.familyId);
                      print("away18");
                      setState(() {
                        isLoad = false;
                      });
                      for (final m in members) {
                        final targetUserId = m['user_id'];

                        if (targetUserId == profile.userId ||
                            (m['role'] != "leader" && m['role'] != "monitor")) {
                          continue;
                        }
                        try {
                          await Supabase.instance.client.functions.invoke(
                            'push-router',
                            body: {
                              "target_user_id": targetUserId,
                              "title": "Check-In",
                              "body":
                                  "${profile.fullName ?? 'Someone'}: Checked in just now",
                              "action": "check_in",
                            },
                          );
                          print("push-router123");

                          setState(() {
                            isLoad = false;
                          });
                          print("away19");
                        } catch (e) {
                          print("Push failed: $e");
                        }
                      }
                    },
                    child: isLoad
                        ? SizedBox(
                            height: 25,
                            width: 25,
                            child: Center(child: CircularProgressIndicator()),
                          )
                        : const Text(
                            "CHECK IN NOW",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                  ),
                ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Widget _timeBox(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 40,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 4),

        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

class _DialogConfig {
  final IconData icon;
  final Color color;
  final String title;

  _DialogConfig({required this.icon, required this.color, required this.title});
} // sync_result.dart

class LiveMembersMap extends StatefulWidget {
  final List<Map<String, dynamic>> events;

  const LiveMembersMap({super.key, required this.events});

  @override
  State<LiveMembersMap> createState() => _LiveMembersMapState();
}

class _LiveMembersMapState extends State<LiveMembersMap> {
  final MapController _mapController = MapController();

  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();

    // Auto refresh map every 15 seconds
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    /// Remove duplicate users and keep latest location
    final Map<String, Map<String, dynamic>> latestUsers = {};

    for (final item in widget.events) {
      final userId = item['user_id'];

      if (userId == null) continue;

      latestUsers[userId] = item;
    }

    final locations = latestUsers.values.toList();

    /// Remove leader & monitor
    final filteredLocations = locations.where((e) {
      final role = (e['role'] ?? '').toString().toLowerCase();

      return role != 'leader' && role != 'monitor';
    }).toList();

    if (filteredLocations.isEmpty) {
      return const SizedBox();
    }

    final first = filteredLocations.first;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 0),
      height: 280,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
      child: FlutterMap(
        mapController: _mapController,
        options: MapOptions(
          initialCenter: LatLng(
            first['latitude'] != null
                ? (first['latitude'] as num).toDouble()
                : 0.0,
            first['longitude'] != null
                ? (first['longitude'] as num).toDouble()
                : 0.0,
          ),
          initialZoom: 10,
          maxZoom: 22,
          minZoom: 8,
        ),

        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.anwiik.wellcheck',
          ),

          MarkerLayer(
            markers: filteredLocations.map((item) {
              final lat = item['latitude'] != null
                  ? (item['latitude'] as num).toDouble()
                  : 0.0;
              final lng = item['longitude'] != null
                  ? (item['longitude'] as num).toDouble()
                  : 0.0;

              final userName = item['user_name'] ?? 'Unknown';

              return Marker(
                point: LatLng(lat, lng),
                width: 120,
                height: 80,

                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 4,
                            color: Colors.black.withOpacity(0.1),
                          ),
                        ],
                      ),
                      child: Text(
                        userName,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),

                    const SizedBox(height: 4),

                    const Icon(Icons.location_on, size: 36, color: Colors.red),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _StepTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _StepTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF007F80), size: 24),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _GuidedSetupSheet extends StatefulWidget {
  final VoidCallback onInviteMembers;
  final VoidCallback onAddMedication;
  final VoidCallback onOpenCommandCenter;
  final VoidCallback onScheduleCheckIn;

  const _GuidedSetupSheet({
    required this.onInviteMembers,
    required this.onAddMedication,
    required this.onOpenCommandCenter,
    required this.onScheduleCheckIn,
  });

  @override
  State<_GuidedSetupSheet> createState() => _GuidedSetupSheetState();
}

class _GuidedSetupSheetState extends State<_GuidedSetupSheet> {
  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      expand: false,
      builder: (_, controller) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: SingleChildScrollView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Handle bar
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Header
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: ShieldColors.activeTeal.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.rocket_launch_rounded,
                        color: ShieldColors.activeTeal,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Set up your Shield',
                            style: Theme.of(context).textTheme.titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: ShieldColors.textBody,
                                ),
                          ),
                          Text(
                            'A few steps to protect your family',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(color: ShieldColors.textLabel),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(
                        Icons.close,
                        color: Colors.grey,
                        size: 20,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Step cards
                _SetupStepCard(
                  index: 1,
                  icon: Icons.person_add_alt_1,
                  iconColor: Colors.blue,
                  title: 'Invite Family Members',
                  subtitle:
                      'Add your family so they can check in and share their location with you.',
                  actionLabel: 'Send Invite',
                  onTap: widget.onInviteMembers,
                ),
                const SizedBox(height: 12),

                _SetupStepCard(
                  index: 2,
                  icon: Icons.medication_rounded,
                  iconColor: Colors.purple,
                  title: 'Add Medications',
                  subtitle:
                      'Track medications and get countdown reminders for each dose.',
                  actionLabel: 'Add Medication',
                  onTap: widget.onAddMedication,
                ),
                const SizedBox(height: 12),
                _SetupStepCard(
                  index: 3,
                  icon: Icons.schedule_sharp,
                  iconColor: Colors.pink,
                  title: 'Schedule a Check-In',
                  subtitle:
                      'Set a time for family members to confirm they\'re safe. You\'ll be alerted if they miss it.',
                  actionLabel: 'Set Schedule',
                  onTap: widget.onScheduleCheckIn,
                ),
                const SizedBox(height: 12),

                _SetupStepCard(
                  index: 4,
                  icon: Icons.grid_view_rounded,
                  iconColor: ShieldColors.activeTeal,
                  title: 'Explore the Command Center',
                  subtitle:
                      'Set safe zones, schedules, check-ins, and more from the MENU.',
                  actionLabel: 'Open Menu',
                  onTap: widget.onOpenCommandCenter,
                ),
                const SizedBox(height: 20),

                // Skip / do it later
                Center(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      'I\'ll explore on my own',
                      style: TextStyle(
                        color: ShieldColors.textLabel,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SetupStepCard extends StatelessWidget {
  final int index;
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final String actionLabel;
  final VoidCallback onTap;

  const _SetupStepCard({
    required this.index,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.actionLabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Step number badge
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$index',
                style: TextStyle(
                  color: iconColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(icon, color: iconColor, size: 18),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: onTap,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: iconColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      actionLabel,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
